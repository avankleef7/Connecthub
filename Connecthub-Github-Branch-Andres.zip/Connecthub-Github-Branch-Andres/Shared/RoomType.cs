﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared
{
    public enum RoomType
    {
        Classroom = 1,    
        Auditorium = 2,   
        Laboratory = 3,    
        Gym = 4,           
        Office = 5         


    }
}
