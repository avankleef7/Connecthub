﻿using System.ComponentModel;

namespace Shared
{
    public enum EventType
    {
        [Description("Geen")]
        None,

        [Description("Cursus")]
        Course,             // Cursus

        [Description("Workshop")]
        Workshop,           // Workshop

        [Description("Lezing")]
        Lecture,            // Lezing

        [Description("Bijeenkomst")]
        Meeting,            // Bijeenkomst

        [Description("Sportevenement")]
        Sport,              // Sportevenement

        [Description("Festival")]
        Festival,           // Festival

        [Description("Open Dag")]
        OpenDay,            // Open Dag

        [Description("Excursie")]
        Excursion,          // Excursie

        [Description("Competitie")]
        Competition,        // Competitie

        [Description("Cultureel evenement")]
        CulturalEvent       // Cultureel evenement
    }
}
