﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared
{
    public enum EnumUnittestHelper
    {
        [Description("Dit is de beschrijving ")]
        Success,

        Pending
    }
}
