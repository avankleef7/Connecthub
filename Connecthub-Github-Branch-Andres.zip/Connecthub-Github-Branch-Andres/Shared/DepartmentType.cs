﻿using System.ComponentModel;

namespace Shared
{

    public enum DepartmentType
    {
        [Description("Geen")]
        None,

        [Description("Educatie en Kindontwikkeling")]
        EducationAndChildDevelopment,

        [Description("Gezondheid en Sport")]
        HealthAndSports,

        [Description("Economie en Bedrijf")]
        EconomicsAndBusiness,

        [Description("Technologie en Natuur")]
        TechnologyAndNature,

        [Description("Gedrag en Samenleving")]
        BehaviorAndSociety,

        [Description("Taal en Communicatie")]
        LanguageAndCommunication,

        [Description("Kunst")]
        Art,

        [Description("ICT")]
        ICT,

        [Description("Logistiek")]
        Logistics
    }
}
