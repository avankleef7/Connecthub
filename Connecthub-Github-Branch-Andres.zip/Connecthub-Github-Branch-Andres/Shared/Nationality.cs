﻿using System.ComponentModel;

namespace Shared
{
    public enum Nationality
    {
        [Description("Algerije")]
        Algerije,

        [Description("Argentinië")]
        Argentinië,

        [Description("Australië")]
        Australië,

        [Description("Brazilië")]
        Brazilië,

        [Description("België")]
        België,

        [Description("Canada")]
        Canada,

        [Description("Chili")]
        Chili,

        [Description("China")]
        China,

        [Description("Colombia")]
        Colombia,

        [Description("Denemarken")]
        Denemarken,

        [Description("Duitsland")]
        Duitsland,

        [Description("Egypte")]
        Egypte,

        [Description("Finland")]
        Finland,

        [Description("Frankrijk")]
        Frankrijk,

        [Description("Indonesië")]
        Indonesië,

        [Description("India")]
        India,

        [Description("Italië")]
        Italië,

        [Description("Japan")]
        Japan,

        [Description("Kenia")]
        Kenia,

        [Description("Noorwegen")]
        Noorwegen,

        [Description("Nieuw-Zeeland")]
        NieuwZeeland,

        [Description("Nederland")]
        Nederland,

        [Description("Nigeria")]
        Nigeria,

        [Description("Oostenrijk")]
        Oostenrijk,

        [Description("Rusland")]
        Rusland,

        [Description("Saoedi-Arabië")]
        SaoediArabië,

        [Description("Spanje")]
        Spanje,

        [Description("Turkije")]
        Turkije,

        [Description("Verenigde Arabische Emiraten")]
        VerenigdeArabischeEmiraten,

        [Description("Verenigd Koninkrijk")]
        VerenigdKoninkrijk,

        [Description("Verenigde Staten")]
        VerenigdeStaten,

        [Description("Zuid-Afrika")]
        ZuidAfrika,

        [Description("Zuid-Korea")]
        ZuidKorea,

        [Description("Zwitserland")]
        Zwitserland
    }
}
