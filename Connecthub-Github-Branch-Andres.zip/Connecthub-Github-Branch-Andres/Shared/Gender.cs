﻿using System.ComponentModel;

public enum Gender
{
    [Description("Man")]
    Man,

    [Description("Vrouw")]
    Vrouw,

    [Description("Non-Binaire")]
    NonBinaire,

    [Description("Anders")]
    Anders
}
