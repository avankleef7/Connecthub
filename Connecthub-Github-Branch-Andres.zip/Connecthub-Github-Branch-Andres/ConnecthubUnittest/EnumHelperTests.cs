﻿using Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;


namespace ConnecthubUnittest
{
    public class EnumHelperTests
    {
        [Fact]
        public void GetDescriptionWithDescriptionAttributeReturnsCorrectDescription()
        {
            // Arrange
            var status = EnumUnittestHelper.Success;

            // Act
            var description = EnumHelper.GetDescription(status);

            // Assert
            Assert.Equal("Dit is de beschrijving ", description);
        }

        
        [Fact]
        public void GetDescriptionWithoutDescriptionAttributeReturnsEnumName()
        {
            // Arrange
            var status = EnumUnittestHelper.Pending;

            // Act
            var description = EnumHelper.GetDescription(status);

            // Assert
            Assert.Equal("Pending", description);
        }


    }
}
