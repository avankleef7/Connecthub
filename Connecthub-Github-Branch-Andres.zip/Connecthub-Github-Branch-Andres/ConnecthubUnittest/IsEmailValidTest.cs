﻿using Core.Domain.Helperclasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConnecthubUnittest
{
    public class IsEmailValidTest
    {

        [Fact]
        public void IsValidEmailValidEmailReturnsTrue()
        {
            // Arrange
            string validemail = "invalid@invalid.com";

            // Act
            bool result = IsEmailValid.IsValidEmail(validemail);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void IsValidEmailValidEmailReturnsFalse()
        {
            // Arrange
            string invalidemail = "invalid.com";

            // Act
            bool result = IsEmailValid.IsValidEmail(invalidemail);

            // Assert
            Assert.False(false);
        }
        [Fact]
        public void IsValidEmailInvalidEmailMissingDomainReturnsFalse()
        {
            // Arrange
            string invalidEmail = "invalid@.com";

            // Act
            bool result = IsEmailValid.IsValidEmail(invalidEmail);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public void IsValidEmailInvalidEmailWithSpacesReturnsFalse()
        {
            // Arrange
            string invalidEmail = "invalid @example.com";

            // Act
            bool result = IsEmailValid.IsValidEmail(invalidEmail);

            // Assert
            Assert.False(result);
        }
    }
}
