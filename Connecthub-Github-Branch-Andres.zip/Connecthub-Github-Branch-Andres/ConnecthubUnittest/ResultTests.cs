﻿using Core.Domain;
using System;
using Xunit;

namespace ConnecthubUnittest
{
    public class ResultTests
    {
        [Fact]
        public void ConstructorWithSuccessTrueAndSuccessMessage()
        {
            // Arrange
            bool success = true;
            string message = "Operation successful";
            string type = "Success";

            // Act
            var result = new Result(success, message, type);

            // Assert
            Assert.True(result.Success);
            Assert.Equal("Operation successful", result.Reason);
            Assert.Equal("Success", result.Type);
        }

        [Fact]
        public void ConstructorWithFalseAndFailureMessage()
        {
            // Arrange
            bool success = false;
            string message = "Operation failed";
            string type = "Failure";

            // Act
            var result = new Result(success, message, type);

            // Assert
            Assert.False(result.Success);
            Assert.Equal("Operation failed", result.Reason);
            Assert.Equal("Failure", result.Type);
        }

        [Fact]
        public void ConstructorWithNullReasonThrowsArgumentNullException()
        {
            // Arrange
            bool success = true;
            string reason = null;
            string type = "Success";

            // Act & Assert
            var exception = Assert.Throws<ArgumentNullException>(() => new Result(success, reason, type));
            Assert.Equal("Bericht mag niet null of leeg zijn voor een failure. (Parameter 'reason')", exception.Message);
        }

        [Fact]
        public void CreateSuccessWithNullMessageReturnsDefaultSuccessMessage()
        {
            // Arrange
            var result = new Result(true, "Success", "Success");

            // Act
            var createdResult = result.CreateSuccess(null);

            // Assert
            Assert.True(createdResult.Success);
            Assert.Equal("Success", createdResult.Reason);
            Assert.Equal("Success", createdResult.Type);
        }

        [Fact]
        public void CreateFailureWithNullMessageThrowsArgumentNullException()
        {
            // Arrange
            string reason = null;

            // Act & Assert
            var exception = Assert.Throws<ArgumentNullException>(() => new Result(true, "Success", "Success").CreateFailure(reason));
            Assert.Equal("Bericht mag niet null of leeg zijn voor een failure. (Parameter 'message')", exception.Message);
        }

        [Fact]
        public void CreateFailureWithEmptyMessageThrowsArgumentNullException()
        {
            // Arrange
            string reason = string.Empty;

            // Act & Assert
            var exception = Assert.Throws<ArgumentNullException>(() => new Result(true, "Success", "Success").CreateFailure(reason));
            Assert.Equal("Bericht mag niet null of leeg zijn voor een failure. (Parameter 'message')", exception.Message);
        }

    }
}
