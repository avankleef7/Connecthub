using Core.Domain.Helperclasses;
using System;
using Xunit;

namespace ConnecthubUnittest
{
    public class Helperclasses
    {
        [Fact]
        public void CalculateYearsToDateInputIsTodayReturnsZero()
        {
            // Arrange
            DateTime today = DateTime.Today;

            // Act
            int result = DateTimeHelper.CalculateYearsToDate(today);

            // Assert
            Assert.Equal(0, result);
        }

        [Fact]
        public void CalculateYearsToDateInputIsOneYearAgoReturnsOne()
        {
            // Arrange
            DateTime oneYearAgo = DateTime.Today.AddYears(-1);

            // Act
            int result = DateTimeHelper.CalculateYearsToDate(oneYearAgo);

            // Assert
            Assert.Equal(1, result);
        }

        [Fact]
        public void CalculateDaysBetweenDatesReturnsOneWhenOneDayApart()
        {
            // Arrange
            DateTime startDate = new DateTime(2023, 1, 1);
            DateTime endDate = new DateTime(2023, 1, 2);

            // Act
            int result = DateTimeHelper.CalculateDaysBetweenDates(startDate, endDate);

            // Assert
            Assert.Equal(1, result);
        }

        [Fact]
        public void CalculateDaysBetweenDatesReturnsZeroWhenDatesAreSame()
        {
            // Arrange
            DateTime startDate = new DateTime(2023, 1, 1);
            DateTime endDate = new DateTime(2023, 1, 1);

            // Act
            int result = DateTimeHelper.CalculateDaysBetweenDates(startDate, endDate);

            // Assert
            Assert.Equal(0, result);
        }

        [Fact]
        public void CalculateDaysBetweenDateReturnsNegativeWhenEndDateBeforeStartDate()
        {
            // Arrange
            DateTime startDate = new DateTime(2023, 1, 2);
            DateTime endDate = new DateTime(2023, 1, 1);

            // Act
            int result = DateTimeHelper.CalculateDaysBetweenDates(startDate, endDate);

            // Assert
            Assert.Equal(-1, result);
        }


    }
}
