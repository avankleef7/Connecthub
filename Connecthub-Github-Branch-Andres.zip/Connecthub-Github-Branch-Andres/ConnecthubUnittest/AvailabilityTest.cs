﻿using System;
using System.Collections.Generic;
using Xunit;
using Moq;
using Core.Domain;
using Shared;

namespace ConnecthubUnittest
{
    public class AvailabilityTest
    {

        [Fact]
        public void IsAvailableConflictingEventExistsReturnsFalse()
        {
            // Arrange
            var mockStudent = new Mock<IParticipant>("John", "Doe", Gender.Man, Nationality.Nederland, DateTime.Now.AddYears(-20), "john.doe@example.com");

            var mockVenue = new Mock<Venue>("Test Venue", "Test Straat", RoomType.Classroom, 50, true, false, true, false);

            var mockDepartment = new Mock<Department>();
            mockDepartment.Setup(d => d.GetName).Returns("ICT Department");
            mockDepartment.Setup(d => d.GetDepartmentType).Returns(DepartmentType.ICT);
            mockDepartment.Setup(d => d.GetDescription).Returns("This department focuses on Information and Communication Technology, providing students with the skills and knowledge required for careers in IT.");
            mockDepartment.Setup(d => d.GetStudentCapacity).Returns(200);  
            mockDepartment.Setup(d => d.GetTeacherCapacity).Returns(50);  

            var existingEvent = new Mock<Event>(
                "Conflicting Event",
                EventType.Lecture,
                mockDepartment.Object,
                DateTime.Today,
                TimeSpan.FromHours(10),
                DateTime.Today,
                TimeSpan.FromHours(12),
                "Een conflicterend evenement.",
                mockVenue.Object
            );

            var newEvent = new Mock<Event>(
                "New Event",
                EventType.Workshop,
                mockDepartment.Object,
                DateTime.Today,
                TimeSpan.FromHours(11),
                DateTime.Today,
                TimeSpan.FromHours(13),
                "Een nieuw evenement.",
                mockVenue.Object
            );

            var mockEventCatalog = new Mock<EventCatalog>();
            mockEventCatalog.Setup(c => c.GetEvents).Returns(new List<Event> { existingEvent.Object });

            var availabilityChecker = new AvailabilityChecker(mockEventCatalog.Object);

            // Act
            var result = availabilityChecker.IsAvailable(mockStudent.Object, newEvent.Object);

            // Assert
            Assert.False(result.Success);
            Assert.Equal("Al ingeschreven voor een ander evenement op dit tijdstip.", result.Reason);
        }
        [Fact]
        public void IsAvailableConflictingEventExistsReturnsTrue()
        {
            // Arrange
            var mockStudent = new Mock<IParticipant>("John", "Doe", Gender.Man, Nationality.Nederland, DateTime.Now.AddYears(-20), "john.doe@example.com");

            var mockVenue = new Mock<Venue>("Test Venue", "Test Straat", RoomType.Classroom, 50, true, false, true, false);

            var mockDepartment = new Mock<Department>();
            mockDepartment.Setup(d => d.GetName).Returns("ICT Department");
            mockDepartment.Setup(d => d.GetDepartmentType).Returns(DepartmentType.ICT);
            mockDepartment.Setup(d => d.GetDescription).Returns("This department focuses on Information and Communication Technology, providing students with the skills and knowledge required for careers in IT.");
            mockDepartment.Setup(d => d.GetStudentCapacity).Returns(200);
            mockDepartment.Setup(d => d.GetTeacherCapacity).Returns(50);

            var existingEvent = new Mock<Event>(
                "Conflicting Event",
                EventType.Lecture,
                mockDepartment.Object,
                DateTime.Today,
                TimeSpan.FromHours(10),
                DateTime.Today,
                TimeSpan.FromHours(12),
                "Een conflicterend evenement.",
                mockVenue.Object
            );

            var newEvent = new Mock<Event>(
                "New Event",
                EventType.Workshop,
                mockDepartment.Object,
                DateTime.Today,
                TimeSpan.FromHours(11),
                DateTime.Today.AddDays(1),
                TimeSpan.FromHours(13),
                "Een nieuw evenement.",
                mockVenue.Object
            );

            var mockEventCatalog = new Mock<EventCatalog>();
            mockEventCatalog.Setup(c => c.GetEvents).Returns(new List<Event> { existingEvent.Object });

            var availabilityChecker = new AvailabilityChecker(mockEventCatalog.Object);

            // Act
            var result = availabilityChecker.IsAvailable(mockStudent.Object, newEvent.Object);

            // Assert
            Assert.False(result.Success);
            Assert.Equal("Al ingeschreven voor een ander evenement op dit tijdstip.", result.Reason);
        }
        //[Fact]
        //public void IsAvailableWorkshopEventParticipantToNewEventReturnsTrue()
        //{
        //    // Arrange
        //    var mockParticipant = new Mock<IParticipant>();
        //    mockParticipant.Setup(p => p.GetFirstName).Returns("John");
        //    mockParticipant.Setup(p => p.GetLastName).Returns("Doe");
        //    mockParticipant.Setup(p => p.GetEmail).Returns("john.doe@example.com");

        //    var mockEventPeriod = new Mock<EventPeriod>(
        //        DateTime.Today.AddDays(1), 
        //        TimeSpan.FromHours(9),    
        //        DateTime.Today.AddDays(1), 
        //        TimeSpan.FromHours(11)     
        //    );

        //    // Mock de Venue
        //    var mockVenue = new Mock<Venue>("Locatie", "Straatnaam 123, Stad", RoomType.Classroom, 20, true, true, false, true);


        //    var mockEvent = new Mock<WorkshopEvent>(
        //        "Workshop over unittesting",
        //        EventType.Workshop,
        //        mockEventPeriod.Object,
        //        "Een introductie in Unittesting",
        //        mockVenue.Object,
        //        20
        //    );

        //    // Mock de event-catalogus als dat nodig is (hier geen conflicten, dus lege lijst)
        //    var mockEventCatalog = new Mock<ICatalog<Event>>();
        //    mockEventCatalog.Setup(c => c.GetItems()).Returns(new List<Event> { });

        //    // Maak de AvailabilityChecker aan met de gemockte EventCatalog
        //    var availabilityChecker = new AvailabilityChecker(mockEventCatalog.Object);

        //    // Act
        //    var result = availabilityChecker.IsAvailable(mockParticipant.Object, mockEvent.Object);

        //    // Assert
        //    Assert.True(result.Success);
        //    Assert.Equal("Beschikbaar voor dit evenement.", result.Reason);
        //}

        //[Fact]
        //public void IsAvailableSportEventParticipantToNewEventReturnsTrue()
        //{
        //    // Arrange
        //    var mockParticipant = new Mock<IParticipant>();
        //    mockParticipant.Setup(p => p.GetFirstName).Returns("John");
        //    mockParticipant.Setup(p => p.GetLastName).Returns("Doe");
        //    mockParticipant.Setup(p => p.GetEmail).Returns("john.doe@example.com");

        //    var mockEventPeriod = new Mock<EventPeriod>(
        //       DateTime.Today.AddDays(1),
        //       TimeSpan.FromHours(9),
        //       DateTime.Today.AddDays(1),
        //       TimeSpan.FromHours(11)
        //   );


        //    // Mock de Venue
        //    var mockVenue = new Mock<Venue>("Locatie", "Straatnaam 123, Stad", RoomType.Classroom, 20, true, true, false, true);


        //    var mockEvent = new Mock<SportEvent>(
        //        "Sport event over hardlopen",
        //        EventType.Sport,
        //        mockEventPeriod.Object,
        //        "Een introductie in hardlopen",
        //        mockVenue.Object,
        //        20
        //    );

        //    // Mock de event-catalogus als dat nodig is (hier geen conflicten, dus lege lijst)
        //    var mockEventCatalog = new Mock<ICatalog<Event>>();
        //    mockEventCatalog.Setup(c => c.GetItems()).Returns(new List<Event> { });


        //    var availabilityChecker = new AvailabilityChecker(mockEventCatalog.Object);

        //    // Act
        //    var result = availabilityChecker.IsAvailable(mockParticipant.Object, mockEvent.Object);

        //    // Assert
        //    Assert.True(result.Success);
        //    Assert.Equal("Beschikbaar voor dit evenement.", result.Reason);
        //}

        //[Fact]
        //public void IsAvailableMeetingEventParticipantToNewEventReturnsTrue()
        //{
        //    // Arrange
        //    var mockParticipant = new Mock<IParticipant>();
        //    mockParticipant.Setup(p => p.GetFirstName).Returns("John");
        //    mockParticipant.Setup(p => p.GetLastName).Returns("Doe");
        //    mockParticipant.Setup(p => p.GetEmail).Returns("john.doe@example.com");

        //    var mockEventPeriod = new Mock<EventPeriod>(
        //       DateTime.Today.AddDays(1),
        //       TimeSpan.FromHours(9),
        //       DateTime.Today.AddDays(1),
        //       TimeSpan.FromHours(11)
        //   );


        //    // Mock de Venue
        //    var mockVenue = new Mock<Venue>("Locatie", "Straatnaam 123, Stad", RoomType.Classroom, 20, true, true, false, true);

        //    var mockEvent = new Mock<MeetingEvent>(
        //        "Meeting over Connecthub",
        //        EventType.Meeting,
        //        mockEventPeriod.Object,
        //        "Een vergadering over unittesten",
        //        mockVenue.Object,
        //        20
        //    );


        //    var mockEventCatalog = new Mock<ICatalog<Event>>();
        //    mockEventCatalog.Setup(c => c.GetItems()).Returns(new List<Event> { });

        //    // Maak de AvailabilityChecker aan met de gemockte EventCatalog
        //    var availabilityChecker = new AvailabilityChecker(mockEventCatalog.Object);

        //    // Act
        //    var result = availabilityChecker.IsAvailable(mockParticipant.Object, mockEvent.Object);

        //    // Assert
        //    Assert.True(result.Success);
        //    Assert.Equal("Beschikbaar voor dit evenement.", result.Reason);
        //}

        //[Fact]
        //public void IsAvailableMeetingEventParticipantConflictingEventReturnFalse()
        //{
        //    // Arrange

        //    // 
        //    var department = new Department(
        //        "ICT Afdeling",
        //        DepartmentType.ICT,
        //        "Gespecialiseerd in informatie- en communicatietechnologie",
        //        250, // studentencapaciteit
        //        28   // docentencapaciteit
        //    );

        //    var mockParticipant = new Mock<Student>("John", "Doe", Gender.Man, Nationality.Nederland, DateTime.Today.AddYears(-25), "john.doe@example.com", department);
        //    mockParticipant.Setup(s => s.GetEmail).Returns("john.doe@example.com");

        //    var mockEventPeriod1 = new Mock<EventPeriod>(
        //        DateTime.Today.AddDays(1),
        //        TimeSpan.FromHours(9),
        //        DateTime.Today.AddDays(1),
        //        TimeSpan.FromHours(11)
        //    );

        //    var mockEventPeriod2 = new Mock<EventPeriod>(
        //        DateTime.Today.AddDays(1),
        //        TimeSpan.FromHours(10),
        //        DateTime.Today.AddDays(1),
        //        TimeSpan.FromHours(12)
        //    );

        //    // Mock de Venue
        //    var mockVenue = new Mock<Venue>(
        //        "Locatie",
        //        "Straatnaam 123, Stad",
        //        RoomType.Classroom,
        //        20,
        //        true,
        //        true,
        //        false,
        //        true
        //    );

        //    var mockEvent1 = new Mock<MeetingEvent>(
        //        "Vergadering over Connecthub",
        //        EventType.Meeting,
        //        mockEventPeriod1.Object,
        //        "Een vergadering over unittesten",
        //        mockVenue.Object,
        //        20
        //    );

        //    var mockEvent2 = new Mock<SportEvent>(
        //        "Conflicterend evenement",
        //        EventType.Meeting,
        //        mockEventPeriod2.Object,
        //        "Een ander evenement dat overlapt",
        //        mockVenue.Object,
        //        20
        //    );

        //    // Voeg de mock van Student toe aan de studentenlijst van mockEvent2 om een conflict te simuleren
        //    var studentList = new List<Student> { mockParticipant.Object }; 
        //    mockEvent2.Setup(e => e.Students).Returns(studentList.AsReadOnly()); 

        //    // Stel het event-catalogus mock in om een conflict te simuleren
        //    var mockEventCatalog = new Mock<ICatalog<Event>>();
        //    mockEventCatalog.Setup(c => c.GetItems()).Returns(new List<Event> { mockEvent2.Object });

        //    // Maak de AvailabilityChecker aan met de gemockte EventCatalog
        //    var availabilityChecker = new AvailabilityChecker(mockEventCatalog.Object);

        //    // Act
        //    var result = availabilityChecker.IsAvailable(mockParticipant.Object, mockEvent1.Object);

        //    // Assert
        //    Assert.False(result.Success);  // Verwacht dat het niet beschikbaar is vanwege een conflict
        //    Assert.Equal("Al ingeschreven voor een ander evenement op dit tijdstip.", result.Reason);
        //}

        //[Fact]
        //public void IsAvailableWorkshopEventParticipantConflictingEventReturnFalse()
        //{
        //    // Arrange

        //    // 
        //    var department = new Department(
        //        "ICT Afdeling",
        //        DepartmentType.ICT,
        //        "Gespecialiseerd in informatie- en communicatietechnologie",
        //        250, 
        //        28   
        //    );

        //    var mockParticipant = new Mock<Student>("John", "Doe", Gender.Man, Nationality.Nederland, DateTime.Today.AddYears(-25), "john.doe@example.com", department);
        //    mockParticipant.Setup(s => s.GetEmail).Returns("john.doe@example.com");

        //    var mockEventPeriod1 = new Mock<EventPeriod>(
        //        DateTime.Today.AddDays(1),
        //        TimeSpan.FromHours(9),
        //        DateTime.Today.AddDays(1),
        //        TimeSpan.FromHours(11)
        //    );

        //    var mockEventPeriod2 = new Mock<EventPeriod>(
        //        DateTime.Today.AddDays(1),
        //        TimeSpan.FromHours(10),
        //        DateTime.Today.AddDays(1),
        //        TimeSpan.FromHours(12)
        //    );

        //    // Mock de Venue
        //    var mockVenue = new Mock<Venue>(
        //        "Locatie",
        //        "Straatnaam 123, Stad",
        //        RoomType.Classroom,
        //        20,
        //        true,
        //        true,
        //        false,
        //        true
        //    );

        //    var mockEvent1 = new Mock<MeetingEvent>(
        //        "Vergadering over Connecthub",
        //        EventType.Meeting,
        //        mockEventPeriod1.Object,
        //        "Een vergadering over unittesten",
        //        mockVenue.Object,
        //        20
        //    );

        //    var mockEvent2 = new Mock<SportEvent>(
        //        "Conflicterend evenement",
        //        EventType.Meeting,
        //        mockEventPeriod2.Object,
        //        "Een ander evenement dat overlapt",
        //        mockVenue.Object,
        //        20
        //    );

        //    // Voeg de mock van Student toe aan de studentenlijst van mockEvent2 om een conflict te simuleren
        //    var studentList = new List<Student> { mockParticipant.Object };
        //    mockEvent2.Setup(e => e.Students).Returns(studentList.AsReadOnly());

        //    // Stel het event-catalogus mock in om een conflict te simuleren
        //    var mockEventCatalog = new Mock<ICatalog<Event>>();
        //    mockEventCatalog.Setup(c => c.GetItems()).Returns(new List<Event> { mockEvent2.Object });

        //    // Maak de AvailabilityChecker aan met de gemockte EventCatalog
        //    var availabilityChecker = new AvailabilityChecker(mockEventCatalog.Object);

        //    // Act
        //    var result = availabilityChecker.IsAvailable(mockParticipant.Object, mockEvent1.Object);

        //    // Assert
        //    Assert.False(result.Success); 
        //    Assert.Equal("Al ingeschreven voor een ander evenement op dit tijdstip.", result.Reason);
        //}

        //[Fact]
        //public void IsSameVenueFirstVenueNotEqualsSecondVenueReturnsFalse()
        //{
        //    // Arrange
        //    var mockVenue1 = new Mock<Venue>(
        //        "Locatie",
        //        "Straatnaam 123, Stad",
        //        RoomType.Classroom,
        //        20,
        //        true,
        //        true,
        //        false,
        //        true
        //    );

        //    var mockVenue2 = new Mock<Venue>(
        //        "Andere locatie",
        //        "Anderestraat 123, Anderestad",
        //        RoomType.Classroom,
        //        20,
        //        true,
        //        true,
        //        false,
        //        true
        //    );


        //    var mockEventCatalog = new Mock<ICatalog<Event>>();
        //    mockEventCatalog.Setup(c => c.GetItems()).Returns(new List<Event> { });
        //    var availabilityChecker = new AvailabilityChecker(mockEventCatalog.Object);

        //    // Act
        //    bool isSameVenue = availabilityChecker.IsSameVenue(mockVenue1.Object, mockVenue2.Object);

        //    // Assert
        //    Assert.False(isSameVenue);
        //}

        //[Fact]
        //public void IsSameVenueFirstvenueEqualsSecondVenueReturnsTrue()
        //{
        //    // Arrange
        //    var mockVenue1 = new Mock<Venue>(
        //        "Locatie",
        //        "Straatnaam 123, Stad",
        //        RoomType.Classroom,
        //        20,
        //        true,
        //        true,
        //        false,
        //        true
        //    );

        //    var mockVenue2 = new Mock<Venue>(
        //       "Locatie",
        //       "Straatnaam 123, Stad",
        //       RoomType.Classroom,
        //       20,
        //       true,
        //       true,
        //       false,
        //       true
        //   );


        //    var mockEventCatalog = new Mock<ICatalog<Event>>();
        //    mockEventCatalog.Setup(c => c.GetItems()).Returns(new List<Event> { });
        //    var availabilityChecker = new AvailabilityChecker(mockEventCatalog.Object);

        //    // Act
        //    bool isSameVenue = availabilityChecker.IsSameVenue(mockVenue1.Object, mockVenue2.Object);

        //    // Assert
        //    Assert.True(isSameVenue);

    }


    
}
