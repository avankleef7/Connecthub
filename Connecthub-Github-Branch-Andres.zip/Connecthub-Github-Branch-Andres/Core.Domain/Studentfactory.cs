﻿using Core.Domain.Helperclasses;
using Shared;
using System;
using System.Xml.Linq;

namespace Core.Domain
{
    /// <summary>
    /// Maakt een nieuwe Student aan na het valideren van de verstrekte gegevens. 
    /// Het controleert of de e-mail uniek is door zowel de StudentCatalog als TeacherCatalog te raadplegen.
    /// </summary>
    public class StudentFactory
    {
        private readonly DepartmentCapacityValidator departmentCapacityValidator;
        private readonly IEmailValidator emailValidator;

        public StudentFactory(IEmailValidator emailValidator)
        {
            this.departmentCapacityValidator = new DepartmentCapacityValidator();
            this.emailValidator = emailValidator;
        }

        public AddingResult CreateStudent(string firstname, string lastname, Gender gender, Nationality nationality, DateTime dateofbirth, string email, Department department, StudentCatalog studentCatalog, TeacherCatalog teacherCatalog, SpeakerCatalogus speakercatalog)
        {
            // Maak een nieuwe student aan voor validatie
            Student student = new Student(firstname, lastname, gender, nationality, dateofbirth, email, department);

            // Valideer de student met de StudentValidator
            StudentValidator studentValidator = new StudentValidator(emailValidator, departmentCapacityValidator);
            ValidationResult validationResult = studentValidator.Validate(student);
            // Als de validatie mislukt, retourneer het resultaat
            if (!validationResult.Success)
            {
                return new AddingResult(false, validationResult.Reason);
            }

            // Probeer de student toe te voegen aan het department
            AddingResult addStudentToDepartmentResult = department.TryAddStudent(student);
            // Als het toevoegen niet gelukt is, geef dat terug
            if (!addStudentToDepartmentResult.Success) return addStudentToDepartmentResult;

            // Voeg de student toe aan de studentencatalogus
            AddingResult addStudentToCatalogResult = studentCatalog.TryAddStudent(student, department.GetName);

            // Return het resultaat van het toevoegen aan de catalogus
            return addStudentToCatalogResult;
        }



    }



}
