﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public interface IParticipant
    {
        string GetFirstName { get; }
        string GetLastName { get; }
        int GetAge { get; }
        string GetEmail();
    }

}
