﻿using Infrastructure;

namespace Core.Domain
{
    public class TeacherCatalog : ITeacherRepository
    {
        private readonly TeacherRepository _teacherRepository;
        private readonly DepartmentRepository _departmentRepository;
        private readonly DepartmentCatalog _departmentCatalog;

        private List<Teacher> teachers = new List<Teacher>();

        public TeacherCatalog(TeacherRepository teacherRepository, DepartmentRepository departmentRepository, DepartmentCatalog departmentCatalog)
        {
            _teacherRepository = teacherRepository ?? throw new ArgumentNullException(nameof(teacherRepository));
            _departmentRepository = departmentRepository ?? throw new ArgumentNullException(nameof(departmentRepository));
            _departmentCatalog = departmentCatalog ?? throw new ArgumentNullException(nameof(departmentCatalog));

            // Laad docenten vanuit de database bij de initialisatie van de catalogus
            LoadTeachersFromDatabase();
        }

        private void LoadTeachersFromDatabase()
        {
            // Haal alle docenten op uit de database via de repository
            var teacherDTOs = _teacherRepository.GetAllTeachers();

            // Zet de opgehaalde docenten om naar Teacher objecten en vul de lijst
            teachers = teacherDTOs.Select(dto =>
            {
                // Haal de afdeling op via het DepartmentRepository
                string departmentName = _departmentRepository.GetDepartmentNameById(dto.DepartmentID);
                var department = _departmentCatalog.TryFindDepartmentByName(departmentName);

                // Maak een Teacher object en retourneer deze
                return new Teacher(
                    dto.FirstName,
                    dto.LastName,
                    dto.Gender,
                    dto.DateOfBirth,
                    dto.Email,
                    department
                );
            }).ToList();
        }

        public IReadOnlyList<Teacher> GetTeachers() => this.teachers;

        public AddingResult TryAddTeacher(Teacher teacher, string departmentName)
        {
            if (teacher == null)
                throw new ArgumentNullException(nameof(Teacher), "Docent kan niet null zijn, niet toegevoegd");

            // Zoek de juiste DepartmentId via de DepartmentRepository
            int departmentId = _departmentRepository.GetDepartmentIdByName(departmentName);

            if (departmentId == 0)
            {
                return new AddingResult(false, "Department niet gevonden.");
            }

            // Maak een TeacherDTO aan van de docent
            var teacherDTO = new TeacherDTO(
                departmentId,
                teacher.GetFirstName,
                teacher.GetLastName,
                teacher.GetDateOfBirth(),
                teacher.GetGender,
                teacher.GetEmail()
            );

            // Voeg de docent toe aan de database via de TeacherRepository
            _teacherRepository.AddTeacher(teacherDTO, departmentId);

            // Voeg de docent toe aan de lokale lijst in de catalogus
            teachers.Add(teacher);

            return new AddingResult(true, "Docent succesvol toegevoegd.");
        }

        public RemovingResult TryRemoveTeacher(string email, string departmentName)
        {
            if (string.IsNullOrWhiteSpace(email))
                return new RemovingResult(false, "Email kan niet leeg zijn, verwijdering niet geslaagd.");

            var teacher = FindTeacherByEmail(email);

            if (teacher == null)
                return new RemovingResult(false, "Docent niet gevonden in de catalogus.");

            int departmentId = _departmentRepository.GetDepartmentIdByName(departmentName);

            if (departmentId == 0)
                return new RemovingResult(false, "Department niet gevonden.");

            var department = _departmentCatalog.TryFindDepartmentByName(departmentName);

            // Verwijder de docent uit de catalogus
            if (teachers.Remove(teacher))
            {
                // Maak een TeacherDTO voor de docent die we willen verwijderen
                var teacherDTO = new TeacherDTO(
                    departmentId,
                    teacher.GetFirstName,
                    teacher.GetLastName,
                    teacher.GetDateOfBirth(),
                    teacher.GetGender,
                    teacher.GetEmail()
                );

                // Verwijder de docent uit de database
                _teacherRepository.RemoveTeacher(teacherDTO);

                return new RemovingResult(true, "Docent succesvol verwijderd.");
            }

            return new RemovingResult(false, "Docent niet gevonden in de catalogus.");
        }

        public Teacher FindTeacherByEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                throw new ArgumentException("Email mag niet leeg zijn.", nameof(email));

            // Zoek de docent op basis van e-mail
            Teacher teacher = teachers.FirstOrDefault(t => t.GetEmail().Equals(email, StringComparison.OrdinalIgnoreCase));

            if (teacher == null)
            {
                throw new InvalidOperationException("Geen docent gevonden met het opgegeven e-mailadres.");
            }

            return teacher;
        }

        internal IEnumerable<IParticipant> GetAllParticipants()
        {
            return teachers.Cast<IParticipant>().ToList();
        }
    }
}
