﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public interface IUnenroll
    {
        UnenrollmentResult UnenrollStudent(Student student, Event eventItem);
        UnenrollmentResult UnenrollTeacher(Teacher teacher, Event eventItem);
        UnenrollmentResult UnenrollSpeaker(Speaker speaker, Event eventItem);

    }
}
