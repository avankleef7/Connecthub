﻿using Shared;
using System;

namespace Core.Domain
{
    public class EventBuilder
    {
        private string title;
        private Department department;
        private DateTime date;
        private TimeSpan startingTime;
        private DateTime enddate; 
        private TimeSpan endingTime;
        private string description;
        private Venue venue;
        private int maxCapacity;
        private EventType eventType;

        // Setters voor de gemeenschappelijke eigenschappen
        public EventBuilder SetTitle(string title)
        {
            if (string.IsNullOrWhiteSpace(title))
                throw new ArgumentException("Titel mag niet leeg zijn.", nameof(title));

            this.title = title;
            return this;
        }

        public EventBuilder SetDate(DateTime date)
        {
            if (date <= DateTime.Now)
                throw new ArgumentOutOfRangeException(nameof(date), "Datum moet in de toekomst liggen.");

            this.date = date;
            return this;
        }

        public EventBuilder SetStartTime(TimeSpan startingTime)
        {
            if (startingTime == default)
                throw new ArgumentException("Starttijd moet worden ingesteld.", nameof(startingTime));

            this.startingTime = startingTime;
            return this;
        }

        public EventBuilder SetEndTime(TimeSpan endingTime)
        {
            if (endingTime == default)
                throw new ArgumentException("Eindtijd moet worden ingesteld.", nameof(endingTime));

            this.endingTime = endingTime;
            return this;
        }

        public EventBuilder SetEndDate(DateTime enddate)  // Gebruik DateTime voor einddatum
        {
            if (enddate <= date)  // Controleer of einddatum na de startdatum is
                throw new ArgumentOutOfRangeException(nameof(enddate), "Einddatum moet later zijn dan de startdatum.");

            this.enddate = enddate;
            return this;
        }

        public EventBuilder SetDescription(string description)
        {
            if (string.IsNullOrWhiteSpace(description))
                throw new ArgumentException("Beschrijving mag niet leeg zijn.", nameof(description));

            this.description = description;
            return this;
        }

        public EventBuilder SetVenue(Venue venue)
        {
            if (venue == null)
                throw new ArgumentNullException(nameof(venue), "Locatie mag niet null zijn.");

            this.venue = venue;
            return this;
        }

        public EventBuilder SetMaxStudentCapacity(int capacity)
        {
            if (capacity <= 0)
                throw new ArgumentOutOfRangeException(nameof(capacity), "Maximale capaciteit van studenten moet groter zijn dan nul.");

            this.maxCapacity = capacity;
            return this;
        }

        public EventBuilder SetEventType(EventType eventType)
        {
            this.eventType = eventType;
            return this;
        }

        public EventBuilder SetDepartment(Department department)
        {
            if (department == null)
                throw new ArgumentNullException(nameof(department), "Afdeling mag niet null zijn.");

            this.department = department;
            return this;
        }

        public AddingResult Build(EventCatalog eventCatalog)
        {
            // Validatie bij het bouwen van het Event
            if (string.IsNullOrEmpty(title))
                throw new InvalidOperationException("Titel moet worden ingesteld voordat het evenement wordt gebouwd.");
            if (date == default)
                throw new InvalidOperationException("Datum moet worden ingesteld voordat het evenement wordt gebouwd.");
            if (startingTime == default)
                throw new InvalidOperationException("Starttijd moet worden ingesteld voordat het evenement wordt gebouwd.");
            if (endingTime == default)
                throw new InvalidOperationException("Eindtijd moet worden ingesteld voordat het evenement wordt gebouwd.");
            if (startingTime >= endingTime)
                throw new InvalidOperationException("Starttijd moet eerder zijn dan de eindtijd.");
            if (enddate == default)
                throw new InvalidOperationException("Einddatum moet worden ingesteld voordat het evenement wordt gebouwd.");
            if (enddate <= date)
                throw new InvalidOperationException("Einddatum moet later zijn dan de startdatum.");
            if (venue == null)
                throw new InvalidOperationException("Locatie moet worden ingesteld voordat het evenement wordt gebouwd.");

            // Maak een event op basis van het type
            Event createdEvent;
            switch (eventType)
            {
                case EventType.Workshop:
                    createdEvent = new WorkshopEvent(title, EventType.Workshop, department, date, startingTime, enddate, endingTime, description, venue, maxCapacity);
                    break;
                case EventType.Sport:
                    createdEvent = new SportEvent(title, EventType.Sport, department, date, startingTime, enddate, endingTime, description, venue, maxCapacity);
                    break;
                case EventType.Meeting:
                default:
                    createdEvent = new MeetingEvent(title, EventType.Meeting, department, date, startingTime, enddate, endingTime, description, venue, maxCapacity);
                    break;
            }

            // Event opslaan in de catalogus
            eventCatalog.TryAddEventToCatalog(createdEvent);
            return new AddingResult(true, "Evenement succesvol aangemaakt");
        }
    }
}
