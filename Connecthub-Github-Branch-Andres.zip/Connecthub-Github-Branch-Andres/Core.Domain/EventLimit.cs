﻿namespace Core.Domain
{
    public class EventLimit
    {
        public int MaxEvents { get; private set; }

        public EventLimit(int maxEvents)
        {
            MaxEvents = maxEvents;
        }

    
        public virtual int GetEnrolledEventCount(IParticipant participant, EventCatalog eventCatalog)
        {
            // Tel het aantal evenementen waaraan de deelnemer is ingeschreven
            return eventCatalog.GetEvents
                .Where(e => e.Students.Contains(participant) || e.Teachers.Contains(participant) || e.Speakers.Contains(participant))
                .Count();
        }

       
        public virtual EnrollmentResult HasReachedLimit(IParticipant participant, EventCatalog eventCatalog)
        {
           
            int currentEventCount = GetEnrolledEventCount(participant, eventCatalog);

            if (currentEventCount >= MaxEvents)
            {
                return new EnrollmentResult(false, $"Je hebt je al voor {currentEventCount} evenementen ingeschreven, wat de limiet van {MaxEvents} overschrijdt.");
            }

            return new EnrollmentResult(true, $"Je hebt je voor {currentEventCount} evenementen ingeschreven. Je kunt je nog inschrijven voor meer evenementen.");
        }
    }
}
