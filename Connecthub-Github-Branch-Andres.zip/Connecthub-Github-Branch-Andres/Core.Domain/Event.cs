﻿using System;
using System.Collections.Generic;
using Shared;

namespace Core.Domain
{
    public abstract class Event
    {
        private string title;
        private EventType eventType;
        private Department department;
        private Status status;
        private DateTime date;
        private TimeSpan startingtime;
        private DateTime enddate;
        private TimeSpan endingtime;
        private string description;

        private Venue venue;
        private List<Speaker> enrolledSpeakers;
        private List<Student> enrolledStudents;
        private List<Teacher> enrolledTeachers;
        private List<Speaker> unenrolledSpeakers;
        private List<Student> unenrolledStudents;
        private List<Teacher> unenrolledTeachers;

        // Properties
        public string GetTitle => title;
        public EventType GetEventType => eventType;
        public Department GetDepartment => department;
        public Status GetStatus => status;
        public DateTime GetDate => date;
        public TimeSpan GetStartTime => startingtime;
        public DateTime GetEndDate => enddate;  
        public TimeSpan GetEndTime => endingtime;

        public string GetDescription => description;
        public IReadOnlyList<Speaker> Speakers => enrolledSpeakers; 
        public IReadOnlyList<Student> Students => enrolledStudents;
        public IReadOnlyList<Teacher> Teachers => enrolledTeachers;
        public IReadOnlyList<Speaker> unrolledSpeakers => unenrolledSpeakers;
        public IReadOnlyList<Student> unrolledStudents => unenrolledStudents;
        public IReadOnlyList<Teacher> unrolledTeachers => unenrolledTeachers;
        public Venue Venue => venue;

        // Constructor met validatie
        protected Event(string title, EventType eventType, Department department, DateTime date, TimeSpan starttime, DateTime enddate, TimeSpan endtime, string description, Venue venue)
        {
            if (string.IsNullOrWhiteSpace(title))
                throw new ArgumentNullException(nameof(title), "Titel kan niet leeg of null zijn.");
            //if (date < DateTime.Now)
            //    throw new ArgumentOutOfRangeException(nameof(date), "Evenementdatum moet in de toekomst liggen.");
            // Validatie voor einddatum
            if (enddate < date)
                throw new ArgumentOutOfRangeException(nameof(enddate), "Einddatum moet later zijn dan de startdatum.");
            // Validatie voor eindtijd (moet na de starttijd liggen)
            if (endtime <= starttime)
                throw new ArgumentOutOfRangeException(nameof(endtime), "Eindtijd moet na starttijd liggen.");
            if (endtime < TimeSpan.Zero || endtime >= TimeSpan.FromHours(24))
                throw new ArgumentOutOfRangeException(nameof(endtime), "Eindtijd moet tussen 00:00 en 23:59 zijn.");

            if (string.IsNullOrWhiteSpace(description))
                throw new ArgumentNullException(nameof(description), "Beschrijving kan niet leeg of null zijn.");
            if (venue == null)
                throw new ArgumentNullException(nameof(venue), "Locatie kan niet null zijn.");

            this.title = title;
            this.eventType = eventType;
            this.department = department;
            this.status = Status.Inactive;
            this.date = date;
            this.startingtime = starttime;
            this.enddate = enddate;
            this.endingtime = endtime;
            this.description = description;
            this.venue = venue;
            this.enrolledSpeakers = new List<Speaker>();
            this.enrolledStudents = new List<Student>();
            this.enrolledTeachers = new List<Teacher>();
            this.unenrolledSpeakers = new List<Speaker>();
            this.unenrolledStudents = new List<Student>();
            this.unenrolledTeachers = new List<Teacher>();
        }

        // Abstract method for checking event capacity
        public abstract bool IsFull();

        public ChangingStatusResult ChangingStatus(Status newStatus)
        {
            this.status = newStatus;
            return new ChangingStatusResult(true, "Status succesvol gewijzigd."); // Succesvolle wijziging
        }

        // Methode om studenten toe te voegen, met capaciteitscontrole
        public virtual void TryAddStudent(Student student)
        {
            if (student == null)
                throw new ArgumentNullException(nameof(student), "Student kan niet null zijn.");
            if (IsFull())
                throw new InvalidOperationException("Kan student niet toevoegen. Evenement is vol.");

            enrolledStudents.Add(student);
        }

        // Methode om docenten toe te voegen, met capaciteitscontrole
        public virtual void TryAddTeacher(Teacher teacher)
        {
            if (teacher == null)
                throw new ArgumentNullException(nameof(teacher), "Docent kan niet null zijn.");
            if (IsFull())
                throw new InvalidOperationException("Kan docent niet toevoegen. Evenement is vol.");

            enrolledTeachers.Add(teacher);
        }

        // Methode om sprekers toe te voegen
        public virtual void TryAddSpeaker(Speaker speaker)
        {
            if (speaker == null)
                throw new ArgumentNullException(nameof(speaker), "Spreker kan niet null zijn.");

            enrolledSpeakers.Add(speaker);
        }

        // Verander de TryRemoveStudent naar een boolean return
        public virtual bool TryRemoveStudent(Student student)
        {
            if (student == null)
                throw new ArgumentNullException(nameof(student), "Student kan niet null zijn.");

            return enrolledStudents.Remove(student);
        }

        public virtual bool TryRemoveTeacher(Teacher teacher)
        {
            if (teacher == null)
                throw new ArgumentNullException(nameof(teacher), "Docent kan niet null zijn.");

            return enrolledTeachers.Remove(teacher);
        }

        public virtual bool TryRemoveSpeaker(Speaker speaker)
        {
            if (speaker == null)
                throw new ArgumentNullException(nameof(speaker), "Spreker kan niet null zijn.");

            return enrolledSpeakers.Remove(speaker);
        }
        public virtual void TryAddUnenrolledStudent(Student student)
        {
            if (student == null)
                throw new ArgumentNullException(nameof(student), "Student kan niet null zijn.");

            if (!unenrolledStudents.Contains(student))
            {
                unenrolledStudents.Add(student);
            }
            
           
        }

        public virtual void TryAddUnenrolledTeacher(Teacher teacher)
        {
            if (teacher == null)
                throw new ArgumentNullException(nameof(teacher), "Docent kan niet null zijn.");

            if (!unenrolledTeachers.Contains(teacher))
            {
                unenrolledTeachers.Add(teacher);
            }
        }

        public virtual void TryAddUnenrolledSpeaker(Speaker speaker)
        {
            if (speaker == null)
                throw new ArgumentNullException(nameof(speaker), "Spreker kan niet null zijn.");

            if (!unenrolledSpeakers.Contains(speaker))
            {
                unenrolledSpeakers.Add(speaker);
            }
           
        }

        public virtual bool TryRemoveUnenrolledStudent(Student student)
        {
            if (student == null)
                throw new ArgumentNullException(nameof(student), "Student kan niet null zijn.");

            
            return unenrolledStudents.Remove(student);
        }

        public virtual bool TryRemoveUnenrolledTeacher(Teacher teacher)
        {
            if (teacher == null)
                throw new ArgumentNullException(nameof(teacher), "Docent kan niet null zijn.");

            
            return unenrolledTeachers.Remove(teacher);
        }

        public virtual bool TryRemoveUnenrolledSpeaker(Speaker speaker)
        {
            if (speaker == null)
                throw new ArgumentNullException(nameof(speaker), "Spreker kan niet null zijn.");

            
            return unenrolledSpeakers.Remove(speaker);
        }

        public IEnumerable<IParticipant> GetAllEnrolledParticipants()
        {
            // Combineer de ingeschreven studenten, docenten en sprekers in één lijst van IParticipant
            return enrolledStudents.Cast<IParticipant>()
                .Concat(enrolledTeachers.Cast<IParticipant>())
                .Concat(enrolledSpeakers.Cast<IParticipant>());
        }

        public IEnumerable<IParticipant> GetAllUnenrolledParticipants()
        {
            // Combineer de uitgeschreven studenten, docenten en sprekers in één lijst van IParticipant
            return unenrolledStudents.Cast<IParticipant>()
                .Concat(unenrolledTeachers.Cast<IParticipant>())
                .Concat(unenrolledSpeakers.Cast<IParticipant>());
        }
    }
}
