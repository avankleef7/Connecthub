﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Core.Domain
{
    /// <summary>
    /// Deze klassen is gemaakt om alle Catalogussen samen te voegen
    /// Door deze Apart te maken wordt er rekening gehouden met single responsibility
    /// </summary>
    public class ParticipantService : IParticipantService
    {
        private readonly StudentCatalog _studentCatalog;
        private readonly TeacherCatalog _teacherCatalog;
        private readonly SpeakerCatalogus _speakerCatalog;
       
        public ParticipantService(StudentCatalog studentCatalog, TeacherCatalog teacherCatalog, SpeakerCatalogus speakerCatalog)
        {
            _studentCatalog = studentCatalog;
            _teacherCatalog = teacherCatalog;
            _speakerCatalog = speakerCatalog;
           
        }

        public IEnumerable<IParticipant> GetParticipants()
        {
            // Combineer de studenten, docenten en sprekers in één lijst van IParticipant
            return _studentCatalog.GetAllParticipants()
                .Concat(_teacherCatalog.GetAllParticipants())
                .Concat(_speakerCatalog.GetAllParticipants());
        }

    }
}
