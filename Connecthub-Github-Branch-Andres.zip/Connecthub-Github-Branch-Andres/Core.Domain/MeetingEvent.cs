﻿using Shared;
using System;

namespace Core.Domain
{
    public class MeetingEvent : Event
    {
        private int maxCapacity;
        public int MaxCapacity => maxCapacity;

        public MeetingEvent(string title, EventType eventType, Department department, DateTime date, TimeSpan startingTime, DateTime enddate, TimeSpan endingTime, string description, Venue venue, int maxCapacity)
            : base(title, eventType, department, date, startingTime, enddate, endingTime, description, venue)
        {
            if (maxCapacity <= 0)
                throw new ArgumentOutOfRangeException(nameof(maxCapacity), "Max capacity must be greater than zero.");

            if (startingTime >= endingTime)
                throw new ArgumentException("Starting time must be earlier than ending time.");

            this.maxCapacity = maxCapacity;
        }

        public override bool IsFull()
        {
            // Voor een meeting event tellen zowel studenten als leraren mee voor de capaciteit
            return Students.Count + Teachers.Count >= maxCapacity;
        }
    }
}
