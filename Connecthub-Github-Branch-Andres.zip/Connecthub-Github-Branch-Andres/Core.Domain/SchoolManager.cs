﻿using Core.Domain;
using Core.DTO;
using Infrastructure;
using Microsoft.Extensions.Configuration;

public class SchoolManager
{
    private static School _instance;
    private static IConfiguration _configuration; 

    public static void Initialize(IConfiguration configuration)
    {
        _configuration = configuration;
        var schoolRepository = new SchoolRepository(_configuration.GetConnectionString("DefaultConnection"));

    
        if (!schoolRepository.SchoolExists("Fontys Hogeschool"))
        {
            // Voeg de school toe
            var schoolDTO = new SchoolDTO("Fontys Hogeschool", new List<DepartmentDTO>(), new List<VenueDTO>());
            schoolRepository.AddSchool(schoolDTO);

        }




    }

    public static School Instance
    {
        get
        {
            if (_instance == null)
            {
                if (_configuration == null)
                {
                    throw new InvalidOperationException("SchoolManager is not initialized. Call Initialize with a valid IConfiguration.");
                }

                // Connectionstring ophalen uit configuratie
                var connectionString = _configuration.GetConnectionString("DefaultConnection");

                // School object initialiseren (bijvoorbeeld met connectionString)
                _instance = new School("Fontys Hogeschool", connectionString);
            }
            return _instance;
        }
    }

    private SchoolManager() { }
}
