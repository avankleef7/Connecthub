﻿using Shared;
using System;

namespace Core.Domain
{
    public class SportEvent : Event
    {
        private int maxCapacity;
        public int MaxCapacity => maxCapacity;

        public SportEvent(string title, EventType eventType, Department department, DateTime date, TimeSpan startingTime, DateTime enddate, TimeSpan endingTime, string description, Venue venue, int maxCapacity)
            : base(title, eventType, department, date, startingTime, enddate, endingTime, description, venue)
        {
            if (maxCapacity <= 0)
                throw new ArgumentOutOfRangeException(nameof(maxCapacity), "Max capacity must be greater than zero.");

            if (startingTime >= endingTime)
                throw new ArgumentException("Starting time must be earlier than ending time.");

            this.maxCapacity = maxCapacity;
        }

        public override bool IsFull()
        {
            return Students.Count >= maxCapacity;
        }
    }
}
