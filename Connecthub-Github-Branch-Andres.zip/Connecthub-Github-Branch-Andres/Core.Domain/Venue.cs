﻿using Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public class Venue
    {
        private string LocationName;
        private string Adress;
        private RoomType RoomTypes;
        private int Capacity;
        private bool HasElectricity;
        private bool HasProjectorOrScreen;
        private bool HasStage;
        private bool IsWheelChairAccessible;

        public string GetLocationName => LocationName;
        public string GetAdress => Adress;
        public int GetCapacity => Capacity;
        public RoomType GetRoomType => RoomTypes;
        public bool GetHasElectricity => HasElectricity;
        public bool GetHasProjectorOrScreen => HasProjectorOrScreen;
        public bool GetHasStage => HasStage;
        public bool GetIsWheelChairAccessible => IsWheelChairAccessible;

        public Venue(string locationname, string adress, RoomType roomtype, int capacity, bool haselectricity, bool hasprojectorscreen, bool hasstage, bool wheelchairaccessible)
        {
            // Validatie voor locatie naam
            if (string.IsNullOrWhiteSpace(locationname)) throw new ArgumentNullException(nameof(locationname), "Locatienaam mag niet leeg zijn of alleen uit spaties bestaan.");
            // Validatie voor capaciteit
            if (capacity <= 0) throw new ArgumentOutOfRangeException(nameof(capacity), "Capaciteit moet een positief getal zijn.");

            this.LocationName = locationname;
            this.Adress = adress;
            this.RoomTypes = roomtype;
            this.Capacity = capacity;
            this.HasElectricity = haselectricity;
            this.HasProjectorOrScreen = hasprojectorscreen;
            this.HasStage = hasstage;
            this.IsWheelChairAccessible = wheelchairaccessible;
        }

        // Optionele methode om capaciteit aan te passen met validatie
        public void UpdateCapacity(int newCapacity)
        {
            if (newCapacity <= 0)
                throw new ArgumentOutOfRangeException(nameof(newCapacity), "Capaciteit moet een positief getal zijn.");
            this.Capacity = newCapacity;
        }

        public override string ToString()
        {
            return $"Locatie: {LocationName}, Adres: {Adress}, Capaciteit: {Capacity}, Kamertype: {RoomTypes}, Elektriciteit: {HasElectricity}, Projector/Scherm: {HasProjectorOrScreen}, Podium: {HasStage}, Rolstoeltoegankelijk: {IsWheelChairAccessible}";
        }

        public void UpdateFacilities(bool hasElectricity, bool hasProjectorOrScreen, bool hasStage, bool isWheelChairAccessible)
        {
            if (!hasElectricity && hasProjectorOrScreen)
            {
                throw new InvalidOperationException("Een scherm/projector kan niet werken zonder elektriciteit.");
            }

            this.HasElectricity = hasElectricity;
            this.HasProjectorOrScreen = hasProjectorOrScreen;
            this.HasStage = hasStage;
            this.IsWheelChairAccessible = isWheelChairAccessible;
        }
    }
}
