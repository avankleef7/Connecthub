﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public abstract class PersonValidator<T> : IValidator<T>
    {
        private readonly IEmailValidator emailValidator;
        private readonly DepartmentCapacityValidator departmentCapacityValidator;

        public PersonValidator(IEmailValidator emailvalidator, DepartmentCapacityValidator departmentvalidator)
        {
            this.emailValidator = emailvalidator;
            this.departmentCapacityValidator = departmentvalidator;
        }

        public abstract ValidationResult Validate(T entity);
    }
}
