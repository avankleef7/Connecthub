﻿using Core.Domain.Helperclasses;
using Shared;
using System;

namespace Core.Domain
{
    /// <summary>
    /// Maakt een nieuwe Teacher aan na het valideren van de verstrekte gegevens.
    /// Het controleert of de e-mail uniek is door zowel de TeacherCatalog als andere catalogussen te raadplegen.
    /// </summary>
    public class TeacherService
    {
        private readonly DepartmentCapacityValidator departmentCapacityValidator;
        private readonly IEmailValidator emailValidator;

        public TeacherService(IEmailValidator emailValidator)
        {
            this.departmentCapacityValidator = new DepartmentCapacityValidator();
            this.emailValidator = emailValidator;
        }

        public AddingResult CreateTeacher(string firstname, string lastname, Gender gender, DateTime dateofbirth, string email, Department department, TeacherCatalog teacherCatalog, StudentCatalog studentCatalog, SpeakerCatalogus speakercatalog)
        {
            // Maak een nieuwe teacher aan voor validatie
            Teacher teacher = new Teacher(firstname, lastname, gender, dateofbirth, email, department);

            // Valideer de teacher met de TeacherValidator
            TeacherValidator teacherValidator = new TeacherValidator(emailValidator, departmentCapacityValidator);
            ValidationResult validationResult = teacherValidator.Validate(teacher);

            // Als de validatie mislukt, retourneer het resultaat
            if (!validationResult.Success)
            {
                return new AddingResult(false, validationResult.Reason);
            }

            // Probeer de teacher toe te voegen aan het department
            AddingResult addTeacherResult = department.TryAddTeacher(teacher);
            // Als het toevoegen niet gelukt is, geef dat terug
            if (!addTeacherResult.Success)
                return addTeacherResult;

            // Voeg de teacher toe aan de teachercatalogus
            AddingResult addTeachertoCatalog = teacherCatalog.TryAddTeacher(teacher, department.GetName);

            return new AddingResult(true, "Teacher is succesvol aangemaakt.");
        }

    }
}
