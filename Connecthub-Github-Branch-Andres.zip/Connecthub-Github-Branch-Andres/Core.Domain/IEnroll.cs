﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public interface IEnroll
    {

        EnrollmentResult EnrollStudent(Student student, Event eventItem);
        EnrollmentResult EnrollTeacher(Teacher teacher, Event eventItem);
        EnrollmentResult EnrollSpeaker(Speaker speaker, Event eventItem);
        


    }
}
