﻿using Core.Domain;
using Core.DTO;
using Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;

public class DepartmentCatalog
{
    private readonly DepartmentRepository _departmentRepository;
    private readonly SchoolRepository _schoolRepository;
    private List<Department> departments = new List<Department>();

    public DepartmentCatalog(DepartmentRepository departmentRepository, SchoolRepository schoolRepository)
    {
        _departmentRepository = departmentRepository ?? throw new ArgumentNullException(nameof(departmentRepository));
        _schoolRepository = schoolRepository ?? throw new ArgumentNullException(nameof(schoolRepository));

        // Laad afdelingen uit de database bij initialisatie
        LoadDepartmentsFromDatabase();
    }

    private void LoadDepartmentsFromDatabase()
    {
        // Haal de afdelingen op via de repository
        var departmentDTOs = _departmentRepository.GetAllDepartments();

        // Zet de opgehaalde DTO's om naar Department objecten
        departments = departmentDTOs.Select(dto => new Department(
            dto.Name,
            dto.DepartmentType,
            dto.Description,
            dto.StudentCapacity,
            dto.TeacherCapacity
        )).ToList();
    }

    public IReadOnlyList<Department> GetDepartments => departments.AsReadOnly();

    public AddingResult TryAddDepartment(Department department, string schoolName)
    {
        if (department == null)
            throw new ArgumentNullException(nameof(department), "Afdeling mag niet null zijn.");

        // Verkrijg het SchoolId via de SchoolRepository
        int schoolId = _schoolRepository.GetSchoolIdByName(schoolName);

        if (schoolId == 0)
        {
            return new AddingResult(false, "School niet gevonden.");
        }

        // Maak de DepartmentDTO aan met de verkregen SchoolId
        var departmentDTO = new DepartmentDTO(
            schoolId,
            department.GetName,
            department.GetDescription,
            department.GetStudentCapacity,
            department.GetTeacherCapacity,
            department.GetDepartmentType
        );

        // Voeg de afdeling toe aan de database via de repository
        _departmentRepository.AddDepartment(departmentDTO);

        // Voeg de afdeling toe aan de lokale lijst
        departments.Add(department);

        return new AddingResult(true, "Afdeling succesvol toegevoegd.");
    }

    public RemovingResult TryRemoveDepartment(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentNullException(nameof(name), "Afdelingsnaam mag niet leeg of null zijn.");

        // Zoek de afdeling op naam
        Department department = TryFindDepartmentByName(name);

        if (department != null)
        {
            // Verwijder de afdeling uit de database
            _departmentRepository.RemoveDepartment(name);

            // Verwijder de afdeling uit de lokale lijst
            departments.Remove(department);

            return new RemovingResult(true, "Afdeling succesvol verwijderd.");
        }

        return new RemovingResult(false, "Afdeling niet gevonden.");
    }

    public Department TryFindDepartmentByName(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentNullException(nameof(name), "Afdelingsnaam mag niet leeg of null zijn.");

        // Zoek de afdeling op naam in de lijst
        return departments.FirstOrDefault(d => d.GetName == name);
    }
}
