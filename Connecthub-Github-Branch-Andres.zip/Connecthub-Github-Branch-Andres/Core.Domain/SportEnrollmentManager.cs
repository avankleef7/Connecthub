﻿using Core.Domain;

public class SportEnrollmentManager : EnrollmentManager
{
    public SportEnrollmentManager(
        EventCatalog eventCatalog,
        AvailabilityChecker availabilityChecker,
        LimitEventService limitEventService)
        : base(eventCatalog, availabilityChecker, limitEventService)
    {
    }

    public override EnrollmentResult EnrollStudent(Student student, Event eventItem)
    {
        // Controleer of het evenement een SportEvent is
        if (!(eventItem is SportEvent))
        {
            return new EnrollmentResult(false, "Dit is geen sportevenement.");
        }

        // Controleer of de student van het Sport department is
        if (!student.GetDepartment.Equals("Gezondheid en Sport"))
        {
            return new EnrollmentResult(false, "Student moet van afdeling Gezondheid en Sport zijn om zich in te schrijven voor een sportevenement.");
        }

        return base.EnrollStudent(student, eventItem);
    }

    public override EnrollmentResult EnrollTeacher(Teacher teacher, Event eventItem)
    {
        // Controleer of het evenement een SportEvent is
        if (!(eventItem is SportEvent))
        {
            return new EnrollmentResult(false, "Dit is geen sportevenement.");
        }

        // Controleer of de docent van het Sport department is
        if (!teacher.GetDepartment.Equals("Gezondheid en Sport"))
        {
            return new EnrollmentResult(false, "Docent moet van afdeling Gezondheid en Sport zijn om zich in te schrijven voor een sportevenement.");
        }

        return base.EnrollTeacher(teacher, eventItem);
    }
}
