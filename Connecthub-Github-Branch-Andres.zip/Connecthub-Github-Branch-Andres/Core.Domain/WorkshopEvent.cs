﻿using Shared;
using System;

namespace Core.Domain
{
    public class WorkshopEvent : Event
    {
        private int maxCapacity;
        public int MaxCapacity => maxCapacity;

        public WorkshopEvent(string title, EventType eventType, Department department, DateTime date, TimeSpan startingTime, DateTime enddate, TimeSpan endingTime, string description, Venue venue, int maxCapacity)
            : base(title, eventType, department, date, startingTime, enddate, endingTime, description, venue)
        {
            if (maxCapacity <= 0)
                throw new ArgumentOutOfRangeException(nameof(maxCapacity), "Maximale capaciteit moet groter zijn dan nul.");

            if (startingTime >= endingTime)
                throw new ArgumentException("De starttijd moet vóór de eindtijd liggen.");

            this.maxCapacity = maxCapacity;
        }

        public override bool IsFull()
        {
            return Students.Count >= maxCapacity;
        }
    }
}
