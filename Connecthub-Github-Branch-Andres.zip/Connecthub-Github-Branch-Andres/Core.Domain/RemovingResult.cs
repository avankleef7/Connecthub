﻿using System;

namespace Core.Domain
{
    public class RemovingResult : Result
    {
        public RemovingResult(bool success, string reason) : base(success, reason, success ? "Success" : "Failure") { }

     
    }
}
