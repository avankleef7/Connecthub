﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Core.Domain
{
    public abstract class SearchService<T, TFilter>
    {
        protected IEnumerable<T> SearchItems;

        protected SearchService(IEnumerable<T> items)
        {
            SearchItems = items;
        }

        public IReadOnlyList<T> Search(string searchTerm, TFilter filterType) 
        {
            

            var filteredItems = Filter(searchTerm, filterType);

            return filteredItems.OrderBy(GetSortKey).ToList().AsReadOnly();
        }

        protected abstract IEnumerable<T> Filter(string searchTerm, TFilter filterType); 

        protected abstract string GetSortKey(T item);
    }
}
