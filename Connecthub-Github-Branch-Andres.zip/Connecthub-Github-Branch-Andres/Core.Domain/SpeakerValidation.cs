﻿using Core.Domain.Helperclasses;
using Shared;
using System;

namespace Core.Domain
{
    public class SpeakerValidator : PersonValidator<Speaker>
    {
        private readonly IEmailValidator emailValidator;
        private readonly DepartmentCapacityValidator departmentCapacityValidator;

        public SpeakerValidator(IEmailValidator emailValidator, DepartmentCapacityValidator departmentCapacityValidator)
            : base(emailValidator, departmentCapacityValidator)
        {
            this.emailValidator = emailValidator;
            this.departmentCapacityValidator = departmentCapacityValidator;
        }

        public override ValidationResult Validate(Speaker speaker)
        {
            // Controleer op null
            if (speaker == null)
            {
                return new ValidationResult(false, "Speaker kan niet null zijn.");
            }

            // Validatie voor voornaam
            if (string.IsNullOrWhiteSpace(speaker.GetFirstName))
            {
                return new ValidationResult(false, "Voornaam kan niet leeg of null zijn.");
            }

            // Validatie voor achternaam
            if (string.IsNullOrWhiteSpace(speaker.GetLastName))
            {
                return new ValidationResult(false, "Achternaam kan niet leeg of null zijn.");
            }

            // Validatie voor geboortedatum
            if (speaker.GetDateOfBirth() >= DateTime.Now)
            {
                return new ValidationResult(false, "Geboortedatum moet in het verleden liggen.");
            }

            // Validatie voor e-mail
            if (string.IsNullOrWhiteSpace(speaker.GetEmail()) || !IsEmailValid.IsValidEmail(speaker.GetEmail()))
            {
                return new ValidationResult(false, "E-mail is ongeldig.");
            }

			// Controleer of de e-mail uniek is
			var emailResult = emailValidator.IsEmailUnique(speaker.GetEmail());
			
            if (emailResult == null || !emailResult.Success)
			{
				return new ValidationResult(false, emailResult.Reason);
			}

			// Als alle validaties zijn geslaagd, geef een succesvolle validatieresultaat terug
	 		return new ValidationResult(true, "Validatie van de spreker is geslaagd.");
        }
    }
}
