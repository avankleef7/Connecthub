﻿using System;

namespace Core.Domain.Helperclasses
{
    public static class DateTimeHelper
    {
        public static int CalculateDaysBetweenDates(DateTime start, DateTime end)
        {
            return (end - start).Days;
        }

        public static int CalculateYearsToDate(DateTime date)
        {
            var today = DateTime.Today;
            var years = today.Year - date.Year;

            if (date > today.AddYears(-years)) years--;

            return years;
        }
    }
}
