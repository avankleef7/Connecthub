﻿using Shared;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Core.Domain
{
    public class ParticipantSearchService : SearchService<IParticipant, ParticipantType>
    {
        private readonly ParticipantService _participantService;

        public ParticipantSearchService(ParticipantService participantService)
            : base(participantService.GetParticipants())
        {
            _participantService = participantService;
        }

        protected override IEnumerable<IParticipant> Filter(string searchTerm, ParticipantType participantType)
        {
            // Eerst filteren op basis van de participant type
            var filteredByType = FilterByParticipantType(participantType);

            // Vervolgens filteren op basis van de zoekterm
            return filteredByType.Where(p =>
                p.GetFirstName.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                p.GetLastName.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                p.GetEmail().Contains(searchTerm, StringComparison.OrdinalIgnoreCase));
        }

        private IEnumerable<IParticipant> FilterByParticipantType(ParticipantType participantType)
        {
            return participantType switch
            {
                ParticipantType.All => SearchItems,
                ParticipantType.Student => SearchItems.OfType<Student>(),
                ParticipantType.Teacher => SearchItems.OfType<Teacher>(),
                ParticipantType.Speaker => SearchItems.OfType<Speaker>(),
                _ => throw new ArgumentOutOfRangeException(nameof(participantType), participantType, null)
            };
        }

        protected override string GetSortKey(IParticipant participant)
        {
            return participant.GetFirstName; 
        }
    }
}
