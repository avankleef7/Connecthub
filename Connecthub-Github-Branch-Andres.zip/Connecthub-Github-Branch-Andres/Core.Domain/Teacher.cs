﻿using Core.Domain.Helperclasses;
using Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Core.Domain
{
    public class Teacher : IParticipant
    {

        private string FirstName;

        private string LastName;

        private DateTime DateOfBirth;

        private string Email;

        private Department _department;
        private Gender _Gender;
      
        
     


        public int GetAge => DateTimeHelper.CalculateYearsToDate(DateOfBirth);
        public string GetFirstName => FirstName;
        public string GetLastName => LastName;
        public Gender GetGender => _Gender;
        
        public string GetEmail() => Email;
        public DateTime GetDateOfBirth() => DateOfBirth;
        public Department GetDepartment => _department;  

        public Teacher(string firstname, string lastname, Gender gender, DateTime dateofbirth, string email, Department department) 
        {
            // Validatie voor voornaam
            if (string.IsNullOrWhiteSpace(firstname)) throw new ArgumentNullException(nameof(firstname), "Firstname cannot be empty or null.");
            // Validatie voor achternaam
            if (string.IsNullOrWhiteSpace(lastname)) throw new ArgumentNullException(nameof(lastname), "Lastname cannot be empty or null.");
            // Validatie voor datum van geboorte (moet in het verleden liggen)
            if (dateofbirth >= DateTime.Now) throw new ArgumentOutOfRangeException(nameof(dateofbirth), "Date of birth must be in the past.");
            // Validatie voor e-mail (eenvoudige controle)
            if (string.IsNullOrWhiteSpace(email) || !email.Contains("@")) throw new ArgumentException("Email is invalid.", nameof(email));

            this.FirstName = firstname;
            this.LastName = lastname;   
            this.DateOfBirth = dateofbirth;
            this._Gender = gender;
            this.Email = email;
            this._department = department;

        }    
    }
}
