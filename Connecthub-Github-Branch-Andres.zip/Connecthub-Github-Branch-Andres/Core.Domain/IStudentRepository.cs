﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public interface IStudentRepository
    {
        AddingResult TryAddStudent(Student student, string departmentName);
        RemovingResult TryRemoveStudent(string email, string departmentName);
        Student FindStudentByEmail(string email);
        IReadOnlyList<Student> GetStudents();
    }
}
