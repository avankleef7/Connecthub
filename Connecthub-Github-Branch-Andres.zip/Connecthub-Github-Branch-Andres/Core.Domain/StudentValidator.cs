﻿using Core.Domain.Helperclasses;
using System;

namespace Core.Domain
{
    public class StudentValidator : PersonValidator<Student>
    {
        private readonly IEmailValidator emailValidator;
        private readonly DepartmentCapacityValidator departmentCapacityValidator;

        public StudentValidator(IEmailValidator emailValidator, DepartmentCapacityValidator departmentCapacityValidator)
            : base(emailValidator, departmentCapacityValidator)
        {
            this.emailValidator = emailValidator;
            this.departmentCapacityValidator = departmentCapacityValidator;
        }

        public override ValidationResult Validate(Student student)
        {
            // Controleer op null
            if (student == null)
            {
                return new ValidationResult(false, "Student kan niet null zijn.");
            }

            // Validatie voor voornaam
            if (string.IsNullOrWhiteSpace(student.GetFirstName))
            {
                return new ValidationResult(false, "Voornaam kan niet leeg of null zijn.");
            }

            // Validatie voor achternaam
            if (string.IsNullOrWhiteSpace(student.GetLastName))
            {
                return new ValidationResult(false, "Achternaam kan niet leeg of null zijn.");
            }

            // Validatie voor datum van geboorte
            if (student.GetDateOfBirth() >= DateTime.Now)
            {
                return new ValidationResult(false, "Geboortedatum moet in het verleden liggen.");
            }

            // Validatie voor e-mail
            if (string.IsNullOrWhiteSpace(student.GetEmail()) || !IsEmailValid.IsValidEmail(student.GetEmail()))
            {
                return new ValidationResult(false, "E-mail is ongeldig.");
            }

            // Controleer of de e-mail uniek is
            var emailResult = emailValidator.IsEmailUnique(student.GetEmail());
            if (emailResult == null || !emailResult.Success)
            {
                return new ValidationResult(false, emailResult.Reason);
            }

            // Controleer de capaciteit van de afdeling
            var capacityValidationResult = departmentCapacityValidator.ValidateStudentCapacity(student.GetDepartment);
            if (!capacityValidationResult.Success)
            {
                return new ValidationResult(false, capacityValidationResult.Reason);
            }

            // Als alle validaties zijn geslaagd, geef een succesvolle validatieresultaat terug
            return new ValidationResult(true, "Validatie van de student is geslaagd.");
        }
    }
}
