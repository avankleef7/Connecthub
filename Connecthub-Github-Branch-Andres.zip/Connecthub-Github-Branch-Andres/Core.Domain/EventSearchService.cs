﻿using Core.Domain;
using Shared;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Core.Domain
{
    public class EventSearchService : SearchService<Event, EventType>
    {
        private readonly EventCatalog _eventCatalog; 

        // Constructor om de evenementcatalogus te initialiseren
        public EventSearchService(EventCatalog eventCatalog)
            : base(eventCatalog.GetEvents)
        {
            _eventCatalog = eventCatalog;
        }

        protected override IEnumerable<Event> Filter(string searchTerm, EventType eventType)
        {
            // Filteren op basis van het evenementtype
            var filteredByType = FilterByEventType(eventType);

            // Filteren op basis van de zoekterm
            return filteredByType.Where(e =>
                e.GetTitle.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                e.GetDescription.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                e.GetEventType.ToString().Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                e.GetDate.ToString("yyyy-MM-dd").Contains(searchTerm));
        }

        private IEnumerable<Event> FilterByEventType(EventType eventType)
        {
            // Filter op basis van het evenementtype
            return eventType switch
            {
                EventType.None => SearchItems, // Geef alle evenementen terug als "None" is geselecteerd
                EventType.Sport => SearchItems.Where(e => e.GetEventType == EventType.Sport), 
                EventType.Workshop => SearchItems.Where(e => e.GetEventType == EventType.Workshop), 
                EventType.Meeting => SearchItems.Where(e => e.GetEventType == EventType.Meeting), 
                // Als ik alle inheritance heb toegevoegd dan kan ik de rest toevoegen
                _ => SearchItems
            };
        }

        protected override string GetSortKey(Event item)
        {
            return item.GetTitle; // Sorteer op de titel van het evenement
        }
    }
}
