﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public class EmailUniqueResult : Result
    {
        public EmailUniqueResult(bool success, string reason) : base(success, reason, success ? "Success" : "Failure") { }

 
    }
}
