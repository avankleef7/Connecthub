﻿using System;

namespace Core.Domain
{
    public class ValidationResult : Result
    {
        public ValidationResult(bool success, string reason) : base(success, reason, success ? "Success" : "Failure") { }

  
    }
}
