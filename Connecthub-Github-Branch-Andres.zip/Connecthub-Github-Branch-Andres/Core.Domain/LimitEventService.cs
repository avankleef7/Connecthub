﻿namespace Core.Domain
{
    public class LimitEventService
    {
        private readonly EventCatalog _eventCatalog;

        public LimitEventService(EventCatalog eventCatalog)
        {
            _eventCatalog = eventCatalog;
        }

        // Controleer of de deelnemer de limiet heeft bereikt
        public EnrollmentResult CheckLimit(IParticipant participant)
        {
            switch (participant)
            {
                case Student student:
                    var eventLimitStudent = new EventLimitStudent(_eventCatalog);
                    var studentEnrollmentResult = eventLimitStudent.HasReachedLimit(student, _eventCatalog);
                    if (!studentEnrollmentResult.Success)
                    {
                        return studentEnrollmentResult;  // Return als student de limiet heeft bereikt
                    }
                    break;

                case Teacher teacher:
                    var eventLimitTeacher = new EventLimit(10);  // Stel limiet voor docenten in op 10 evenementen
                    var teacherEnrollmentResult = eventLimitTeacher.HasReachedLimit(teacher, _eventCatalog);
                    if (!teacherEnrollmentResult.Success)
                    {
                        return teacherEnrollmentResult;  // Return als docent de limiet heeft bereikt
                    }
                    break;

                case Speaker speaker:
                    var eventLimitSpeaker = new EventLimit(5);  // Stel limiet voor sprekers in op 5 evenementen
                    var speakerEnrollmentResult = eventLimitSpeaker.HasReachedLimit(speaker, _eventCatalog);
                    if (!speakerEnrollmentResult.Success)
                    {
                        return speakerEnrollmentResult;  // Return als spreker de limiet heeft bereikt
                    }
                    break;

                default:
                    return new EnrollmentResult(false, "Onbekende deelnemer.");
            }

            return new EnrollmentResult(true, "Limiet controle is geslaagd.");
        }
    }
}
