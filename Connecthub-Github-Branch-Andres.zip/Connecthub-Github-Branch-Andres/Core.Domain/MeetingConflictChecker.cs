﻿using Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public class MeetingConflictChecker : EventConflictChecker
    {
        public override EventConflictingResult IsEventConflicting(Event eventItem, EventCatalog eventCatalog)
        {

            
            RoomType eventRoomType = eventItem.Venue.GetRoomType;

            // Check of de ruimte een van de uitgesloten types is (Gym, Auditorium, Laboratory)
            if (eventRoomType == RoomType.Gym || eventRoomType == RoomType.Auditorium || eventRoomType == RoomType.Laboratory)
            {
                return new EventConflictingResult(false, "Conflict: Een meeting kan niet plaatsvinden in een Gym, Auditorium of Laboratorium.");
            }

     
            return base.IsEventConflicting(eventItem, eventCatalog);
        }

    }
}
