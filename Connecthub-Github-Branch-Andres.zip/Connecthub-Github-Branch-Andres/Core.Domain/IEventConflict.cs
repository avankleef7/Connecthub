﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public interface IEventConflict
    {
        EventConflictingResult IsEventConflicting(Event eventItem, EventCatalog eventCatalog);

    }
}
