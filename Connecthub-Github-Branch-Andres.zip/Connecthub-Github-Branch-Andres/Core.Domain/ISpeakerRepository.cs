﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public interface ISpeakerRepository
    {
        void TryAddSpeaker(Speaker speaker);
        RemovingResult TryRemoveSpeaker(string email);
        Speaker FindSpeakerByEmail(string email);
        IReadOnlyList<Speaker> GetSpeakers();
    }
}
