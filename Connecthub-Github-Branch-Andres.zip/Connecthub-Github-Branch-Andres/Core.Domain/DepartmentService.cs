﻿using System;
using Shared;

namespace Core.Domain
{
    public class DepartmentFactory
    {
        public AddingResult CreateDepartment(DepartmentType departmentType, DepartmentCatalog departmentCatalog)
        {
            if (departmentCatalog == null) throw new ArgumentNullException(nameof(departmentCatalog), "Afdelingscatalogus kan niet null zijn.");

            string naam;
            string beschrijving;
            int studentcapaciteit;
            int docentcapaciteit;
           

            switch (departmentType)
            {
                case DepartmentType.EducationAndChildDevelopment:
                    naam = "Afdeling Onderwijs en Kinderontwikkeling";
                    beschrijving = "Gefocust op de ontwikkeling van onderwijsmethoden en kinderontwikkeling.";
                    studentcapaciteit = 1;
                    docentcapaciteit = 1;
                    break;
                case DepartmentType.HealthAndSports:
                    naam = "Afdeling Gezondheid en Sport";
                    beschrijving = "Toegewijd aan het bevorderen van gezondheid en fitness door middel van sport en welzijnsprogramma's.";
                    studentcapaciteit = 200;
                    docentcapaciteit = 25;
                    break;
                case DepartmentType.EconomicsAndBusiness:
                    naam = "Afdeling Economie en Bedrijfskunde";
                    beschrijving = "Gefocust op economische theorieën, bedrijfsbeheer en financiële systemen.";
                    studentcapaciteit = 300;
                    docentcapaciteit = 30;
                    break;
                case DepartmentType.TechnologyAndNature:
                    naam = "Afdeling Technologie en Natuur";
                    beschrijving = "Combineert studies in technologische vooruitgangen en natuurwetenschappen.";
                    studentcapaciteit = 180;
                    docentcapaciteit = 22;
                    break;
                case DepartmentType.BehaviorAndSociety:
                    naam = "Afdeling Gedrag en Samenleving";
                    beschrijving = "Analyseert menselijk gedrag en maatschappelijke structuren om sociale interacties beter te begrijpen.";
                    studentcapaciteit = 120;
                    docentcapaciteit = 15;
                    break;
                case DepartmentType.LanguageAndCommunication:
                    naam = "Afdeling Taal en Communicatie";
                    beschrijving = "Onderzoekt taalkundige structuren, communicatiemethoden en culturele expressie.";
                    studentcapaciteit = 100;
                    docentcapaciteit = 18;
                    break;
                case DepartmentType.Art:
                    naam = "Afdeling Kunst";
                    beschrijving = "Richt zich op de creatie, geschiedenis en waardering van beeldende en uitvoerende kunsten.";
                    studentcapaciteit = 80;
                    docentcapaciteit = 10;
                    break;
                case DepartmentType.ICT:
                    naam = "Afdeling ICT";
                    beschrijving = "Specialiseert zich in informatie- en communicatietechnologie, inclusief software- en systeemontwikkeling.";
                    studentcapaciteit = 250;
                    docentcapaciteit = 28;
                    break;
                case DepartmentType.Logistics:
                    naam = "Afdeling Logistiek";
                    
                    beschrijving = "Behandelt de studie van supply chain management, transport en logistieke systemen.";
                    studentcapaciteit = 170;
                    docentcapaciteit = 20;
                    break;
                default:
                    throw new ArgumentException("Ongeldige DepartmentType opgegeven.");
            }

            // Maak de afdeling aan
            Department department = new Department(naam, departmentType, beschrijving, studentcapaciteit, docentcapaciteit);

            // Voeg de afdeling toe aan de school en verkrijg het resultaat
            AddingResult result = departmentCatalog.TryAddDepartment(department, SchoolManager.Instance.Name);
            return result;
        }
    }
}
