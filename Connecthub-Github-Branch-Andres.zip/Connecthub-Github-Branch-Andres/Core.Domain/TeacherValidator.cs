﻿using Core.Domain.Helperclasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public class TeacherValidator : PersonValidator<Teacher>
    {
        private readonly IEmailValidator emailValidator;
        private readonly DepartmentCapacityValidator departmentCapacityValidator;

        public TeacherValidator(IEmailValidator emailValidator, DepartmentCapacityValidator departmentCapacityValidator)
            : base(emailValidator, departmentCapacityValidator)
        {
            this.emailValidator = emailValidator;
            this.departmentCapacityValidator = departmentCapacityValidator;
        }

        public override ValidationResult Validate(Teacher teacher)
        {
            // Controleer op null
            if (teacher == null)
            {
                return new ValidationResult(false, "Teacher kan niet null zijn.");
            }

            // Validatie voor voornaam
            if (string.IsNullOrWhiteSpace(teacher.GetFirstName))
            {
                return new ValidationResult(false, "Voornaam kan niet leeg of null zijn.");
            }

            // Validatie voor achternaam
            if (string.IsNullOrWhiteSpace(teacher.GetLastName))
            {
                return new ValidationResult(false, "Achternaam kan niet leeg of null zijn.");
            }

            // Validatie voor geboortedatum
            if (teacher.GetDateOfBirth() >= DateTime.Now)
            {
                return new ValidationResult(false, "Geboortedatum moet in het verleden liggen.");
            }

            // Validatie voor e-mail
            if (string.IsNullOrWhiteSpace(teacher.GetEmail()) || !IsEmailValid.IsValidEmail(teacher.GetEmail()))
            {
                return new ValidationResult(false, "E-mail is ongeldig.");
            }

            // Controleer of de e-mail uniek is
            var emailResult = emailValidator.IsEmailUnique(teacher.GetEmail());
            if (emailResult == null || !emailResult.Success)
            {
                return new ValidationResult(false, emailResult.Reason);
            }

            // Controleer de capaciteit van de afdeling
            var capacityValidationResult = departmentCapacityValidator.ValidateTeacherCapacity(teacher.GetDepartment);
            if (!capacityValidationResult.Success)
            {
                return new ValidationResult(false, capacityValidationResult.Reason);
            }

            // Als alle validaties zijn geslaagd, geef een succesvolle validatieresultaat terug
            return new ValidationResult(true, "Validatie van de leraar is geslaagd.");
        }

    }
}
