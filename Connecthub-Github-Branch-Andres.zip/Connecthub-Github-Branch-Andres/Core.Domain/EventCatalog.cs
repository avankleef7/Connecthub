﻿using Core.DTO;
using Infrastructure;
using Microsoft.Data.SqlClient;
using Shared;

namespace Core.Domain
{
    public class EventCatalog
    {
        private List<Event> events = new List<Event>();
        private readonly EventRepository _eventRepository;
        private readonly DepartmentRepository _departmentRepository;
        private readonly VenueRepository _venueRepository;
        private readonly DepartmentCatalog _departmentCatalog;
        private readonly VenueCatalog _venueCatalog;
        public IReadOnlyList<Event> GetEvents => events;

        // Constructor met een EventRepository parameter
        public EventCatalog(EventRepository eventRepository, DepartmentRepository departmentRepository, VenueRepository venueRepository, DepartmentCatalog departmentCatalog, VenueCatalog venuecatalog)
        {
            _eventRepository = eventRepository;
            _departmentRepository = departmentRepository;
            _venueRepository = venueRepository;
            _departmentCatalog = departmentCatalog;
            _venueCatalog = venuecatalog;
            LoadEventsFromDatabase();
            //PrintAllEvents();
        }

        //public void PrintAllEvents()
        //{
        //    if (events == null || !events.Any())
        //    {
        //        Console.WriteLine("Geen evenementen gevonden in de catalogus.");
        //        return;
        //    }

        //    Console.WriteLine("Alle evenementen in de catalogus:");
        //    foreach (var ev in events)
        //    {
        //        Console.WriteLine("=====================================");
        //        Console.WriteLine($"Titel: {ev.GetTitle}");
        //        Console.WriteLine($"Type: {ev.GetEventType}");
        //        Console.WriteLine($"Afdeling: {ev.GetDepartment?.GetName ?? "Geen afdeling gekoppeld"}");
        //        Console.WriteLine($"Datum: {ev.GetDate.ToShortDateString()}");
        //        Console.WriteLine($"Starttijd: {ev.GetStartTime}");
        //        Console.WriteLine($"Eindtijd: {ev.GetEndTime}");
        //        Console.WriteLine($"Beschrijving: {ev.GetDescription}");
        //        Console.WriteLine($"Locatie: {ev.Venue?.GetLocationName ?? "Geen locatie gekoppeld"}");
        //        Console.WriteLine("=====================================");
        //    }
        //}

        private void LoadEventsFromDatabase()
        {
            // Haal de EventDTO's op uit de repository
            var eventDTOs = _eventRepository.GetAllEvents();

            // Zet de EventDTO's om naar Event objecten en voeg ze toe aan de lijst
            events = eventDTOs.Select(dto => CreateEventFromDTO(dto)).ToList();


        }

        private Event CreateEventFromDTO(EventDTO dto)
        {
            string departmentName = _departmentRepository.GetDepartmentNameById(dto.DepartmentId);
            var department = _departmentCatalog.TryFindDepartmentByName(departmentName);
            string venueName = _venueRepository.GetVenueNameByID(dto.VenueId);
            var venue = _venueCatalog.TryFindVenueByLocationName(venueName);

            switch (dto.EventType)
            {
                case EventType.Sport:
                    return new SportEvent(dto.Title, dto.EventType, department, dto.Date, dto.StartTime, dto.EndDate, dto.EndTime, dto.Description, venue, dto.Capacity);
                case EventType.Meeting:
                    return new MeetingEvent(dto.Title, dto.EventType, department, dto.Date, dto.StartTime, dto.EndDate, dto.EndTime, dto.Description, venue, dto.Capacity);
                case EventType.Workshop:
                    return new WorkshopEvent(dto.Title, dto.EventType, department, dto.Date, dto.StartTime, dto.EndDate, dto.EndTime, dto.Description, venue, dto.Capacity);
                default:
                    throw new InvalidOperationException("Onbekend evenementtype.");
            }
        }



        public AddingResult TryAddEventToCatalog(Event eventToAdd)
        {
            if (eventToAdd == null)
                return new AddingResult(false, "Evenement kan niet null zijn.");

            int departmentId = _departmentRepository.GetDepartmentIdByName(eventToAdd.GetDepartment.GetName);
            int venueId = _venueRepository.GetVenueIDbyName(eventToAdd.Venue.GetLocationName);

            int capacity = 0;
            if (eventToAdd is MeetingEvent meetingEvent)
            {
                capacity = meetingEvent.MaxCapacity;
            }
            else if (eventToAdd is WorkshopEvent workshopEvent)
            {
                capacity = workshopEvent.MaxCapacity; 
            }
            else if (eventToAdd is SportEvent sportEvent)
            {
                capacity = sportEvent.MaxCapacity; 
            }

            // Maak een EventDTO aan en vul de properties
            var eventDTO = new EventDTO(
                title: eventToAdd.GetTitle,
                eventType: eventToAdd.GetEventType,
                departmentId,
                status: eventToAdd.GetStatus,
                date: eventToAdd.GetDate,
                startTime: eventToAdd.GetStartTime,
                endDate: eventToAdd.GetEndDate,
                endTime: eventToAdd.GetEndTime,
                description: eventToAdd.GetDescription,
                venueId,
                capacity: capacity,  
                enrolledSpeakers: eventToAdd.Speakers?.Select(s => ConvertSpeakerToDTO(s)).ToList(),
                enrolledStudents: eventToAdd.Students?.Select(s => ConvertStudentToDTO(s)).ToList(),
                enrolledTeachers: eventToAdd.Teachers?.Select(t => ConvertTeacherToDTO(t)).ToList(),
                unenrolledSpeakers: eventToAdd.unrolledSpeakers?.Select(s => ConvertSpeakerToDTO(s)).ToList(),
                unenrolledStudents: eventToAdd.unrolledStudents?.Select(s => ConvertStudentToDTO(s)).ToList(),
                unenrolledTeachers: eventToAdd.unrolledTeachers?.Select(t => ConvertTeacherToDTO(t)).ToList()
            );

            try
            {
                _eventRepository.AddEvent(eventDTO);
                events.Add(eventToAdd);
                return new AddingResult(true, "Evenement succesvol toegevoegd aan de catalogus en de database.");
            }
            catch (SqlException ex)
            {
                Console.WriteLine($"SQL Error: {ex.Message}");
                foreach (SqlError error in ex.Errors)
                {
                    Console.WriteLine($" - Error Code: {error.Number}, Message: {error.Message}");
                }
                throw;
            }
        }


        // Zoek een evenement op naam
        public Event FindEventByName(string name)
        {
            return events.FirstOrDefault(e => e.GetTitle.Equals(name, StringComparison.OrdinalIgnoreCase));
        }

        // Conversie-methodes voor Student, Teacher en Speaker
        public StudentDTO ConvertStudentToDTO(Student student)
        {
            int departmentId = _departmentRepository.GetDepartmentIdByName(student.GetDepartment.GetName);
            return new StudentDTO(
                departmentid: departmentId,
                firstName: student.GetFirstName,
                lastName: student.GetLastName,
                dateOfBirth: student.GetDateOfBirth(),
                gender: student.GetGender,
                nationality: student.GetNationality,
                email: student.GetEmail()
            );
        }

        public TeacherDTO ConvertTeacherToDTO(Teacher teacher)
        {
            int departmentId = _departmentRepository.GetDepartmentIdByName(teacher.GetDepartment.GetName);
            return new TeacherDTO(
                departmentID: departmentId,
                firstName: teacher.GetFirstName,
                lastName: teacher.GetLastName,
                dateOfBirth: teacher.GetDateOfBirth(),
                gender: teacher.GetGender,
                email: teacher.GetEmail()
            );
        }

        public SpeakerDTO ConvertSpeakerToDTO(Speaker speaker)
        {
            return new SpeakerDTO(
                firstName: speaker.GetFirstName,
                lastName: speaker.GetLastName,
                dateOfBirth: speaker.GetDateOfBirth(),
                gender: speaker.GetGender,
                email: speaker.GetEmail(),
                organization: speaker.GetOrganization,
                position: speaker.GetPosition
            );
        }
    }
}
