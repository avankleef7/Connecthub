﻿using Infrastructure;
using System;

namespace Core.Domain
{
    public class School
    {
        public string Name { get; private set; }
        public DepartmentCatalog DepartmentCatalog { get; private set; }
        public VenueCatalog VenueCatalog { get; private set; }

        // Constructor voor de School
        public School(string name, string connectionString)
        {
            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentNullException(nameof(name), "School name cannot be null or empty.");

            Name = name;

            // Maak een nieuwe SchoolRepository aan
            var schoolRepository = new SchoolRepository(connectionString);

            // Maak een nieuwe DepartmentRepository aan en geef deze door aan de DepartmentCatalog
            var departmentRepository = new DepartmentRepository(connectionString);
            DepartmentCatalog = new DepartmentCatalog(departmentRepository, schoolRepository);  // SchoolRepository wordt hier doorgegeven

            // Maak een nieuwe VenueCatalog aan
            var venueRepository = new VenueRepository(connectionString);
            VenueCatalog = new VenueCatalog(venueRepository, schoolRepository);
        }
    }
}
