﻿using Shared;

namespace Core.Domain
{
    public class EventLimitStudent : EventLimit
    {
        private const int MaxStudentEvents = 5;   // Limiet voor algemene evenementen
        private const int MaxSportEvents = 2;     // Limiet voor sportevenementen

        private readonly EventCatalog _eventCatalog;

        public EventLimitStudent(EventCatalog eventCatalog) : base(MaxStudentEvents)
        {
            _eventCatalog = eventCatalog;
        }

        // Override van de HasReachedLimit methode voor studenten
        public override EnrollmentResult HasReachedLimit(IParticipant participant, EventCatalog eventCatalog)
        {
            // Haal het aantal ingeschreven evenementen op voor de student
            int enrolledEventCount = GetEnrolledEventCount(participant, eventCatalog);

            // Controleer of de student de limiet voor algemene evenementen heeft bereikt
            if (enrolledEventCount >= MaxStudentEvents)
            {
                return new EnrollmentResult(false, $"Je hebt je al voor {enrolledEventCount} evenementen ingeschreven, wat de limiet van {MaxStudentEvents} overschrijdt.");
            }

            // Als het een sportevenement is, controleer dan of de student de limiet van sportevenementen heeft bereikt
            if (participant is Student && eventCatalog.GetEvents
                .Where(e => e.Students.Contains(participant) && e.GetEventType == EventType.Sport)
                .Count() >= MaxSportEvents)
            {
                return new EnrollmentResult(false, $"Je kunt je niet inschrijven voor meer dan {MaxSportEvents} sportevenementen.");
            }

            return new EnrollmentResult(true, $"Je hebt je voor {enrolledEventCount} evenementen ingeschreven. Je kunt je nog inschrijven voor meer evenementen.");
        }
    }
}
