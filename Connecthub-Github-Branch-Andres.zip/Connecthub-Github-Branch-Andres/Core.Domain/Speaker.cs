﻿using Core.Domain.Helperclasses;
using Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public class Speaker : IParticipant
    {

        private string FirstName;

        private string LastName;

        private DateTime DateOfBirth;

        private string Email;

        private string Organization;

        private string Position;
        private Gender _Gender;
        


        public int GetAge => DateTimeHelper.CalculateYearsToDate(DateOfBirth);
        public string GetFirstName => FirstName;
        public string GetLastName => LastName;
        public Gender GetGender => _Gender;
        public string GetEmail() => Email;
        public DateTime GetDateOfBirth() => DateOfBirth;
        public string GetOrganization => Organization;
        public string GetPosition => Position;





        public Speaker(string firstname, string lastname, Gender gender, DateTime dateofbirth, string email, string organization, string position)
        {
            // Validatie voor voornaam
            if (string.IsNullOrWhiteSpace(firstname)) throw new ArgumentNullException(nameof(firstname), "Firstname cannot be empty or null.");
            // Validatie voor achternaam
            if (string.IsNullOrWhiteSpace(lastname)) throw new ArgumentNullException(nameof(lastname), "Lastname cannot be empty or null.");
            // Validatie voor datum van geboorte (moet in het verleden liggen)
            if (dateofbirth >= DateTime.Now) throw new ArgumentOutOfRangeException(nameof(dateofbirth), "Date of birth must be in the past.");
            // Validatie voor e-mail (eenvoudige controle)
            if (string.IsNullOrWhiteSpace(email) || !email.Contains("@")) throw new ArgumentException("Email is invalid.", nameof(email));
            // Validatie voor organisatie
            if (string.IsNullOrWhiteSpace(organization)) throw new ArgumentException(nameof(organization), "Organization cannot be empty or null.");
            // Validatie voor positie (binnen het bedrijf)
            if (string.IsNullOrWhiteSpace(organization)) throw new ArgumentException(nameof(organization), "Organization cannot be empty or null.");


            this.FirstName = firstname;
            this.LastName = lastname;
            this._Gender = gender;
            this.DateOfBirth = dateofbirth;
            this.Email = email;
            this.Organization = organization;
            this.Position = position;


        }

    }
}
