﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public class AddingResult : Result
    {
       
        public AddingResult(bool success, string reason)
            : base(success, reason, success ? "Success" : "Failure")
        { }

    }
}
