﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public interface ITeacherRepository
    {
        AddingResult TryAddTeacher(Teacher teacher, string departmentName);
        RemovingResult TryRemoveTeacher(string email, string departmentName);
        Teacher FindTeacherByEmail(string email);
        IReadOnlyList<Teacher> GetTeachers();
    }
}
