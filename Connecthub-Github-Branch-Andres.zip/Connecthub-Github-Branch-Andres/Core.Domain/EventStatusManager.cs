﻿using Shared;
using System;
using System.Linq;

namespace Core.Domain
{
    public class EventStatusManager 
    {
        private readonly EventConflictChecker _eventConflictChecker;
        private readonly SportEventConflictChecker _sportConflictChecker;
        private readonly MeetingConflictChecker _meetingConflictChecker;

        public EventStatusManager(EventConflictChecker eventConflictChecker, SportEventConflictChecker sportconflictchecker, MeetingConflictChecker meetingconflictchecker)
        {
            _eventConflictChecker = eventConflictChecker;
            _sportConflictChecker = sportconflictchecker;
            _meetingConflictChecker = meetingconflictchecker;
            
        }


        public ChangingStatusResult EventStatusCheck(Event eventItem)
        {
            var currentTime = DateTime.Now;
            var eventStartDateTime = eventItem.GetDate.Date + eventItem.GetStartTime; // Starttijd
            var eventEndDateTime = eventStartDateTime + (eventItem.GetEndTime - eventItem.GetStartTime); // Eindtijd

            if (eventItem.GetStatus == Status.Inactive && currentTime >= eventStartDateTime && currentTime < eventEndDateTime)
            {
                return eventItem.ChangingStatus(Status.Pending); // Zet status op "Pending"
            }

            // Controleer of het evenement afgelopen en bevestigd moet zijn
            if (eventItem.GetStatus == Status.Pending && currentTime >= eventEndDateTime)
            {
                return eventItem.ChangingStatus(Status.Confirmed);
            }

            // Als er geen verandering in status is, return een geslaagd resultaat zonder status update
            return new ChangingStatusResult(true, "Event status is onverandert.");
        }

        public ChangingStatusResult ActivateEvent(Event eventItem, EventCatalog eventCatalog)
        {
                                
            // Kies de juiste conflictchecker op basis van het evenementtype
            EventConflictingResult conflictResult;

            switch (eventItem.GetEventType)
            {
                case EventType.Sport:
                    conflictResult = _sportConflictChecker.IsEventConflicting(eventItem, eventCatalog);
                    break;

                case EventType.Meeting:
                    conflictResult = _meetingConflictChecker.IsEventConflicting(eventItem, eventCatalog);
                    break;
                default:
                    conflictResult = _eventConflictChecker.IsEventConflicting(eventItem, eventCatalog);
                    break;
            }

            if (!conflictResult.Success)
            {
                // Gebruik de foutmelding uit de conflictchecker in de ChangingStatusResult
                return new ChangingStatusResult(false, conflictResult.Reason);
            }
            // Activeer het evenement door de status naar 'Active' te zetten
            return eventItem.ChangingStatus(Status.Active);
            
        }

        
    }
}
