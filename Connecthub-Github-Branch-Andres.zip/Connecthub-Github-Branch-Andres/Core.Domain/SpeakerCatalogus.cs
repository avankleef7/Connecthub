﻿using Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Core.Domain
{
    public class SpeakerCatalogus : ISpeakerRepository
    {
        private readonly SpeakerRepository _speakerRepository;

        private List<Speaker> speakers = new List<Speaker>();

        public SpeakerCatalogus(SpeakerRepository speakerRepository)
        {
            _speakerRepository = speakerRepository ?? throw new ArgumentNullException(nameof(speakerRepository));
            // Laad de sprekers uit de database bij initialisatie
            LoadSpeakersFromDatabase();
        }

        private void LoadSpeakersFromDatabase()
        {
            // Haal alle sprekers op uit de database via de repository
            var speakerDTOs = _speakerRepository.GetAllSpeakers();

            // Zet de opgehaalde sprekers om naar Speaker objecten
            speakers = speakerDTOs.Select(dto => new Speaker(
                dto.FirstName,
                dto.LastName,
                dto.Gender,
                dto.DateOfBirth,
                dto.Email,
                dto.Organization,
                dto.Position
            )).ToList();
        }

        public IReadOnlyList<Speaker> GetSpeakers() => speakers.AsReadOnly();

        public void TryAddSpeaker(Speaker speaker)
        {
            if (speaker == null)
                throw new ArgumentNullException(nameof(speaker), "Spreker kan niet null zijn, niet toegevoegd.");

            // Maak een SpeakerDTO van de spreker
            var speakerDTO = new SpeakerDTO(
                firstName: speaker.GetFirstName,
                lastName: speaker.GetLastName,
                dateOfBirth: speaker.GetDateOfBirth(),
                gender: speaker.GetGender,
                email: speaker.GetEmail(),
                organization: speaker.GetOrganization,
                position: speaker.GetPosition
            );

            // Voeg de spreker toe aan de database via de repository
            _speakerRepository.AddSpeaker(speakerDTO);

            // Voeg de spreker toe aan de lokale lijst in de catalogus
            speakers.Add(speaker);
        }

        public RemovingResult TryRemoveSpeaker(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                return new RemovingResult(false, "Email kan niet leeg of null zijn.");
            }

            // Zoek de spreker in de lokale lijst
            Speaker speaker = FindSpeakerByEmail(email);

            if (speaker != null)
            {
                // Verwijder de spreker uit de database
                var speakerDTO = new SpeakerDTO(
                    speaker.GetFirstName,
                    speaker.GetLastName,
                    speaker.GetDateOfBirth(),
                    speaker.GetGender,
                    speaker.GetEmail(),
                    speaker.GetOrganization,
                    speaker.GetPosition
                );

                _speakerRepository.RemoveSpeaker(speakerDTO);

                // Verwijder de spreker uit de lokale lijst in de catalogus
                speakers.Remove(speaker);

                return new RemovingResult(true, "Spreker succesvol verwijderd.");
            }

            return new RemovingResult(false, "Spreker niet gevonden.");
        }

        public Speaker FindSpeakerByEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                throw new ArgumentException("Email mag niet leeg zijn.", nameof(email));

            // Zoek de spreker op basis van het opgegeven e-mailadres
            Speaker speaker = speakers.FirstOrDefault(s => s.GetEmail().Equals(email, StringComparison.OrdinalIgnoreCase));

            if (speaker == null)
            {
                throw new InvalidOperationException("Geen spreker gevonden met het opgegeven e-mailadres.");
            }

            return speaker;
        }

        public IEnumerable<IParticipant> GetAllParticipants()
        {
            return speakers.Cast<IParticipant>().ToList();
        }
    }
}
