﻿using Shared;
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public class SportEventConflictChecker : EventConflictChecker
    {
        private readonly TimeSpan LatestEndTime = new TimeSpan(23, 0, 0);
        private readonly TimeSpan EarliestStartTime = new TimeSpan(6, 0, 0);

        // Controleer of de start- en eindtijden van het sportevenement geldig zijn
        public override EventConflictingResult IsEventConflicting(Event eventItem, EventCatalog eventCatalog)
        {
            // Bereken de eindtijd van het sportevenement
            var eventEndTime = eventItem.GetStartTime + (eventItem.GetEndTime - eventItem.GetStartTime);

            // Controleer of het evenement na 23:00 uur eindigt
            if (eventEndTime > LatestEndTime)
            {
                return new EventConflictingResult(false, "Conflict: Het sportevenement mag niet later dan 23:00 uur eindigen.");
            }

            // Controleer of het evenement niet vóór 06:00 uur start
            if (eventItem.GetStartTime < EarliestStartTime)
            {
                return new EventConflictingResult(false, "Conflict: Het sportevenement mag niet vóór 06:00 uur beginnen.");
            }

            
            return base.IsEventConflicting(eventItem, eventCatalog);
        }
    }
}
