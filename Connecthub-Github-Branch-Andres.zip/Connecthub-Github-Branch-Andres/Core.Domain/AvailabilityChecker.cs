﻿using Shared;

namespace Core.Domain
{
    public class AvailabilityChecker
    {
        private readonly EventCatalog _eventCatalog;

        public AvailabilityChecker(EventCatalog eventCatalog)
        {
            _eventCatalog = eventCatalog;
        }

        public EnrollmentResult IsAvailable(IParticipant participant, Event eventItem)
        {
            // Bepaal het start- en eindtijdstip van het evenement
            var eventStartDateTime = eventItem.GetDate.Date + eventItem.GetStartTime;
            var eventEndDateTime = eventStartDateTime + (eventItem.GetEndTime - eventItem.GetStartTime);

            // Controleer of er conflicterende evenementen zijn
            var conflictingEvents = _eventCatalog.GetEvents
                .Where(e => (e.GetStatus == Status.Active || e.GetStatus == Status.Pending) && // Controleer of het evenement actief of pending is
                    e.Venue == eventItem.Venue && // Controleer of de locatie overeenkomt
                    (eventStartDateTime < (e.GetDate.Date + e.GetEndTime) && // Begin van evenement moet vóór het einde van een ander evenement liggen
                     eventEndDateTime > (e.GetDate.Date + e.GetStartTime)) && // Einde van evenement moet na het begin van een ander evenement liggen
                    (e.Students.Contains(participant) || e.Teachers.Contains(participant) || e.Speakers.Contains(participant)))
                .Any();

            if (conflictingEvents)
            {
                return new EnrollmentResult(false, "Al ingeschreven voor een ander evenement op dit tijdstip.");
            }

           
            // Als er geen conflicten zijn en de limieten niet zijn bereikt, geef dan een positieve boodschap terug
            return new EnrollmentResult(true, "Beschikbaar voor dit evenement.");
        }
    }
}
