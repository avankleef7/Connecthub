﻿using Core.Domain;

public class MeetingEnrollmentManager : EnrollmentManager
{
    public MeetingEnrollmentManager(
        EventCatalog eventCatalog,
        AvailabilityChecker availabilityChecker,
        LimitEventService limitEventService)
        : base(eventCatalog, availabilityChecker, limitEventService)
    {
    }

    public override EnrollmentResult EnrollStudent(Student student, Event meeting)
    {
        // Controleer of de student het juiste department heeft voor de meeting
        if (student == null)
            throw new ArgumentNullException(nameof(student), "Student mag niet null zijn.");
        if (meeting == null)
            throw new ArgumentNullException(nameof(meeting), "Evenement mag niet null zijn.");

        // Check of het department van de student overeenkomt met het department van de meeting
        if (student.GetDepartment != meeting.GetDepartment)
        {
            return new EnrollmentResult(false, "Student kan zich niet inschrijven voor dit evenement. Dit evenement is alleen voor studenten van het afdeling: " + meeting.GetDepartment);
        }

        return base.EnrollStudent(student, meeting);
    }

    public override EnrollmentResult EnrollTeacher(Teacher teacher, Event meeting)
    {
        // Controleer of de docent het juiste department heeft voor de meeting
        if (teacher == null)
            throw new ArgumentNullException(nameof(teacher), "Docent mag niet null zijn.");
        if (meeting == null)
            throw new ArgumentNullException(nameof(meeting), "Evenement mag niet null zijn.");

        // Check of het department van de docent overeenkomt met het department van de meeting
        if (teacher.GetDepartment != meeting.GetDepartment)
        {
            return new EnrollmentResult(false, "Docent kan zich niet inschrijven voor dit evenement. Dit evenement is alleen voor docenten van het afdeling: " + meeting.GetDepartment);
        }

        return base.EnrollTeacher(teacher, meeting);
    }

    public override EnrollmentResult EnrollSpeaker(Speaker speaker, Event meeting)
    {
        // Controleer of de spreker geldig is
        if (speaker == null)
            throw new ArgumentNullException(nameof(speaker), "Spreker mag niet null zijn.");
        if (meeting == null)
            throw new ArgumentNullException(nameof(meeting), "Evenement mag niet null zijn.");

        // Controleer of er al een spreker is ingeschreven voor dit evenement
        var existingSpeaker = meeting.Speakers.FirstOrDefault();
        if (existingSpeaker != null)
        {
            // Als er al een spreker is, controleer dan of de nieuwe spreker van dezelfde organisatie is
            if (existingSpeaker.GetOrganization != speaker.GetOrganization)
            {
                return new EnrollmentResult(false, "De spreker kan zich niet inschrijven voor dit evenement. Alleen sprekers van dezelfde organisatie kunnen zich inschrijven.");
            }
        }

        return base.EnrollSpeaker(speaker, meeting);
    }
}
