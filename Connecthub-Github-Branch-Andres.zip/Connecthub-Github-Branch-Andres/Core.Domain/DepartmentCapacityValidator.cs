﻿using System;

namespace Core.Domain
{
    public class DepartmentCapacityValidator : ICapacityValidator<Department>
    {
        public CapacityResult ValidateStudentCapacity(Department department)
        {
            if (department == null)
                throw new ArgumentNullException(nameof(department), "Afdeling kan niet null zijn.");

            if (department.GetStudentCount() >= department.GetStudentCapacity)
            {
                return new CapacityResult(false, "Afdeling heeft zijn maximale studentencapaciteit bereikt.");
            }

            return new CapacityResult(true, "Controle op studentencapaciteit geslaagd.");
        }

        public CapacityResult ValidateTeacherCapacity(Department department)
        {
            if (department == null)
                throw new ArgumentNullException(nameof(department), "Afdeling kan niet null zijn.");

            if (department.GetTeacherCount() >= department.GetTeacherCapacity)
            {
                return new CapacityResult(false, "Afdeling heeft zijn maximale docenten capaciteit bereikt.");
            }

            return new CapacityResult(true, "Controle op docenten capaciteit geslaagd.");
        }
    }
}
