﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public class UnenrollmentManager : IUnenroll
    {
     
        public UnenrollmentResult UnenrollSpeaker(Speaker speaker, Event eventItem)
        {
            if (speaker == null)
                throw new ArgumentNullException(nameof(speaker), "Student kan niet null zijn.");
            if (eventItem == null)
                throw new ArgumentNullException(nameof(eventItem), "Evenement kan niet null zijn.");

       
            if (eventItem.TryRemoveSpeaker(speaker))
            {
                eventItem.TryAddUnenrolledSpeaker(speaker);
                return new UnenrollmentResult(true, "Student is succesvol uitgeschreven voor het evenement.");
            }

            return new UnenrollmentResult(false, "Student was niet ingeschreven voor dit evenement.");
        }

        public UnenrollmentResult UnenrollStudent(Student student, Event eventItem)
        {
            if (student == null)
                throw new ArgumentNullException(nameof(student), "Student kan niet null zijn.");
            if (eventItem == null)
                throw new ArgumentNullException(nameof(eventItem), "Evenement kan niet null zijn.");

            if (eventItem.TryRemoveStudent(student))
            {
                eventItem.TryAddUnenrolledStudent(student);
                return new UnenrollmentResult(true, "Student is succesvol uitgeschreven voor het evenement.");
            }

            return new UnenrollmentResult(false, "Student was niet ingeschreven voor dit evenement.");
        }

        public UnenrollmentResult UnenrollTeacher(Teacher teacher, Event eventItem)
        {
            if (teacher == null)
                throw new ArgumentNullException(nameof(teacher), "Docent kan niet null zijn.");
            if (eventItem == null)
                throw new ArgumentNullException(nameof(eventItem), "Evenement kan niet null zijn.");

            if (eventItem.TryRemoveTeacher(teacher))
            {

                eventItem.TryAddUnenrolledTeacher(teacher);
                return new UnenrollmentResult(true, "Docent is succesvol uitgeschreven voor het evenement.");

            }

            return new UnenrollmentResult(false, "Docent was niet ingeschreven voor dit evenement.");
        }
    }
}
