﻿namespace Core.Domain
{
    public class Result : IResult
    {
        public bool Success { get; private set; }
        public string Reason { get; private set; }
        public string Type { get; private set; }

        public Result(bool success, string reason, string type)
        {
            Success = success;
            Reason = reason ?? throw new ArgumentNullException(nameof(reason), "Bericht mag niet null of leeg zijn voor een failure.");
            Type = type;
        }

        // De methoden zijn nu virtueel en kunnen in subklassen worden overschreven indien nodig
        public virtual Result CreateSuccess(string message = null)
        {
            return new Result(true, message ?? "Success", "Success");
        }

        public virtual Result CreateFailure(string message)
        {
            if (string.IsNullOrEmpty(message))
            {
                throw new ArgumentNullException(nameof(message), "Bericht mag niet null of leeg zijn voor een failure.");
            }
            return new Result(false, message, "Failure");
        }
    }
}
