﻿using System;
using System.Collections.Generic;
using System.Linq;
using Infrastructure;
using Shared; // Voor Student, Gender, Nationality, enz.

namespace Core.Domain
{
    public class Department
    {
        private string name;
        private DepartmentType departmentType;
        private string description;
        private int studentCapacity;
        private int teacherCapacity;

        private List<Student> students;  // Lijst van studenten in dit department
        private List<Teacher> teachers;





        // Eigenschappen
        public string GetName => name;
        public DepartmentType GetDepartmentType => departmentType;
        public string GetDescription => description;

        public int GetStudentCapacity => studentCapacity;
        public int GetTeacherCapacity => teacherCapacity;

        public int GetStudentCount()
        {
            return students.Count;
        }

        public int GetTeacherCount()
        {
            return teachers.Count;
        }

        // Constructor
        public Department(string name, DepartmentType departmentType, string description, int studentCapacity, int teacherCapacity)
        {
            // Validatie van naam en beschrijving
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentNullException(nameof(name), "Afdelingsnaam mag niet leeg of null zijn.");
            if (string.IsNullOrWhiteSpace(description))
                throw new ArgumentNullException(nameof(description), "Afdelingsbeschrijving mag niet leeg of null zijn.");

            // Validatie van capaciteit
            if (studentCapacity <= 0)
                throw new ArgumentOutOfRangeException(nameof(studentCapacity), "Studenten capaciteit mag niet nul of minder zijn.");
            if (teacherCapacity <= 0)
                throw new ArgumentOutOfRangeException(nameof(teacherCapacity), "Docenten capaciteit mag niet nul of minder zijn.");

            // Initialisatie van de velden
            this.name = name;
            this.description = description;
            this.studentCapacity = studentCapacity;
            this.teacherCapacity = teacherCapacity;
            this.students = new List<Student>();
            this.teachers = new List<Teacher>();
            //this._studentRepository = studentRepository;
 
        }

        // Probeer een student toe te voegen
        public AddingResult TryAddStudent(Student student)
        {
            if (student == null)
                return new AddingResult(false, "Student mag niet null zijn.");

            bool studentExists = students.Any(s => s.GetEmail() == student.GetEmail());
            if (studentExists)
                return new AddingResult(false, "Student bestaat al in de afdeling.");

            if (students.Count >= studentCapacity)
                return new AddingResult(false, "Capaciteit bereikt.");

            students.Add(student);
            return new AddingResult(true, "Student is succesvol toegevoegd aan de afdeling.");
        }

        // Probeer een student te verwijderen
        public RemovingResult TryRemoveStudent(Student student)
        {
            if (student == null)
                return new RemovingResult(false, "Student mag niet null zijn.");

            var studentInDepartment = students.FirstOrDefault(s => s.GetEmail() == student.GetEmail());
            if (studentInDepartment == null)
                return new RemovingResult(false, "Student niet gevonden in de afdeling.");

            students.Remove(studentInDepartment);
            return new RemovingResult(true, $"Student {student.GetEmail()} succesvol verwijderd.");
        }

        // Toevoegen van een docent (optioneel)
        public AddingResult TryAddTeacher(Teacher teacher)
        {
            // Code voor het toevoegen van een docent
            return new AddingResult(true, "Docent succesvol toegevoegd.");
        }

        // Verwijderen van een docent (optioneel)
        public RemovingResult TryRemoveTeacher(Teacher teacher)
        {
            // Code voor het verwijderen van een docent
            return new RemovingResult(true, "Docent succesvol verwijderd.");
        }

        public override string ToString()
        {
            return $"Afdeling: {name}\n" +
                   $"Beschrijving: {description}\n" +
                   $"Studenten Capaciteit: {studentCapacity}\n" +
                   $"Huidig Studenten Aantal: {GetStudentCount()}\n" +
                   $"Docenten Capaciteit: {teacherCapacity}\n" +
                   $"Huidig Docenten Aantal: {GetTeacherCount()}";
        }
    }
}
