﻿using Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public class EventConflictChecker : IEventConflict
    {

        public virtual EventConflictingResult IsEventConflicting(Event eventItem, EventCatalog eventCatalog)
        {

            // Controleer of het evenement inactief is
            if (eventItem.GetStatus != Status.Inactive)
            {
                return new EventConflictingResult(false, "Event kan niet worden geactiveerd. Status is niet 'Inactive'.");
            }
            // Controleer of er minstens één spreker en één student/leraar aanwezig zijn
            if (!eventItem.Speakers.Any())
            {
                return new EventConflictingResult(false, "Event kan niet worden geactiveerd. Geen spreker aanwezig.");
            }
            if (!eventItem.Students.Any() && !eventItem.Teachers.Any())
            {
                return new EventConflictingResult(false, "Event kan niet worden geactiveerd. Geen deelnemers aanwezig.");
            }

            // Verkrijg een lijst van actieve en wachtende evenementen
            var activeEvents = eventCatalog.GetEvents
                .Where(e => e.GetStatus == Status.Active || e.GetStatus == Status.Pending)
                .ToList();

            // Bereken de start- en eindtijd van het evenement
            var eventStartDateTime = eventItem.GetDate.Date + eventItem.GetStartTime;
            var eventEndDateTime = eventStartDateTime + (eventItem.GetEndTime - eventItem.GetStartTime);

            // Loop door de actieve evenementen om te kijken of er conflicten zijn
            foreach (var activeEvent in activeEvents)
            {
                var activeEventStartDateTime = activeEvent.GetDate.Date + activeEvent.GetStartTime;
                var activeEventEndDateTime = activeEventStartDateTime + (activeEvent.GetEndTime - activeEvent.GetStartTime);

                // Controleer of het evenement in dezelfde locatie en tijd valt
                if (activeEvent.Venue == eventItem.Venue &&
                    (eventStartDateTime < activeEventEndDateTime && eventEndDateTime > activeEventStartDateTime))
                {
                    return new EventConflictingResult(false, "Conflict: De geselecteerde locatie en tijd zijn al bezet door een ander evenement.");
                }
            }

            // Geen conflict gevonden
            return new EventConflictingResult(true, "Geen conflict gevonden. Het evenement kan worden ingepland.");
        }
    }
}
