﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public class EmailValidator : IEmailValidator
    {
        private readonly StudentCatalog studentCatalog;
        private readonly TeacherCatalog teacherCatalog;
        private readonly SpeakerCatalogus speakerCatalog;

        public EmailValidator(StudentCatalog studentCatalog, TeacherCatalog teacherCatalog, SpeakerCatalogus speakercatalog)
        {
            this.studentCatalog = studentCatalog;
            this.teacherCatalog = teacherCatalog;
            this.speakerCatalog = speakercatalog;

        }
        
          

        /// <summary>
        /// Deze methode checkt of de email uniek is door de catalogussen te gaan.
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        public EmailUniqueResult IsEmailUnique(string email)
        {
			Console.WriteLine($"Checking email: {email}");
			bool emailInStudents = studentCatalog.GetStudents().Any(s => s.GetEmail() == email);
           bool emailInTeachers = teacherCatalog.GetTeachers().Any(t => t.GetEmail() == email);
           bool emailInSpeakers = speakerCatalog.GetSpeakers().Any(t => t.GetEmail() == email);


            if (!emailInStudents && !emailInTeachers && !emailInSpeakers)
            {
                return new EmailUniqueResult(true, "E-mail is uniek.");
            }
            // Als de e-mail al bestaat
            return new EmailUniqueResult(false, "E-mail is niet uniek.");

        }
    }
}
