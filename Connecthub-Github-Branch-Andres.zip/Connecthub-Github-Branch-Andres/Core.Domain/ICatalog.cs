﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public interface ICatalog<T>
    {
        IReadOnlyList<T> GetItems();
        AddingResult TryAdd(T item);

    }
}
