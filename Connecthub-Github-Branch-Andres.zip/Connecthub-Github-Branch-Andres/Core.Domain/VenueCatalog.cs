﻿using Core.Domain;
using Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;

public class VenueCatalog
{
    private List<Venue> venues = new List<Venue>();
    private readonly VenueRepository _venueRepository;
    private readonly SchoolRepository _schoolRepository;

    public VenueCatalog(VenueRepository venueRepository, SchoolRepository schoolRepository)
    {
        _venueRepository = venueRepository ?? throw new ArgumentNullException(nameof(venueRepository));
        _schoolRepository = schoolRepository ?? throw new ArgumentNullException(nameof(schoolRepository));

        // Laad venues uit de database bij initialisatie
        LoadVenuesFromDatabase();
    }

    private void LoadVenuesFromDatabase()
    {
        // Haal de venueDTO's op via de repository
        var venueDTOs = _venueRepository.GetAllVenues();

        // Zet de opgehaalde VenueDTO's om naar Venue objecten en sla ze op in de lokale lijst
        venues = venueDTOs.Select(dto => new Venue(
            dto.LocationName,
            dto.Address,
            dto.RoomTypes,
            dto.Capacity,
            dto.HasElectricity,
            dto.HasProjectorOrScreen,
            dto.HasStage,
            dto.IsWheelChairAccessible
        )).ToList();
    }

    public IReadOnlyList<Venue> GetVenues => venues.AsReadOnly();

    public AddingResult TryAddVenue(Venue venue, string schoolName)
    {
        if (venue == null)
            return new AddingResult(false, "De locatie kan niet null zijn.");

        if (string.IsNullOrWhiteSpace(venue.GetLocationName))
            return new AddingResult(false, "De naam van de locatie kan niet null of leeg zijn.");

        if (venues.Any(v => v.GetLocationName.Equals(venue.GetLocationName, StringComparison.OrdinalIgnoreCase)))
            return new AddingResult(false, "Er bestaat al een locatie met dezelfde naam.");

        // Verkrijg schoolId via SchoolRepository
        int schoolId = _schoolRepository.GetSchoolIdByName(schoolName);

        // Maak een VenueDTO met de gegevens van de venue
        var venueDTO = new VenueDTO(
            schoolId,
            venue.GetLocationName,
            venue.GetAdress,
            venue.GetRoomType,
            venue.GetCapacity,
            venue.GetHasElectricity,
            venue.GetHasProjectorOrScreen,
            venue.GetHasStage,
            venue.GetIsWheelChairAccessible
        );

        // Voeg de locatie toe aan de database
        _venueRepository.AddVenue(venueDTO);

        // Voeg de locatie toe aan de lokale lijst
        venues.Add(venue);

        return new AddingResult(true, "Locatie succesvol toegevoegd aan de catalogus.");
    }

    public RemovingResult TryRemoveVenue(string locationName, string schoolName)
    {
        if (string.IsNullOrWhiteSpace(locationName))
            throw new ArgumentNullException(nameof(locationName), "Locatienaam mag niet leeg of null zijn.");

        // Zoek de venue op naam
        Venue venue = TryFindVenueByLocationName(locationName);

        // Verkrijg schoolId via SchoolRepository
        int schoolId = _schoolRepository.GetSchoolIdByName(schoolName);

        if (venue != null)
        {
            // Maak een VenueDTO van de te verwijderen venue
            var venueDTO = new VenueDTO(
                schoolId,
                venue.GetLocationName,
                venue.GetAdress,
                venue.GetRoomType,
                venue.GetCapacity,
                venue.GetHasElectricity,
                venue.GetHasProjectorOrScreen,
                venue.GetHasStage,
                venue.GetIsWheelChairAccessible
            );

            // Verwijder de locatie uit de database via de repository
            _venueRepository.RemoveVenue(venueDTO);

            // Verwijder de locatie uit de lokale lijst van venues
            venues.Remove(venue);

            return new RemovingResult(true, "Locatie succesvol verwijderd.");
        }

        return new RemovingResult(false, "Locatie niet gevonden.");
    }

    public Venue TryFindVenueByLocationName(string locationName)
    {
        if (string.IsNullOrWhiteSpace(locationName))
            throw new ArgumentNullException(nameof(locationName), "Locatienaam mag niet leeg of null zijn.");

        // Zoek de venue op locatie naam
        return venues.FirstOrDefault(v => v.GetLocationName.Equals(locationName, StringComparison.OrdinalIgnoreCase));
    }
}
