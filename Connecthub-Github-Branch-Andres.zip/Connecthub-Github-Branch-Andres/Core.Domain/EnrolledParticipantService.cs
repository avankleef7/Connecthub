﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public class EnrolledParticipantService : IParticipantService
    {
        private readonly Event _event;

        public EnrolledParticipantService(Event eventItem)
        {
            _event = eventItem;
        }

        public IEnumerable<IParticipant> GetParticipants()
        {
            return _event.GetAllEnrolledParticipants();
        }
    }

}
