﻿using Core.Domain;

public class EnrollmentManager : IEnroll
{
    private readonly EventCatalog _eventCatalog;
    private readonly AvailabilityChecker _availabilityChecker;
    private readonly LimitEventService _limitEventService;

    public EnrollmentManager(EventCatalog eventCatalog, AvailabilityChecker availabilityChecker, LimitEventService limitEventService)
    {
        _eventCatalog = eventCatalog;
        _availabilityChecker = availabilityChecker;
        _limitEventService = limitEventService;
    }

    public virtual EnrollmentResult EnrollSpeaker(Speaker speaker, Event eventItem)
    {
        if (speaker == null)
            return new EnrollmentResult(false, "Spreker kan niet null zijn.");
        if (eventItem == null)
            return new EnrollmentResult(false, "Evenement kan niet null zijn.");

        // Controleer of de deelnemer al is ingeschreven
        if (eventItem.Speakers.Contains(speaker))
        {
            return new EnrollmentResult(false, "Spreker is al ingeschreven voor dit evenement.");
        }

        // Controleer of het evenement al vol is
        if (eventItem.IsFull())
        {
            return new EnrollmentResult(false, "Evenement is vol.");
        }

        // Controleer beschikbaarheid
        var availabilityresult = _availabilityChecker.IsAvailable(speaker, eventItem);
        if (!availabilityresult.Success)
        {
            return new EnrollmentResult(false, availabilityresult.Reason);
        }

        // Controleer limieten voor sprekers
        var limitResult = _limitEventService.CheckLimit(speaker);
        if (!limitResult.Success)
        {
            return limitResult;  // Als spreker limiet is bereikt, return de fout
        }

        // Verwijder de spreker uit de lijst van uitgeschreven sprekers
        if (eventItem.unrolledSpeakers.Contains(speaker))
        {
            eventItem.TryRemoveUnenrolledSpeaker(speaker);
        }

        // Voeg deelnemer toe aan het evenement
        eventItem.TryAddSpeaker(speaker);
        return new EnrollmentResult(true, "Spreker is succesvol ingeschreven voor het evenement.");
    }

    public virtual EnrollmentResult EnrollStudent(Student student, Event eventItem)
    {
        if (student == null)
            return new EnrollmentResult(false, "Student kan niet null zijn.");
        if (eventItem == null)
            return new EnrollmentResult(false, "Evenement kan niet null zijn.");

        // Controleer of de deelnemer al is ingeschreven
        if (eventItem.Students.Contains(student))
        {
            return new EnrollmentResult(false, "Student is al ingeschreven voor dit evenement.");
        }

        // Controleer of het evenement al vol is
        if (eventItem.IsFull())
        {
            return new EnrollmentResult(false, "Evenement is vol.");
        }

        // Controleer beschikbaarheid
        var availabilityresult = _availabilityChecker.IsAvailable(student, eventItem);
        if (!availabilityresult.Success)
        {
            return new EnrollmentResult(false, availabilityresult.Reason);
        }

        // Controleer limieten voor studenten
        var limitResult = _limitEventService.CheckLimit(student);
        if (!limitResult.Success)
        {
            return limitResult;  // Als student limiet is bereikt, return de fout
        }

        // Verwijder de student uit de lijst van uitgeschreven studenten
        if (eventItem.unrolledStudents.Contains(student))
        {
            eventItem.TryRemoveUnenrolledStudent(student);
        }

        // Voeg deelnemer toe aan het evenement
        eventItem.TryAddStudent(student);
        return new EnrollmentResult(true, "Student is succesvol ingeschreven voor het evenement.");
    }

    public virtual EnrollmentResult EnrollTeacher(Teacher teacher, Event eventItem)
    {
        if (teacher == null)
            return new EnrollmentResult(false, "Docent kan niet null zijn.");
        if (eventItem == null)
            return new EnrollmentResult(false, "Evenement kan niet null zijn.");
        // Controleer of de deelnemer al is ingeschreven
        if (eventItem.Teachers.Contains(teacher))
        {
            return new EnrollmentResult(false, "Docent is al ingeschreven voor dit evenement.");
        }
        // Controleer of het evenement al vol is
        if (eventItem.IsFull())
        {
            return new EnrollmentResult(false, "Evenement is vol.");
        }

        // Controleer beschikbaarheid
        var availabilityresult = _availabilityChecker.IsAvailable(teacher, eventItem);
        if (!availabilityresult.Success)
        {
            return new EnrollmentResult(false, availabilityresult.Reason);
        }

        // Controleer limieten voor docenten
        var limitResult = _limitEventService.CheckLimit(teacher);
        if (!limitResult.Success)
        {
            return limitResult;  // Als docent limiet is bereikt, return de fout
        }

        // Verwijder de docent uit de lijst van uitgeschreven docenten
        if (eventItem.unrolledTeachers.Contains(teacher))
        {
            eventItem.TryRemoveUnenrolledTeacher(teacher);
        }

        // Voeg deelnemer toe aan het evenement
        eventItem.TryAddTeacher(teacher);
        return new EnrollmentResult(true, "Docent is succesvol ingeschreven voor het evenement.");
    }
}
