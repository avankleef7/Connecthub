﻿using Core.Domain;
using Shared;

public class VenueFactory
{
    public AddingResult CreateVenue(string locationName, string address, RoomType roomType, int capacity, VenueCatalog venueCatalog)
    {
        // Validatie voor locatie naam
        if (string.IsNullOrWhiteSpace(locationName))
            return new AddingResult(false, "Locatienaam mag niet leeg of null zijn.");

        // Validatie voor capaciteit
        if (capacity <= 0)
            return new AddingResult(false, "Capaciteit moet een positief getal zijn.");

        bool hasElectricity = false;
        bool hasProjectorOrScreen = false;
        bool hasStage = false;
        bool isWheelChairAccessible = false;

        // Logica om de booleans automatisch in te vullen op basis van RoomType
        switch (roomType)
        {
            case RoomType.Classroom:
                if (capacity > 30)
                    return new AddingResult(false, "Klaslokaal kan geen capaciteit groter dan 30 hebben.");
                hasElectricity = true;
                hasProjectorOrScreen = true;
                break;

            case RoomType.Auditorium:
                if (capacity < 100 || capacity > 500)
                    return new AddingResult(false, "Auditorium moet een capaciteit hebben tussen 100 en 500.");
                hasElectricity = true;
                hasProjectorOrScreen = true;
                hasStage = true;
                break;

            case RoomType.Laboratory:
                if (capacity > 30)
                    return new AddingResult(false, "Laboratorium kan geen capaciteit groter dan 30 hebben.");
                hasElectricity = true;
                break;

            case RoomType.Gym:
                if (capacity < 50)
                    return new AddingResult(false, "Gym moeten een capaciteit van ten minste 50 hebben.");
                hasElectricity = true;
                isWheelChairAccessible = true;
                break;

            case RoomType.Office:
                if (capacity > 10)
                    return new AddingResult(false, "Kantoor kan geen capaciteit groter dan 10 hebben.");
                hasElectricity = true;
                break;

            default:
                return new AddingResult(false, "Ongeldig kamertype.");
        }

        // Venue aanmaken + probeer de Venue toe te voegen aan de catalogus
        Venue venue = new Venue(locationName, address, roomType, capacity, hasElectricity, hasProjectorOrScreen, hasStage, isWheelChairAccessible);

        AddingResult isAddedToVenueCatalog = venueCatalog.TryAddVenue(venue, SchoolManager.Instance.Name);
        if (!isAddedToVenueCatalog.Success)
        {
            return new AddingResult(false, "Het toevoegen van de locatie aan de catalogus is mislukt. Het kan al bestaan.");
        }
        return new AddingResult(true, isAddedToVenueCatalog.Reason);
    }
}
