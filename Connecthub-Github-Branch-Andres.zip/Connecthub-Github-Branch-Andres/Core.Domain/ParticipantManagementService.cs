﻿using Core.Domain;
using Shared;

public class ParticipantManagementService
{
    private readonly StudentCatalog _studentCatalog;
    private readonly TeacherCatalog _teacherCatalog;
    private readonly SpeakerCatalogus _speakerCatalog;

    public ParticipantManagementService(StudentCatalog studentCatalog, TeacherCatalog teacherCatalog, SpeakerCatalogus speakerCatalog)
    {
        _studentCatalog = studentCatalog;
        _teacherCatalog = teacherCatalog;
        _speakerCatalog = speakerCatalog;
    }

    public RemovingResult RemoveParticipant(string email, string departmentName, ParticipantType participantType)
    {

        switch (participantType)
        {
            case ParticipantType.Student:
                return _studentCatalog.TryRemoveStudent(email, departmentName); 
            case ParticipantType.Teacher:
                return _teacherCatalog.TryRemoveTeacher(email, departmentName);
            case ParticipantType.Speaker:
                var speaker = _speakerCatalog.FindSpeakerByEmail(email);
                return _speakerCatalog.TryRemoveSpeaker(email);
            default:
                return new RemovingResult(false, "Ongeldig participant type.");
        }
    }
}
