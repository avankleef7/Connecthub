﻿using System;
using System.Linq;
using Core.Domain;

namespace Core.Domain
{
    public class SpeakerEventManager
    {
        private readonly EventCatalog _eventCatalog;
        private readonly AvailabilityChecker _availabilityChecker;

        public SpeakerEventManager(EventCatalog eventCatalog, AvailabilityChecker availabilityChecker)
        {
            _eventCatalog = eventCatalog;
            _availabilityChecker = availabilityChecker;
        }

        public EnrollmentResult SpeakerToEvent(Speaker speaker, Event eventItem)
        {
            if (speaker == null)
                throw new ArgumentNullException(nameof(speaker), "Spreker kan niet null zijn.");
            if (eventItem == null)
                throw new ArgumentNullException(nameof(eventItem), "Evenement kan niet null zijn.");

            // Controleer of de spreker al is ingeschreven
            if (eventItem.Speakers.Contains(speaker))
            {
                return new EnrollmentResult(false, "Spreker is al ingeschreven voor dit evenement.");
            }

            var availabilityresult = _availabilityChecker.IsAvailable(speaker, eventItem);
            if (!availabilityresult.Success)
            {
                return new EnrollmentResult(false, availabilityresult.Reason);
            }
            // Voeg de spreker toe aan het evenement
            eventItem.TryAddSpeaker(speaker);

            return new EnrollmentResult(true, "Spreker is succesvol toegevoegd aan het evenement.");
        }
        
        public EnrollmentResult RemoveSpeakerFromEvent(Speaker speaker, Event eventItem)
        {
            if (speaker == null)
                throw new ArgumentNullException(nameof(speaker), "Spreker kan niet null zijn.");
            if (eventItem == null)
                throw new ArgumentNullException(nameof(eventItem), "Evenement kan niet null zijn.");

            // Controleer of de spreker al is ingeschreven
            if (!eventItem.Speakers.Contains(speaker))
            {
                return new EnrollmentResult(false, "Spreker is niet ingeschreven voor dit evenement.");
            }

            // Verwijder de spreker van het evenement
            bool removed = eventItem.TryRemoveSpeaker(speaker);
            if (removed)
            {
                return new EnrollmentResult(true, "Spreker is succesvol verwijderd van het evenement.");
            }
            else
            {
                return new EnrollmentResult(false, "Kan de spreker niet verwijderen van het evenement.");
            }
        }
    }
}
