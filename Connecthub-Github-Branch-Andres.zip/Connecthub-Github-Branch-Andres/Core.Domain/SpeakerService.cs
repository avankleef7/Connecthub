﻿using Core.Domain.Helperclasses;
using Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    public class SpeakerService
    {
        private readonly DepartmentCapacityValidator departmentCapacityValidator;
        private readonly IEmailValidator emailValidator;

		public SpeakerService(IEmailValidator emailValidator)
		{
			this.departmentCapacityValidator = new DepartmentCapacityValidator();
			this.emailValidator = emailValidator;
		}

		public AddingResult CreateSpeaker(string firstname, string lastname, Gender gender, DateTime dateofbirth, string email, string organization, string position, StudentCatalog studentCatalog, TeacherCatalog teacherCatalog, SpeakerCatalogus speakerCatalogus)
        {
            // Maak een nieuwe spreker aan voor validatie
            Speaker speaker = new Speaker(firstname, lastname, gender, dateofbirth, email, organization, position);

            // Valideer de spreker met de SpeakerValidator
            SpeakerValidator speakerValidator = new SpeakerValidator(emailValidator, departmentCapacityValidator);
            ValidationResult validationResult = speakerValidator.Validate(speaker);
            // Als de validatie mislukt, retourneer het resultaat
            if (!validationResult.Success)
            {
                return new AddingResult(false, validationResult.Reason);
            }

            // Voeg de spreker toe aan de spreker catalogus
            speakerCatalogus.TryAddSpeaker(speaker);

            return new AddingResult(true, "Speaker is created successfully");
        }
    }
}
