﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain
{
    /// <summary>
    /// De IParticipantService is een interface die zorgt ervoor
    /// dat de klassen die dit implementeert een lijst van IParticipants terug geeft
    /// </summary>
    public interface IParticipantService
    {
        IEnumerable<IParticipant> GetParticipants();
    }
}
