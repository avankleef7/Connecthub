﻿using Core.Domain.Helperclasses;
using Core.DTO;
using Shared;
using System;

namespace Core.Domain
{
    public class Student : IParticipant
    {
        private string FirstName;
        private string LastName;
        private DateTime DateOfBirth;
        private Gender _Gender;
        private Nationality _Nationality;
        private string Email;
        private Department _department;

        public int GetAge => DateTimeHelper.CalculateYearsToDate(DateOfBirth);

        public Gender GetGender => _Gender;

        public Nationality GetNationality => _Nationality;

        public string GetFirstName => FirstName;
        public string GetLastName => LastName;
        public string GetEmail() => Email;
        public DateTime GetDateOfBirth() => DateOfBirth;

       
        public Department GetDepartment => _department;


        public Student(string firstname, string lastname, Gender gender, Nationality nationality, DateTime dateofbirth, string email, Department department)
        {
            // Validatie voor voornaam
            if (string.IsNullOrWhiteSpace(firstname)) throw new ArgumentNullException(nameof(firstname), "Firstname cannot be empty or null.");
            // Validatie voor achternaam
            if (string.IsNullOrWhiteSpace(lastname)) throw new ArgumentNullException(nameof(lastname), "Lastname cannot be empty or null.");
            // Validatie voor datum van geboorte (moet in het verleden liggen)
            if (dateofbirth >= DateTime.Now) throw new ArgumentOutOfRangeException(nameof(dateofbirth), "Date of birth must be in the past.");
            // Validatie voor e-mail (eenvoudige controle)
            if (string.IsNullOrWhiteSpace(email) || !email.Contains("@")) throw new ArgumentException("Email is invalid.", nameof(email));
            if (department == null)
                throw new ArgumentNullException(nameof(department), "Department cannot be null.");

            // Toewijzing van waarden
            this.FirstName = firstname;
            this.LastName = lastname;
            this._Gender = gender;
            this._Nationality = nationality;
            this.DateOfBirth = dateofbirth;
            this.Email = email;
            this._department = department;
        }


        public override string ToString()
        {
            return $"{GetFirstName} {GetLastName}, Age: {GetAge}, Email: {GetEmail()}, Department: {GetDepartment.GetName}";
        }

       


    }
}
