﻿using Core.DTO;
using Infrastructure;

namespace Core.Domain
{
    public class StudentCatalog : IStudentRepository
    {
        private readonly StudentRepository _studentRepository;
        private readonly DepartmentRepository _departmentRepository;
        private readonly DepartmentCatalog _departmentCatalog;

        private List<Student> students = new List<Student>();

        public StudentCatalog(StudentRepository studentRepository, DepartmentRepository departmentRepository, DepartmentCatalog departmentCatalog)
        {
            _studentRepository = studentRepository ?? throw new ArgumentNullException(nameof(studentRepository));
            _departmentRepository = departmentRepository ?? throw new ArgumentNullException(nameof(departmentRepository));
            _departmentCatalog = departmentCatalog ?? throw new ArgumentNullException(nameof(departmentCatalog));

            // Laad de studentenlijst uit de database bij initialisatie
            LoadStudentsFromDatabase();
        }

        private void LoadStudentsFromDatabase()
        {
            // Haal alle studenten op uit de database via de repository
            var studentDTOs = _studentRepository.GetAllStudents();

            // Zet de opgehaalde studenten om naar Student objecten
            students = studentDTOs.Select(dto =>
            {
                string departmentName = _departmentRepository.GetDepartmentNameById(dto.DepartmentID);
                var department = _departmentCatalog.TryFindDepartmentByName(departmentName);

                return new Student(
                    dto.FirstName,
                    dto.LastName,
                    dto.Gender,
                    dto.Nationality,
                    dto.DateOfBirth,
                    dto.Email,
                    department
                );
            }).ToList();
        }

        public IReadOnlyList<Student> GetStudents() => this.students.AsReadOnly();

        public AddingResult TryAddStudent(Student student, string departmentName)
        {
            if (student == null)
                throw new ArgumentNullException(nameof(student), "Student kan niet null zijn, niet toegevoegd");

            // Zoek de juiste DepartmentId via de DepartmentRepository
            int departmentId = _departmentRepository.GetDepartmentIdByName(departmentName);

            if (departmentId == 0)
            {
                return new AddingResult(false, "Department niet gevonden.");
            }

            // Maak een StudentDTO aan van de student
            var studentDTO = new StudentDTO(
                departmentId,
                student.GetFirstName,
                student.GetLastName,
                student.GetDateOfBirth(),
                student.GetGender,
                student.GetNationality,
                student.GetEmail()
            );

            // Voeg de student toe aan de database via de StudentRepository
            _studentRepository.AddStudent(studentDTO, departmentId);

            // Voeg de student toe aan de lokale lijst in de catalogus
            students.Add(student);

            // Laad de lijst van studenten opnieuw vanuit de database om de laatste wijzigingen te reflecteren
            LoadStudentsFromDatabase();

            return new AddingResult(true, "Student succesvol toegevoegd.");
        }

        public RemovingResult TryRemoveStudent(string email, string departmentName)
        {
            if (string.IsNullOrWhiteSpace(email))
                return new RemovingResult(false, "Email kan niet leeg zijn, verwijdering niet geslaagd.");

            var student = FindStudentByEmail(email);

            if (student == null)
                return new RemovingResult(false, "Student niet gevonden in de catalogus.");

            var department = _departmentCatalog.TryFindDepartmentByName(departmentName);

            if (department == null)
                return new RemovingResult(false, "Department niet gevonden.");

            // Verwijder de student uit de catalogus
            if (students.Remove(student))
            {
                int departmentId = _departmentRepository.GetDepartmentIdByName(departmentName);

                if (departmentId == 0)
                    return new RemovingResult(false, "Department ID niet gevonden.");

                // Maak een StudentDTO voor de student die we willen verwijderen
                var studentDTO = new StudentDTO(
                    departmentId,
                    student.GetFirstName,
                    student.GetLastName,
                    student.GetDateOfBirth(),
                    student.GetGender,
                    student.GetNationality,
                    student.GetEmail()
                );

                // Verwijder de student uit de database
                _studentRepository.RemoveStudent(studentDTO);

                return new RemovingResult(true, "Student succesvol verwijdert uit de catalogus en afdeling.");
            }

            return new RemovingResult(false, "Student niet gevonden in de catalogus.");
        }

        public Student FindStudentByEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                throw new ArgumentException("Email mag niet leeg zijn.", nameof(email));

            // Zoek de student op basis van e-mail
            Student student = students.FirstOrDefault(s => s.GetEmail().Equals(email, StringComparison.OrdinalIgnoreCase));

            if (student == null)
            {
                throw new InvalidOperationException("Geen student gevonden met het opgegeven e-mailadres.");
            }

            return student;
        }

        internal IEnumerable<IParticipant> GetAllParticipants()
        {
            return students.Cast<IParticipant>().ToList();
        }
    }
}
