﻿using Microsoft.Data.SqlClient;
using Core.DTO;
using Shared;
using System;
using System.Collections.Generic;
using System.Data;

namespace Infrastructure
{
    public class DepartmentRepository
    {
        private readonly string _connectionString;

        public DepartmentRepository(string connectionString)
        {
            _connectionString = connectionString;
        }


        public void AddDepartment(DepartmentDTO departmentDTO)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = new SqlCommand("INSERT INTO department (Name, Description, StudentCapacity, TeacherCapacity, DepartmentType, SchoolID) VALUES (@Name, @Description, @StudentCapacity, @TeacherCapacity, @DepartmentType, @SchoolID)", connection);
                command.Parameters.AddWithValue("@Name", departmentDTO.Name);
                command.Parameters.AddWithValue("@Description", departmentDTO.Description);
                command.Parameters.AddWithValue("@StudentCapacity", departmentDTO.StudentCapacity);
                command.Parameters.AddWithValue("@TeacherCapacity", departmentDTO.TeacherCapacity);
                command.Parameters.AddWithValue("@DepartmentType", departmentDTO.DepartmentType);
                command.Parameters.AddWithValue("@SchoolID", departmentDTO.SchoolId);

                command.ExecuteNonQuery();

            }
        }

        public List<DepartmentDTO> GetAllDepartments()
        {
            List<DepartmentDTO> departments = new List<DepartmentDTO>();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var departmentCommand = new SqlCommand("SELECT Name, Description, StudentCapacity, TeacherCapacity, DepartmentType, SchoolId FROM department", connection);
                using (var reader = departmentCommand.ExecuteReader())
                {
                    while (reader.Read())
                    {


                        departments.Add(new DepartmentDTO(

                            reader.GetInt32("SchoolId"),
                            reader.GetString("Name"),
                            reader.GetString("Description"),
                            reader.GetInt32("StudentCapacity"),
                            reader.GetInt32("TeacherCapacity"),
                            (DepartmentType)reader.GetInt32("DepartmentType")
                        ));
                    }
                }
            }

            return departments;
        }

        public void RemoveDepartment(string departmentName)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                // Verwijder eerst de studenten en docenten (bijvoorbeeld cascading verwijderen, afhankelijk van je databasemodel)
                var deleteStudents = new SqlCommand("DELETE FROM student WHERE DepartmentId IN (SELECT DepartmentID FROM department WHERE Name = @DepartmentName)", connection);
                deleteStudents.Parameters.AddWithValue("@DepartmentName", departmentName);
                deleteStudents.ExecuteNonQuery();

                var deleteTeachers = new SqlCommand("DELETE FROM teacher WHERE DepartmentId IN (SELECT DepartmentID FROM department WHERE Name = @DepartmentName)", connection);
                deleteTeachers.Parameters.AddWithValue("@DepartmentName", departmentName);
                deleteTeachers.ExecuteNonQuery();

                // Verwijder de afdeling zelf (op basis van de naam)
                var command = new SqlCommand("DELETE FROM department WHERE Name = @DepartmentName", connection);
                command.Parameters.AddWithValue("@DepartmentName", departmentName);

                command.ExecuteNonQuery();
            }
        }

        // Voeg deze functie toe aan je DepartmentRepository
        public int GetDepartmentIdByName(string departmentName)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = new SqlCommand("SELECT DepartmentId FROM department WHERE Name = @DepartmentName", connection);
                command.Parameters.AddWithValue("@DepartmentName", departmentName);

                var departmentId = command.ExecuteScalar();

                if (departmentId == null)
                {
                    throw new Exception("Department not found");
                }

                return (int)departmentId;
            }


        }
        public string GetDepartmentNameById(int departmentId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = new SqlCommand("SELECT Name FROM Department WHERE DepartmentID = @DepartmentID", connection);
                command.Parameters.AddWithValue("@DepartmentID", departmentId);

                var result = command.ExecuteScalar();

                if (result != null)
                {
                    return result.ToString();
                }
            }

            // Als het department niet gevonden wordt, kan je hier een foutmelding gooien of een default waarde teruggeven
            throw new InvalidOperationException($"Department met ID {departmentId} niet gevonden.");
        }



    }
}



