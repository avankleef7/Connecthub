﻿using Microsoft.Data.SqlClient;
using System;

namespace Infrastructure
{
    public class GetParticpantByEmail
    {
        private readonly string _connectionString;

        public GetParticpantByEmail(string connectionString)
        {
            _connectionString = connectionString;
        }

        public int GetSpeakerIdByEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                throw new ArgumentException("Email cannot be null or empty.", nameof(email));

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand(
                    @"SELECT Id FROM speakers WHERE Email = @Email", connection);

                command.Parameters.AddWithValue("@Email", email);

                var result = command.ExecuteScalar();
                if (result != null && int.TryParse(result.ToString(), out int speakerId))
                {
                    return speakerId;
                }

                throw new Exception($"Speaker with email '{email}' not found.");
            }
        }

        public int GetStudentIdByEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                throw new ArgumentException("Email cannot be null or empty.", nameof(email));

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand(
                    @"SELECT Id FROM students WHERE Email = @Email", connection);

                command.Parameters.AddWithValue("@Email", email);

                var result = command.ExecuteScalar();
                if (result != null && int.TryParse(result.ToString(), out int studentId))
                {
                    return studentId;
                }

                throw new Exception($"Student with email '{email}' not found.");
            }
        }

        public int GetTeacherIdByEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                throw new ArgumentException("Email cannot be null or empty.", nameof(email));

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand(
                    @"SELECT Id FROM teachers WHERE Email = @Email", connection);

                command.Parameters.AddWithValue("@Email", email);

                var result = command.ExecuteScalar();
                if (result != null && int.TryParse(result.ToString(), out int teacherId))
                {
                    return teacherId;
                }

                throw new Exception($"Teacher with email '{email}' not found.");
            }
        }
    }
}
