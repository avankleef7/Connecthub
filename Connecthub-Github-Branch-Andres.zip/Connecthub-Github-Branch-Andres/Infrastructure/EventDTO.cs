﻿using Core.DTO;
using Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure
{
    //Check push check nogmaalg
    public class EventDTO
    {
        public string Title { get; set; }
        public EventType EventType { get; set; }
        public int DepartmentId { get; set; }
        public Status Status { get; set; }
        public DateTime Date { get; set; }
        public TimeSpan StartTime { get; set; }
        public DateTime EndDate { get; set; }
        public TimeSpan EndTime { get; set; }
        public string Description { get; set; }
        public int VenueId { get; set; }
        public int Capacity { get; set; }

        public List<SpeakerDTO> EnrolledSpeakers { get; set; }
        public List<StudentDTO> EnrolledStudents { get; set; }
        public List<TeacherDTO> EnrolledTeachers { get; set; }
        public List<SpeakerDTO> UnenrolledSpeakers { get; set; }
        public List<StudentDTO> UnenrolledStudents { get; set; }
        public List<TeacherDTO> UnenrolledTeachers { get; set; }

       
        public EventDTO(string title, EventType eventType, int departmentid, Status status, DateTime date, TimeSpan startTime, DateTime endDate, TimeSpan endTime, string description, int venueid, int capacity,
                        List<SpeakerDTO> enrolledSpeakers, List<StudentDTO> enrolledStudents, List<TeacherDTO> enrolledTeachers,
                        List<SpeakerDTO> unenrolledSpeakers, List<StudentDTO> unenrolledStudents, List<TeacherDTO> unenrolledTeachers)
        {
            Title = title;
            EventType = eventType;
            DepartmentId = departmentid;
            Status = status;
            Date = date;
            StartTime = startTime;
            EndDate = endDate;
            EndTime = endTime;
            Description = description;
            VenueId = venueid;
            Capacity = capacity;
            EnrolledSpeakers = enrolledSpeakers ?? new List<SpeakerDTO>();
            EnrolledStudents = enrolledStudents ?? new List<StudentDTO>();
            EnrolledTeachers = enrolledTeachers ?? new List<TeacherDTO>();
            UnenrolledSpeakers = unenrolledSpeakers ?? new List<SpeakerDTO>();
            UnenrolledStudents = unenrolledStudents ?? new List<StudentDTO>();
            UnenrolledTeachers = unenrolledTeachers ?? new List<TeacherDTO>();
        }
    }
}

