﻿using Microsoft.Data.SqlClient;
using Core.DTO;
using Shared;
using System;
using System.Collections.Generic;
using System.Data;

namespace Infrastructure
{
    public class SchoolRepository
    {
        private readonly string _connectionString;

        public SchoolRepository(string connectionString)
        {
            _connectionString = connectionString;
        }
        
        public bool SchoolExists(string schoolName)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = new SqlCommand("SELECT COUNT(1) FROM School WHERE Name = @Name", connection);
                command.Parameters.AddWithValue("@Name", schoolName);

                return (int)command.ExecuteScalar() > 0;
            }
        }

        
        public void AddSchool(SchoolDTO schoolDTO)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = new SqlCommand("INSERT INTO School (Name) VALUES (@Name); SELECT SCOPE_IDENTITY();", connection);
                command.Parameters.AddWithValue("@Name", schoolDTO.Name);

                var schoolId = Convert.ToInt32(command.ExecuteScalar());

            }
        }
        public int GetSchoolIdByName(string schoolName)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = new SqlCommand("SELECT SchoolId FROM School WHERE Name = @Name", connection);
                command.Parameters.AddWithValue("@Name", schoolName);

                var result = command.ExecuteScalar();
                return result != null ? (int)result : throw new InvalidOperationException("School not found.");
            }
        }

       


    }
}
