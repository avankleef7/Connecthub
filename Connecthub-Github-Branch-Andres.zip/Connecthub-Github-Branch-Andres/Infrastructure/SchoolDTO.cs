﻿using Core.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure
{
    public class SchoolDTO
    {
        public string Name { get; set; }
        public List<DepartmentDTO> Departments { get; set; }
        public List<VenueDTO> Venues { get; set; }

        public SchoolDTO(string name, List<DepartmentDTO> departments, List<VenueDTO> venues)
        {
            Name = name;
            Departments = departments ?? new List<DepartmentDTO>();
            Venues = venues ?? new List<VenueDTO>();
        }
    }
}
