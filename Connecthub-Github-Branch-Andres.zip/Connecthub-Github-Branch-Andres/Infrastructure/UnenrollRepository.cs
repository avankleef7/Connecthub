﻿using Microsoft.Data.SqlClient;
using System;

namespace Infrastructure
{
    public class UnenrollRepository
    {
        private readonly string _connectionString;
        private readonly GetParticpantByEmail _getParticipantByEmail;

        public UnenrollRepository(string connectionString)
        {
            _connectionString = connectionString;
            _getParticipantByEmail = new GetParticpantByEmail(_connectionString);
        }

        public void AddUnenrolledSpeaker(int eventId, string speakerEmail)
        {
            var speakerId = _getParticipantByEmail.GetSpeakerIdByEmail(speakerEmail);
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand(
                    @"INSERT INTO UnenrolledSpeakers (EventId, SpeakerId)
                      VALUES (@EventId, @SpeakerId)", connection);

                command.Parameters.AddWithValue("@EventId", eventId);
                command.Parameters.AddWithValue("@SpeakerId", speakerId);

                command.ExecuteNonQuery();
            }
        }

        public void RemoveUnenrolledSpeaker(int eventId, string speakerEmail)
        {
            var speakerId = _getParticipantByEmail.GetSpeakerIdByEmail(speakerEmail);

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand(
                    @"DELETE FROM UnenrolledSpeakers 
                      WHERE EventId = @EventId AND SpeakerId = @SpeakerId", connection);

                command.Parameters.AddWithValue("@EventId", eventId);
                command.Parameters.AddWithValue("@SpeakerId", speakerId);

                command.ExecuteNonQuery();
            }
        }

        public void AddUnenrolledStudent(int eventId, string studentEmail)
        {
            var studentId = _getParticipantByEmail.GetStudentIdByEmail(studentEmail);
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand(
                    @"INSERT INTO UnenrolledStudents (EventId, StudentId)
                      VALUES (@EventId, @StudentId)", connection);

                command.Parameters.AddWithValue("@EventId", eventId);
                command.Parameters.AddWithValue("@StudentId", studentId);

                command.ExecuteNonQuery();
            }
        }

        public void RemoveUnenrolledStudent(int eventId, string studentEmail)
        {
            var studentId = _getParticipantByEmail.GetStudentIdByEmail(studentEmail);

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand(
                    @"DELETE FROM UnenrolledStudents 
                      WHERE EventId = @EventId AND StudentId = @StudentId", connection);

                command.Parameters.AddWithValue("@EventId", eventId);
                command.Parameters.AddWithValue("@StudentId", studentId);

                command.ExecuteNonQuery();
            }
        }

        public void AddUnenrolledTeacher(int eventId, string teacherEmail)
        {
            var teacherId = _getParticipantByEmail.GetTeacherIdByEmail(teacherEmail);
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand(
                    @"INSERT INTO UnenrolledTeachers (EventId, TeacherId)
                      VALUES (@EventId, @TeacherId)", connection);

                command.Parameters.AddWithValue("@EventId", eventId);
                command.Parameters.AddWithValue("@TeacherId", teacherId);

                command.ExecuteNonQuery();
            }
        }

        public void RemoveUnenrolledTeacher(int eventId, string teacherEmail)
        {
            var teacherId = _getParticipantByEmail.GetTeacherIdByEmail(teacherEmail);

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand(
                    @"DELETE FROM UnenrolledTeachers 
                      WHERE EventId = @EventId AND TeacherId = @TeacherId", connection);

                command.Parameters.AddWithValue("@EventId", eventId);
                command.Parameters.AddWithValue("@TeacherId", teacherId);

                command.ExecuteNonQuery();
            }
        }
    }
}
