﻿using Shared;

namespace Core.DTO
{
    public class StudentDTO
    {

        public int DepartmentID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public Gender Gender { get; set; }
        public Nationality Nationality { get; set; }
        public string Email { get; set; }

        public StudentDTO(int departmentid, string firstName, string lastName, DateTime dateOfBirth, Gender gender, Nationality nationality, string email)
        {
            DepartmentID = departmentid;
            FirstName = firstName;
            LastName = lastName;
            DateOfBirth = dateOfBirth;
            Gender = gender;
            Nationality = nationality;
            Email = email;
           
        }

        
    }
}
