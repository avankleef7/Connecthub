﻿using Core.DTO;
using Microsoft.Data.SqlClient;
using Shared;
using System;
using System.Collections.Generic;
using System.Data;
using Infrastructure.HelperklassesInfrastructure;

namespace Infrastructure
{
    public class VenueRepository
    {
        private readonly string _connectionString;

        public VenueRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public void AddVenue(VenueDTO venue)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand(
                    "INSERT INTO Venue (SchoolID, LocationName, Address, RoomType, Capacity, HasElectricity, HasProjectorOrScreen, HasStage, IsWheelChair) " +
                    "VALUES (@SchoolID, @LocationName, @Address, @RoomType, @Capacity, @HasElectricity, @HasProjectorOrScreen, @HasStage, @IsWheelChair)",
                    connection);

                // Parameterwaarden toevoegen
                command.Parameters.AddWithValue("@SchoolID", venue.SchoolId);
                command.Parameters.AddWithValue("@LocationName", venue.LocationName);
                command.Parameters.AddWithValue("@Address", venue.Address);
                command.Parameters.AddWithValue("@RoomType", venue.RoomTypes);
                command.Parameters.AddWithValue("@Capacity", venue.Capacity);
                command.Parameters.AddWithValue("@HasElectricity", venue.HasElectricity);
                command.Parameters.AddWithValue("@HasProjectorOrScreen", venue.HasProjectorOrScreen);
                command.Parameters.AddWithValue("@HasStage", venue.HasStage);
                command.Parameters.AddWithValue("@IsWheelChair", venue.IsWheelChairAccessible);

                command.ExecuteNonQuery();
            }
        }

        public IReadOnlyList<VenueDTO> GetAllVenues()
        {
            var venues = new List<VenueDTO>();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand("SELECT SchoolID, LocationName, Address, RoomType, Capacity, HasElectricity, HasProjectorOrScreen, HasStage, IsWheelChair FROM Venue", connection);

                using var reader = command.ExecuteReader();
                {
                    while (reader.Read())
                    {
                        venues.Add(new VenueDTO(
                            schoolid: reader.GetInt32(reader.GetOrdinal("SchoolID")),
                            locationName: reader.GetString(reader.GetOrdinal("LocationName")),
                            address: reader.GetString(reader.GetOrdinal("Address")),
                            roomType: (RoomType)reader.GetInt32(reader.GetOrdinal("RoomType")),
                            capacity: reader.GetInt32(reader.GetOrdinal("Capacity")),
                            hasElectricity: ConvertData.ConvertToBool(reader["HasElectricity"]),
                            hasProjectorOrScreen: ConvertData.ConvertToBool(reader["HasProjectorOrScreen"]),
                            hasStage: ConvertData.ConvertToBool(reader["HasStage"]),
                            isWheelChairAccessible: ConvertData.ConvertToBool(reader["IsWheelChair"])
                        ));
                    }
                }
            }

            return venues;
        }

        public void RemoveVenue(VenueDTO venue)
        {
           
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand("DELETE FROM Venue WHERE LocationName = @LocationName AND SchoolId = @SchoolId", connection);

                command.Parameters.AddWithValue("@LocationName", venue.LocationName);
                command.Parameters.AddWithValue("@SchoolId", venue.SchoolId);

                command.ExecuteNonQuery();
            }
        }

        public int GetVenueIDbyName(string venueName)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = new SqlCommand("SELECT VenueId FROM venue WHERE LocationName = @LocationName", connection);
                command.Parameters.AddWithValue("@LocationName", venueName);

                var venueId = command.ExecuteScalar();

                if (venueId == null)
                {
                    throw new Exception("Venue not found");
                }

                return (int) venueId;
            }


        }
        public string GetVenueNameByID(int venueId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = new SqlCommand("SELECT LocationName FROM Venue WHERE VenueID = @VenueID", connection);
                command.Parameters.AddWithValue("@VenueID", venueId);

                var result = command.ExecuteScalar();

                if (result != null)
                {
                    return result.ToString();
                }
            }

            // Als het department niet gevonden wordt, kan je hier een foutmelding gooien of een default waarde teruggeven
            throw new InvalidOperationException($"Venue met ID {venueId} niet gevonden.");
        }



    }
}
