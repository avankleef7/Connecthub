﻿using Microsoft.Data.SqlClient;
using Shared;
using Core.DTO;
using System;
using System.Collections.Generic;

namespace Infrastructure
{
    public class TeacherRepository
    {
        private readonly string _connectionString;

        private readonly DepartmentRepository _departmentRepository;

        public TeacherRepository(string connectionString, DepartmentRepository departmentRepository)
        {
            _connectionString = connectionString;
            _departmentRepository = departmentRepository;
        }

        public IReadOnlyList<TeacherDTO> GetAllTeachers()
        {
            var teachers = new List<TeacherDTO>();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = new SqlCommand("SELECT FirstName, LastName, DateOfBirth, Gender, Email, DepartmentID FROM teacher", connection);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        
                        var teacher = new TeacherDTO(
                            departmentID: reader.GetInt32(reader.GetOrdinal("DepartmentID")),
                            firstName: reader.GetString(reader.GetOrdinal("FirstName")),
                            lastName: reader.GetString(reader.GetOrdinal("LastName")),
                            dateOfBirth: reader.GetDateTime(reader.GetOrdinal("DateOfBirth")),
                            gender: (Gender)reader.GetInt32(reader.GetOrdinal("Gender")),
                            email: reader.GetString(reader.GetOrdinal("Email"))
                        );
                        teachers.Add(teacher);

                    }
                }
            }

            return teachers;
        }



        public void AddTeacher(TeacherDTO teacher, int departmentId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                        
                var command = new SqlCommand("INSERT INTO teacher (FirstName, LastName, DateOfBirth, Gender, Email, DepartmentID) " +
                                             "VALUES (@FirstName, @LastName, @DateOfBirth, @Gender, @Email, @DepartmentID)", connection);

                command.Parameters.AddWithValue("@FirstName", teacher.FirstName);
                command.Parameters.AddWithValue("@LastName", teacher.LastName);
                command.Parameters.AddWithValue("@DateOfBirth", teacher.DateOfBirth);
                command.Parameters.AddWithValue("@Gender", teacher.Gender);
                command.Parameters.AddWithValue("@Email", teacher.Email);
                command.Parameters.AddWithValue("@DepartmentID", departmentId); 

                command.ExecuteNonQuery();
            }
        }



        public void RemoveTeacher(TeacherDTO teacher)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand("DELETE FROM teacher WHERE Email = @Email", connection);

                command.Parameters.AddWithValue("@Email", teacher.Email);

                command.ExecuteNonQuery();
            }
        }
    }
}
