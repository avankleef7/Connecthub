﻿using Core.DTO;
using Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure
{
    public class SpeakerDTO
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public Gender Gender { get; set; }
        public string Email { get; set; }
        public string Organization { get; set; }
        public string Position { get; set; }


        public SpeakerDTO(string firstName, string lastName, DateTime dateOfBirth, Gender gender, string email, string organization, string position)
        {
            FirstName = firstName;
            LastName = lastName;
            DateOfBirth = dateOfBirth;
            Gender = gender;
            Email = email;
            Organization = organization;
            Position = position;
            
        }
    }
}
