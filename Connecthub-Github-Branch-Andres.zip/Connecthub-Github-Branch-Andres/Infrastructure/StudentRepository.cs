﻿using Microsoft.Data.SqlClient;
using Shared;
using Core.DTO;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure
{
    public class StudentRepository
    {
        private readonly string _connectionString;

        public StudentRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public IReadOnlyList<StudentDTO> GetAllStudents()
        {
            var students = new List<StudentDTO>();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = new SqlCommand("SELECT FirstName, LastName, DateOfBirth, Gender, Nationality, Email, DepartmentID FROM student", connection);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {

                        var student = new StudentDTO(
                            departmentid: reader.GetInt32(reader.GetOrdinal("DepartmentID")),
                            firstName: reader.GetString(reader.GetOrdinal("FirstName")),
                            lastName: reader.GetString(reader.GetOrdinal("LastName")),
                            dateOfBirth: reader.GetDateTime(reader.GetOrdinal("DateOfBirth")),
                            gender: (Gender)reader.GetInt32(reader.GetOrdinal("Gender")),
                            nationality: (Nationality)reader.GetInt32(reader.GetOrdinal("Nationality")),
                            email: reader.GetString(reader.GetOrdinal("Email"))
                        );
                        students.Add(student);

                    }
                }
            }

            return students;
        }
        public void AddStudent(StudentDTO student, int departmentId)
        {
            using (var connection = new SqlConnection(_connectionString)) 
            {
                connection.Open();
                var command = new SqlCommand("INSERT INTO student (FirstName, LastName, DateOfBirth, Gender, Nationality, Email, DepartmentID) " +
                                             "VALUES (@FirstName, @LastName, @DateOfBirth, @Gender, @Nationality, @Email, @DepartmentID)", connection);

                command.Parameters.AddWithValue("@FirstName", student.FirstName);
                command.Parameters.AddWithValue("@LastName", student.LastName);
                command.Parameters.AddWithValue("@DateOfBirth", student.DateOfBirth);
                command.Parameters.AddWithValue("@Gender", student.Gender);
                command.Parameters.AddWithValue("@Nationality", student.Nationality);
                command.Parameters.AddWithValue("@Email", student.Email);
                command.Parameters.AddWithValue("@DepartmentID", departmentId);

                command.ExecuteNonQuery();
            }
        }

        // Verwijder een student uit de database
        public void RemoveStudent(StudentDTO student)
        {
            using (var connection = new SqlConnection(_connectionString)) // Gebruik SqlConnection voor SQL Server
            {
                connection.Open();
                var command = new SqlCommand("DELETE FROM student WHERE Email = @Email", connection);

                command.Parameters.AddWithValue("@Email", student.Email);

                command.ExecuteNonQuery();
            }
        }

    }
}
