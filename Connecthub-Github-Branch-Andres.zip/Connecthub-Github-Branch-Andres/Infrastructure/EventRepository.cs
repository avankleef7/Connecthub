﻿using Microsoft.Data.SqlClient; 
using Shared;
using Core.DTO;
using System;
using System.Collections.Generic;
using Infrastructure.HelperklassesInfrastructure;

namespace Infrastructure
{
    public class EventRepository
    {
        private readonly string _connectionString;

        public EventRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        // Voeg een evenement toe aan de database
        public void AddEvent(EventDTO eventDTO)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = new SqlCommand(
            "INSERT INTO [event] (Title, Eventtype, DepartmentID, Status, StartDate, StartTime, EndDate, EndTime, Description, VenueID, Capacity) " +
            "VALUES (@Title, @EventType, @DepartmentID, @Status, @Date, @StartTime, @EndDate, @EndTime, @Description, @VenueID, @Capacity)", connection);

                command.Parameters.AddWithValue("@Title", eventDTO.Title);
                command.Parameters.AddWithValue("@EventType", eventDTO.EventType);
                command.Parameters.AddWithValue("@DepartmentID", eventDTO.DepartmentId);
                string statusChar = ((char)eventDTO.Status).ToString();
                command.Parameters.AddWithValue("@Status", statusChar);
                command.Parameters.AddWithValue("@Date", eventDTO.Date.Date);
                command.Parameters.AddWithValue("@StartTime", eventDTO.StartTime);
                command.Parameters.AddWithValue("@EndDate", eventDTO.EndDate.Date);
                command.Parameters.AddWithValue("@EndTime", eventDTO.EndTime);
                command.Parameters.AddWithValue("@Description", eventDTO.Description);
                command.Parameters.AddWithValue("@VenueID", eventDTO.VenueId);
                command.Parameters.AddWithValue("@Capacity", eventDTO.Capacity);

                // Voer de query uit om het evenement toe te voegen
                command.ExecuteNonQuery();
            }


        }
        public List<EventDTO> GetAllEvents()
        {
            var events = new List<EventDTO>();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = new SqlCommand(
                    "SELECT Title, Eventtype, DepartmentID, Status, StartDate, StartTime, EndDate, EndTime, Description, VenueID, Capacity " +
                    "FROM [event]", connection);

                var reader = command.ExecuteReader();

                
                while (reader.Read())
                {
                    var eventDTO = new EventDTO(
                        title: reader["Title"].ToString(),
                        eventType: (EventType)Enum.Parse(typeof(EventType), reader["Eventtype"].ToString()),
                        departmentid: Convert.ToInt32(reader["DepartmentID"]),
                        status:ConvertData.ConvertToStatus(reader["Status"].ToString()),
                        date: Convert.ToDateTime(reader["StartDate"]),
                        startTime: TimeSpan.Parse(reader["StartTime"].ToString()),
                        endDate: Convert.ToDateTime(reader["EndDate"]),
                        endTime: TimeSpan.Parse(reader["EndTime"].ToString()),
                        description: reader["Description"].ToString(),
                        venueid: Convert.ToInt32(reader["VenueID"]),
                                             
                        capacity: Convert.ToInt32(reader["Capacity"]),
                        enrolledSpeakers: new List<SpeakerDTO>(),
                        enrolledStudents: new List<StudentDTO>(),
                        enrolledTeachers: new List<TeacherDTO>(),
                        unenrolledSpeakers: new List<SpeakerDTO>(),
                        unenrolledStudents: new List<StudentDTO>(),
                        unenrolledTeachers: new List<TeacherDTO>()
                    );
                    events.Add(eventDTO);
                }
            }

            return events;
        }
    }
}
