﻿using Microsoft.Data.SqlClient; 

namespace Infrastructure
{
    public class EnrollRepository
    {
        private readonly string _connectionString;
        private readonly GetParticpantByEmail _getParticipantByEmail;

        public EnrollRepository(string connectionString)
        {
            _connectionString = connectionString;
            _getParticipantByEmail = new GetParticpantByEmail(_connectionString);
        }

        public void AddEnrolledSpeaker(int eventId, string speakerEmail)
        {
            var speakerId = _getParticipantByEmail.GetSpeakerIdByEmail(speakerEmail);
            using (var connection = new SqlConnection(_connectionString)) // Verander naar SqlConnection voor SQL Server
            {
                connection.Open();
                var command = new SqlCommand(
                    @"INSERT INTO EnrolledSpeakers (EventId, SpeakerId)
                      VALUES (@EventId, @SpeakerId)", connection);

                command.Parameters.AddWithValue("@EventId", eventId);
                command.Parameters.AddWithValue("@SpeakerId", speakerId);

                command.ExecuteNonQuery();
            }
        }

        public void RemoveEnrolledSpeaker(int eventId, string speakerEmail)
        {
            var speakerId = _getParticipantByEmail.GetSpeakerIdByEmail(speakerEmail);
            using (var connection = new SqlConnection(_connectionString)) // Verander naar SqlConnection voor SQL Server
            {
                connection.Open();
                var command = new SqlCommand(
                    @"DELETE FROM EnrolledSpeakers 
                      WHERE EventId = @EventId AND SpeakerId = @SpeakerId", connection);

                command.Parameters.AddWithValue("@EventId", eventId);
                command.Parameters.AddWithValue("@SpeakerId", speakerId);

                command.ExecuteNonQuery();
            }
        }

        public void AddEnrolledStudent(int eventId, string studentEmail)
        {
            var studentId = _getParticipantByEmail.GetStudentIdByEmail(studentEmail);
            using (var connection = new SqlConnection(_connectionString)) // Verander naar SqlConnection voor SQL Server
            {
                connection.Open();
                var command = new SqlCommand(
                    @"INSERT INTO EnrolledStudents (EventId, StudentId)
                      VALUES (@EventId, @StudentId)", connection);

                command.Parameters.AddWithValue("@EventId", eventId);
                command.Parameters.AddWithValue("@StudentId", studentId);

                command.ExecuteNonQuery();
            }
        }

        public void RemoveEnrolledStudent(int eventId, string studentEmail)
        {
            var studentId = _getParticipantByEmail.GetStudentIdByEmail(studentEmail);

            using (var connection = new SqlConnection(_connectionString)) // Verander naar SqlConnection voor SQL Server
            {
                connection.Open();
                var command = new SqlCommand(
                    @"DELETE FROM EnrolledStudents 
                      WHERE EventId = @EventId AND StudentId = @StudentId", connection);

                command.Parameters.AddWithValue("@EventId", eventId);
                command.Parameters.AddWithValue("@StudentId", studentId);

                command.ExecuteNonQuery();
            }
        }

        public void AddEnrolledTeacher(int eventId, string teacherEmail)
        {
            var teacherId = _getParticipantByEmail.GetTeacherIdByEmail(teacherEmail);
            using (var connection = new SqlConnection(_connectionString)) // Verander naar SqlConnection voor SQL Server
            {
                connection.Open();
                var command = new SqlCommand(
                    @"INSERT INTO EnrolledTeachers (EventId, TeacherId)
                      VALUES (@EventId, @TeacherId)", connection);

                command.Parameters.AddWithValue("@EventId", eventId);
                command.Parameters.AddWithValue("@TeacherId", teacherId);

                command.ExecuteNonQuery();
            }
        }

        public void RemoveEnrolledTeacher(int eventId, string teacherEmail)
        {
            var teacherId = _getParticipantByEmail.GetTeacherIdByEmail(teacherEmail); // Haal het teacher-ID op via de GetParticpantByEmail instantie

            using (var connection = new SqlConnection(_connectionString)) // Verander naar SqlConnection voor SQL Server
            {
                connection.Open();
                var command = new SqlCommand(
                    @"DELETE FROM EnrolledTeachers
                      WHERE EventId = @EventId AND TeacherId = @TeacherId", connection);

                command.Parameters.AddWithValue("@EventId", eventId);
                command.Parameters.AddWithValue("@TeacherId", teacherId);

                command.ExecuteNonQuery();
            }
        }
    }
}
