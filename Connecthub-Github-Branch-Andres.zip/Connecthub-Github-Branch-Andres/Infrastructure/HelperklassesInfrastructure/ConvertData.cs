﻿using Shared;
using System;

namespace Infrastructure.HelperklassesInfrastructure
{
    public static class ConvertData
    {
        // Converteer een object naar een boolean, verwacht een byte of een andere waarde
        public static bool ConvertToBool(object value)
        {
            return value is byte b ? b == 1 : Convert.ToBoolean(value);
        }

        // Conversie van een string naar de Status enum
        public static Status ConvertToStatus(string status)
        {
            switch (status)
            {
                case "A":
                    return Status.Active;
                case "I":
                    return Status.Inactive;
                case "G":
                    return Status.Pending;
                case "B":
                    return Status.Confirmed;
                default:
                    throw new ArgumentException("Invalid status value", nameof(status));
            }
        }
    }
}
