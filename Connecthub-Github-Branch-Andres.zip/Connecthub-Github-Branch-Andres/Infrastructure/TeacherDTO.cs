﻿using Core.DTO;

public class TeacherDTO
{
    public int DepartmentID { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public DateTime DateOfBirth { get; set; }
    public Gender Gender { get; set; }
    public string Email { get; set; }

    public TeacherDTO(int departmentID, string firstName, string lastName, DateTime dateOfBirth, Gender gender, string email)
    {
        DepartmentID = departmentID;
        FirstName = firstName;
        LastName = lastName;
        DateOfBirth = dateOfBirth;
        Gender = gender;
        Email = email;
    }
}
