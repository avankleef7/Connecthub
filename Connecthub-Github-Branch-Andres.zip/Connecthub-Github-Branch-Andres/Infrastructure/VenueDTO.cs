﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Shared;

namespace Infrastructure
{
    public class VenueDTO
    {

        public int SchoolId { get; set; }
        public string LocationName { get; set; }
        public string Address { get; set; }
        public RoomType RoomTypes { get; set; }
        public int Capacity { get; set; }
        public bool HasElectricity { get; set; }
        public bool HasProjectorOrScreen { get; set; }
        public bool HasStage { get; set; }
        public bool IsWheelChairAccessible { get; set; }

      
        public VenueDTO(int schoolid, string locationName, string address, RoomType roomType, int capacity, bool hasElectricity, bool hasProjectorOrScreen, bool hasStage, bool isWheelChairAccessible)
        {
            SchoolId = schoolid;
            LocationName = locationName;
            Address = address;
            RoomTypes = roomType;
            Capacity = capacity;
            HasElectricity = hasElectricity;
            HasProjectorOrScreen = hasProjectorOrScreen;
            HasStage = hasStage;
            IsWheelChairAccessible = isWheelChairAccessible;
        }
    }
}
