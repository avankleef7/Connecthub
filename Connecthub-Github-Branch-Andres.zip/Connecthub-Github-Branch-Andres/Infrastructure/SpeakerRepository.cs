﻿using Microsoft.Data.SqlClient;
using Shared;
using Core.DTO;
using System;
using System.Collections.Generic;

namespace Infrastructure
{
    public class SpeakerRepository
    {
        private readonly string _connectionString;

        public SpeakerRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public IReadOnlyList<SpeakerDTO> GetAllSpeakers()
        {
            var speakers = new List<SpeakerDTO>();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand("SELECT FirstName, LastName, DateOfBirth, Gender, Email, Organization, Position FROM Speaker", connection);

                using var reader = command.ExecuteReader();
                {
                    while (reader.Read())
                    {
                        speakers.Add(new SpeakerDTO(
                            firstName: reader.GetString(reader.GetOrdinal("FirstName")),
                            lastName: reader.GetString(reader.GetOrdinal("LastName")),
                            dateOfBirth: reader.GetDateTime(reader.GetOrdinal("DateOfBirth")),
                            gender: (Gender)reader.GetInt32(reader.GetOrdinal("Gender")),
                            email: reader.GetString(reader.GetOrdinal("Email")),
                            organization: reader.GetString(reader.GetOrdinal("Organization")),
                            position: reader.GetString(reader.GetOrdinal("Position"))
                        ));
                    }
                }
            }

            return speakers;
        }

        public void AddSpeaker(SpeakerDTO speaker)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand("INSERT INTO speaker (FirstName, LastName, DateOfBirth, Gender, Email, Organization, Position) VALUES (@FirstName, @LastName, @DateOfBirth, @Gender, @Email, @Organization, @Position)", connection);

                command.Parameters.AddWithValue("@FirstName", speaker.FirstName);
                command.Parameters.AddWithValue("@LastName", speaker.LastName);
                command.Parameters.AddWithValue("@DateOfBirth", speaker.DateOfBirth);
                command.Parameters.AddWithValue("@Gender", speaker.Gender);
                command.Parameters.AddWithValue("@Email", speaker.Email);
                command.Parameters.AddWithValue("@Organization", speaker.Organization);
                command.Parameters.AddWithValue("@Position", speaker.Position);

                command.ExecuteNonQuery();
            }
        }

        public void RemoveSpeaker(SpeakerDTO speaker)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand("DELETE FROM speaker WHERE Email = @Email", connection);

                command.Parameters.AddWithValue("@Email", speaker.Email);

                command.ExecuteNonQuery();
            }
        }

        //// Haal een specifieke spreker op via email
        //public SpeakerDTO GetSpeakerByEmail(string email)
        //{
        //    using (var connection = new SqlConnection(_connectionString))
        //    {
        //        connection.Open();
        //        var command = new SqlCommand("SELECT FirstName, LastName, DateOfBirth, Gender, Email, Organization, Position FROM speaker WHERE Email = @Email", connection);
        //        command.Parameters.AddWithValue("@Email", email);

        //        using (var reader = command.ExecuteReader())
        //        {
        //            if (reader.Read())
        //            {
        //                // Maak en retourneer een SpeakerDTO
        //                return new SpeakerDTO(
        //                    firstName: reader["FirstName"].ToString(),
        //                    lastName: reader["LastName"].ToString(),
        //                    dateOfBirth: Convert.ToDateTime(reader["DateOfBirth"]),
        //                    gender: (Gender)Enum.Parse(typeof(Gender), reader["Gender"].ToString()),
        //                    email: reader["Email"].ToString(),
        //                    organization: reader["Organization"].ToString(),
        //                    position: reader["Position"].ToString()
        //                );
        //            }
        //        }
        //    }

        //    return null;
        //}
    }
}
