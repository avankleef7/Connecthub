﻿using Infrastructure;
using Shared;
using System.Collections.Generic;

namespace Core.DTO
{
    public class DepartmentDTO
    {
        public int SchoolId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int StudentCapacity { get; set; }
        public int TeacherCapacity { get; set; }
        public DepartmentType DepartmentType { get; set; }

        public List<StudentDTO> Students { get; set; }
        public List<TeacherDTO> Teachers { get; set; }

     
        public DepartmentDTO(
            int schoolid,
            string name,
            string description,
            int studentCapacity,
            int teacherCapacity,
            DepartmentType departmentType,
            List<StudentDTO> students = null,
            List<TeacherDTO> teachers = null) 
        {
            SchoolId = schoolid;
            Name = name;
            Description = description;
            StudentCapacity = studentCapacity;
            TeacherCapacity = teacherCapacity;
            DepartmentType = departmentType;

            // Als er geen studenten of docenten zijn meegegeven, initialiseer ze dan als lege lijsten
            Students = students ?? new List<StudentDTO>();
            Teachers = teachers ?? new List<TeacherDTO>();
        }
    }
}
