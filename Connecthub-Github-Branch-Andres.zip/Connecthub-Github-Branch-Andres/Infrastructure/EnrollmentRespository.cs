﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure
{
    public class EnrollmentRespository
    {
        private readonly string _connectionString;


        public EnrollmentRespository(string connectionstring)
        {
            _connectionString = connectionstring;

                
        }

        // Voeg een spreker toe aan een evenement
        public void EnrollSpeaker(int eventId, int speakerId, DateTime participationDate, TimeSpan participationTime)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = new SqlCommand(
                    "INSERT INTO speakereventline (EventID, SpeakerID, ParticipationDate, ParticipationTime) " +
                    "VALUES (@EventID, @SpeakerID, @ParticipationDate, @ParticipationTime)", connection);

                command.Parameters.AddWithValue("@EventID", eventId);
                command.Parameters.AddWithValue("@SpeakerID", speakerId);
                command.Parameters.AddWithValue("@ParticipationDate", participationDate);
                command.Parameters.AddWithValue("@ParticipationTime", participationTime);

                command.ExecuteNonQuery();
            }
        }

        // Verwijder een spreker van een evenement
        public void UnenrollSpeaker(int eventId, int speakerId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = new SqlCommand(
                    "DELETE FROM speakereventline WHERE EventID = @EventID AND SpeakerID = @SpeakerID", connection);

                command.Parameters.AddWithValue("@EventID", eventId);
                command.Parameters.AddWithValue("@SpeakerID", speakerId);

                command.ExecuteNonQuery();
            }
        }

        // Controleer of een spreker al is ingeschreven voor een evenement
        public bool IsSpeakerEnrolled(int eventId, int speakerId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = new SqlCommand(
                    "SELECT COUNT(1) FROM speakereventline WHERE EventID = @EventID AND SpeakerID = @SpeakerID", connection);

                command.Parameters.AddWithValue("@EventID", eventId);
                command.Parameters.AddWithValue("@SpeakerID", speakerId);

                return (int)command.ExecuteScalar() > 0;
            }
        }
    }
}
