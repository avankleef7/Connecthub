﻿namespace Classes
{
    public class Class1
    {

    }
}
