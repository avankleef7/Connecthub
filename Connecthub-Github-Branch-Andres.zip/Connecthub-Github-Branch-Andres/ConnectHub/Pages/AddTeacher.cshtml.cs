using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Core.Domain;
using System.Collections.Generic;
using System.Linq;

namespace ConnectHub.Pages
{
    public class AddTeacherModel : PageModel
    {
        [BindProperty(SupportsGet = true)]
        public string EventTitle { get; set; } // Event title from the query string

        public Event SelectedEvent { get; set; }
        public List<Teacher> Teachers { get; set; } = new List<Teacher>();
        public List<Teacher> EnrolledTeachers { get; set; } = new List<Teacher>();

        private readonly EventCatalog _eventCatalog;
        private readonly TeacherCatalog _teacherCatalog;
        private readonly EnrollmentManager _enrollmentManager;
        private readonly UnenrollmentManager _unenrollmentManager;

        public string SuccessMessage { get; private set; }
        public string ErrorMessage { get; private set; }

        // Property to bind selected teacher email from button click
        [BindProperty]
        public string ParticipantEmail { get; set; }

        public AddTeacherModel(EventCatalog eventCatalog, TeacherCatalog teacherCatalog, EnrollmentManager enrollmentManager, UnenrollmentManager unenrollmentManager)
        {
            _eventCatalog = eventCatalog;
            _teacherCatalog = teacherCatalog;
            _enrollmentManager = enrollmentManager;
            _unenrollmentManager = unenrollmentManager;
        }

        public void OnGet()
        {
            LoadTeachers(); // Load teachers when the page is accessed

            // Fetch the event using the provided EventTitle
            if (!string.IsNullOrEmpty(EventTitle))
            {
                SelectedEvent = _eventCatalog.FindEventByName(EventTitle);
                if (SelectedEvent != null)
                {
                    LoadEnrolledParticipants(); // Load enrolled teachers for the selected event
                }
            }
        }

        public IActionResult OnPost()
        {
            // Load the selected event to ensure the event is available
            if (!string.IsNullOrEmpty(EventTitle))
            {
                SelectedEvent = _eventCatalog.FindEventByName(EventTitle);
                if (SelectedEvent != null)
                {
                    LoadTeachers();
                }
            }

            if (SelectedEvent == null)
            {
                ErrorMessage = "Geen geldig evenement geselecteerd.";
                return Page();
            }

            // Check if a teacher is being added
            if (!string.IsNullOrEmpty(ParticipantEmail))
            {
                var teacher = Teachers.FirstOrDefault(t => t.GetEmail() == ParticipantEmail);

                if (teacher != null)
                {
                    var result = _enrollmentManager.EnrollTeacher(teacher, SelectedEvent); // Use the injected EnrollmentManager
                    if (result.Success)
                    {
                        SuccessMessage = $"{teacher.GetFirstName} {teacher.GetLastName} is succesvol toegevoegd aan {SelectedEvent.GetTitle}.";
                        LoadEnrolledParticipants(); // Reload enrolled teachers after adding
                    }
                    else
                    {
                        ErrorMessage = result.Reason;
                    }
                }
            }

            // Check if a teacher is being unenrolled
            if (!string.IsNullOrEmpty(Request.Form["UnenrollEmail"]))
            {
                var unenrollEmail = Request.Form["UnenrollEmail"];
                var unenrolledTeacher = _teacherCatalog.GetTeachers().FirstOrDefault(t => t.GetEmail() == unenrollEmail);

                if (unenrolledTeacher != null)
                {
                    var unenrollmentResult = _unenrollmentManager.UnenrollTeacher(unenrolledTeacher, SelectedEvent);
                    if (unenrollmentResult.Success)
                    {
                        SuccessMessage = $"{unenrolledTeacher.GetFirstName} {unenrolledTeacher.GetLastName} is succesvol afgemeld voor {SelectedEvent.GetTitle}.";
                        LoadEnrolledParticipants(); // Reload enrolled teachers after unenrolling
                    }
                    else
                    {
                        ErrorMessage = unenrollmentResult.Reason;
                    }
                }
            }

            LoadEnrolledParticipants(); // Reload after processing
            return Page();
        }

        private void LoadTeachers()
        {
            Teachers = _teacherCatalog.GetTeachers().ToList();
            Console.WriteLine($"Aantal docenten geladen: {Teachers.Count}");
        }

        private void LoadEnrolledParticipants()
        {
            if (!string.IsNullOrEmpty(EventTitle))
            {
                SelectedEvent = _eventCatalog.FindEventByName(EventTitle);
                if (SelectedEvent != null)
                {
                    EnrolledTeachers = SelectedEvent.Teachers.ToList();
                    Console.WriteLine($"Aantal ingeschreven docenten: {EnrolledTeachers.Count}");
                }
            }
        }
    }
}
