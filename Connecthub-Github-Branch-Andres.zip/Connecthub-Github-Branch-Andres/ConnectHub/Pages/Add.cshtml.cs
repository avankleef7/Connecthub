using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Core.Domain;
using System.Collections.Generic;
using System.Linq;

namespace ConnectHub.Pages
{
    public class AddParticipantsModel : PageModel
    {
        [BindProperty(SupportsGet = true)]
        public string EventTitle { get; set; } // Event title from the query string

        public Event SelectedEvent { get; set; }
        public List<Student> Students { get; set; } = new List<Student>();
        public List<Student> EnrolledStudents { get; set; } = new List<Student>();

        private readonly EventCatalog _eventCatalog;
        private readonly StudentCatalog _studentCatalog;
        private readonly EnrollmentManager _enrollmentManager;
        private readonly UnenrollmentManager _unenrollmentManager;

        public string SuccessMessage { get; private set; }
        public string ErrorMessage { get; private set; }

        // Property to bind selected participant (student) email from button click
        [BindProperty]
        public string ParticipantEmail { get; set; }

        public AddParticipantsModel(EventCatalog eventCatalog, StudentCatalog studentCatalog, EnrollmentManager enrollmentManager, UnenrollmentManager unenrollmentManager)
        {
            _eventCatalog = eventCatalog;
            _studentCatalog = studentCatalog;
            _enrollmentManager = enrollmentManager;
            _unenrollmentManager = unenrollmentManager; 
        }

        public void OnGet()
        {
            LoadStudents(); // Load students when the page is accessed

            // Fetch the event using the provided EventTitle
            if (!string.IsNullOrEmpty(EventTitle))
            {
                SelectedEvent = _eventCatalog.FindEventByName(EventTitle);
                if (SelectedEvent != null)
                {
                    LoadEnrolledParticipants(); // Load enrolled participants for the selected event
                }
            }
        }

        public IActionResult OnPost()
        {
            if (!string.IsNullOrEmpty(EventTitle))
            {
                SelectedEvent = _eventCatalog.FindEventByName(EventTitle);
                if (SelectedEvent != null)
                {
                    LoadStudents();
                }
            }

            if (SelectedEvent == null)
            {
                ErrorMessage = "Geen geldig evenement geselecteerd.";
                return Page();
            }

            // Check if a student is being added
            if (!string.IsNullOrEmpty(ParticipantEmail))
            {
                var student = Students.FirstOrDefault(s => s.GetEmail() == ParticipantEmail);

                if (student != null)
                {
                    var result = _enrollmentManager.EnrollStudent(student, SelectedEvent); // Gebruik de ge�njecteerde EnrollmentManager
                    if (result.Success)
                    {
                        SuccessMessage = $"{student.GetFirstName} {student.GetLastName} is succesvol toegevoegd aan {SelectedEvent.GetTitle}.";
                        LoadEnrolledParticipants(); // Reload enrolled participants after adding
                    }
                    else
                    {
                        ErrorMessage = result.Reason;
                    }
                }
            }

            // Check if a student is being unenrolled
            if (!string.IsNullOrEmpty(Request.Form["UnenrollEmail"]))
            {
                var unenrollEmail = Request.Form["UnenrollEmail"];

                // Zoek de student op basis van het e-mailadres
                var unenrolledStudent = _studentCatalog.GetStudents().FirstOrDefault(s => s.GetEmail() == unenrollEmail);

                if (unenrolledStudent != null)
                {
                    // Gebruik de UnenrollmentManager om de student uit te schrijven
                    var unenrollmentResult = _unenrollmentManager.UnenrollStudent(unenrolledStudent, SelectedEvent);
                    if (unenrollmentResult.Success)
                    {
                        SuccessMessage = $"{unenrolledStudent.GetFirstName} {unenrolledStudent.GetLastName} is succesvol afgemeld voor {SelectedEvent.GetTitle}.";
                        LoadEnrolledParticipants(); // Reload enrolled participants after unenrolling
                    }
                    else
                    {
                        ErrorMessage = unenrollmentResult.Reason;
                    }
                }
            }

            LoadEnrolledParticipants(); // Reload after processing
            return Page();
        }

        private void LoadStudents()
        {
            Students = _studentCatalog.GetStudents().ToList();
            Console.WriteLine($"Aantal studenten geladen: {Students.Count}");
        }

        private void LoadEnrolledParticipants()
        {
            if (!string.IsNullOrEmpty(EventTitle))
            {
                SelectedEvent = _eventCatalog.FindEventByName(EventTitle);
                if (SelectedEvent != null)
                {
                    EnrolledStudents = SelectedEvent.Students.ToList(); // Load enrolled students from the selected event
                    Console.WriteLine($"Aantal ingeschreven studenten: {EnrolledStudents.Count}");
                }
            }
        }
    }
}
