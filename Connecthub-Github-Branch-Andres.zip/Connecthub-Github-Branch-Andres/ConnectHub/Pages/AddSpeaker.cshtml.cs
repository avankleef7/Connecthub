using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Core.Domain;
using System.Collections.Generic;
using System.Linq;

namespace ConnectHub.Pages
{
    public class AddSpeakerModel : PageModel
    {
        [BindProperty(SupportsGet = true)]
        public string EventTitle { get; set; }

        public Event SelectedEvent { get; set; }
        public List<Speaker> Speakers { get; set; } = new List<Speaker>();
        public List<Speaker> EnrolledSpeakers { get; set; } = new List<Speaker>();

        private readonly EventCatalog _eventCatalog;
        private readonly SpeakerCatalogus _speakerCatalog;
        private readonly SpeakerEventManager _speakerEventManager;

        public string SuccessMessage { get; private set; }
        public string ErrorMessage { get; private set; }

        [BindProperty]
        public string SpeakerEmail { get; set; }

        [BindProperty]
        public string RemoveSpeakerEmail { get; set; }

        public AddSpeakerModel(EventCatalog eventCatalog, SpeakerCatalogus speakerCatalog, SpeakerEventManager speakerEventManager)
        {
            _eventCatalog = eventCatalog;
            _speakerCatalog = speakerCatalog;
            _speakerEventManager = speakerEventManager;
        }

        public void OnGet()
        {
            LoadSpeakers();

            if (!string.IsNullOrEmpty(EventTitle))
            {
                SelectedEvent = _eventCatalog.FindEventByName(EventTitle);
                if (SelectedEvent != null)
                {
                    LoadEnrolledSpeakers();
                }
            }
        }

        public IActionResult OnPost()
        {
            if (!string.IsNullOrEmpty(EventTitle))
            {
                SelectedEvent = _eventCatalog.FindEventByName(EventTitle);
                if (SelectedEvent != null)
                {
                    LoadSpeakers();
                }
            }

            if (SelectedEvent == null)
            {
                ErrorMessage = "Geen geldig evenement geselecteerd.";
                return Page();
            }

            if (!string.IsNullOrEmpty(SpeakerEmail))
            {
                var speaker = Speakers.FirstOrDefault(s => s.GetEmail() == SpeakerEmail);
                if (speaker != null)
                {
                    var result = _speakerEventManager.SpeakerToEvent(speaker, SelectedEvent);
                    if (result.Success)
                    {
                        SuccessMessage = $"{speaker.GetFirstName} {speaker.GetLastName} is succesvol toegevoegd aan {SelectedEvent.GetTitle}.";
                        LoadEnrolledSpeakers();
                    }
                    else
                    {
                        ErrorMessage = result.Reason;
                    }
                }
            }

            if (!string.IsNullOrEmpty(RemoveSpeakerEmail))
            {
                var unenrolledSpeaker = _speakerCatalog.GetSpeakers().FirstOrDefault(s => s.GetEmail() == RemoveSpeakerEmail);
                  
                if (unenrolledSpeaker != null)
                {
                    var removeResult = _speakerEventManager.RemoveSpeakerFromEvent(unenrolledSpeaker, SelectedEvent);
                    if (removeResult.Success)
                    {
                        SuccessMessage = $"{unenrolledSpeaker.GetFirstName} {unenrolledSpeaker.GetLastName} is succesvol afgemeld voor {SelectedEvent.GetTitle}.";
                        LoadEnrolledSpeakers();
                    }
                    else
                    {
                        ErrorMessage = removeResult.Reason;
                    }
                }
            }

            LoadEnrolledSpeakers();
            return Page();
        }

        private void LoadSpeakers()
        {
            Speakers = _speakerCatalog.GetSpeakers().ToList();
            Console.WriteLine($"Aantal sprekers geladen: {Speakers.Count}");
        }

        private void LoadEnrolledSpeakers()
        {
            if (!string.IsNullOrEmpty(EventTitle))
            {
                SelectedEvent = _eventCatalog.FindEventByName(EventTitle);
                if (SelectedEvent != null)
                {
                    EnrolledSpeakers = SelectedEvent.Speakers.ToList();
                    Console.WriteLine($"Aantal ingeschreven sprekers: {EnrolledSpeakers.Count}");
                }
            }
        }
    }
}
