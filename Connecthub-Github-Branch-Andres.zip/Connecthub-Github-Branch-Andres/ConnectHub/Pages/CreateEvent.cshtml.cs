using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Core.Domain;
using System.Collections.Generic;
using System.Linq;
using Shared;
using ConnectHub.ViewModels.Request;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ConnectHub.Pages
{
    public class CreateEventModel : PageModel
    {
        private School school => SchoolManager.Instance;

        [BindProperty]
        public EventRegistration EventRegistration { get; set; }

        
        public List<Department> DepartmentsList { get; set; } = new List<Department>();



        // Lijst van evenementen, locaties, en studenten
        public List<Venue> Venues { get; set; } = new List<Venue>();
        public List<Event> Events { get; set; } = new List<Event>();

        // Bericht voor succes en fout
        public string SuccessMessage { get; private set; }
        public string ErrorMessage { get; private set; }

        private readonly EventCatalog _eventCatalog;
        private readonly VenueCatalog _venueCatalog;
        private readonly DepartmentCatalog _departmentCatalog;

        public CreateEventModel(EventCatalog eventCatalog, VenueCatalog venueCatalog, DepartmentCatalog departmentCatalog)
        {
            _eventCatalog = eventCatalog;
            _venueCatalog = venueCatalog;
            _departmentCatalog = departmentCatalog;
        
        }

        public List<SelectListItem> Departments { get; set; } = new List<SelectListItem>();

        public void OnGet()
        {
            LoadDepartments();
            LoadVenues();
            LoadEvents();
            Console.WriteLine("");
        }

        public IActionResult OnPost()
        {
            LoadDepartments();
            LoadVenues();
            LoadEvents();

            var department = school.DepartmentCatalog.GetDepartments
                .FirstOrDefault(d => d.GetName.Equals(EventRegistration.SelectedDepartment, StringComparison.OrdinalIgnoreCase));

            if (department == null)
            {
                ModelState.AddModelError("Registration.SelectedDepartment", "Invalid department selected.");
                return Page();
            }

            try
            {
               

                // Zoek de venue op basis van de geselecteerde naam
                var venue = Venues
                    .FirstOrDefault(v => v.GetLocationName.Equals(EventRegistration.SelectedVenue, StringComparison.OrdinalIgnoreCase));

                if (venue == null)
                {
                    ModelState.AddModelError("EventRegistration.SelectedVenue", "De geselecteerde venue is ongeldig.");
                    return Page();
                }

                // Valideer dat starttijd v��r eindtijd ligt
                if (EventRegistration.StartingTime >= EventRegistration.EndingTime)
                {
                    ModelState.AddModelError("EventRegistration.StartingTime", "Starttijd moet voor eindtijd liggen.");
                    return Page();
                }

                // Valideer dat de einddatum na de startdatum ligt
                if (EventRegistration.Date > EventRegistration.EndDate)
                {
                    ModelState.AddModelError("EventRegistration.EndDate", "Einddatum moet na de startdatum liggen.");
                    return Page();
                }

                // Maak een nieuw event via de builder
                var builder = new EventBuilder()
                    .SetTitle(EventRegistration.Title)
                    .SetDepartment(department)
                    .SetDate(EventRegistration.Date)
                    .SetStartTime(EventRegistration.StartingTime)
                    .SetEndTime(EventRegistration.EndingTime)
                    .SetEndDate(EventRegistration.EndDate)
                    .SetDescription(EventRegistration.Description)
                    .SetVenue(venue)
                    .SetMaxStudentCapacity(EventRegistration.MaxCapacity)
                    .SetEventType(EventRegistration.EventType);

                // Bouw het event en sla het op in de catalogus
                var result = builder.Build(_eventCatalog);
                if (result.Success)
                {
                    SuccessMessage = result.Reason;
                }
                else
                {
                    ErrorMessage = result.Reason;
                }

                LoadEvents(); // Herlaad de lijst met evenementen
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Er is een fout opgetreden: {ex.Message}";
            }

            return Page();
        }

        private void LoadDepartments()
        {
           
            Departments = school.DepartmentCatalog.GetDepartments
                .Select(d => new SelectListItem
                {
                    Value = d.GetName,
                    Text = $"{d.GetName} - {d.GetDescription}"
                })
                .ToList();
        }


        private void LoadVenues()
        {
            Venues = _venueCatalog.GetVenues.ToList();
        }

        private void LoadEvents()
        {
            Events = _eventCatalog.GetEvents.ToList();
        }
    }

}
