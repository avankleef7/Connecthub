using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Shared;
using Core.Domain;
using System.Collections.Generic;
using System.Linq;
using ConnectHub.ViewModels.Request;

namespace ConnectHub.Pages
{
    public class CreateVenueModel : PageModel
    {
        [BindProperty]
        public VenueRegistration NewVenueRegistration { get; set; } = new VenueRegistration();

        private readonly VenueCatalog venueCatalog; // VenueCatalog als private readonly veld

        public List<string> RoomTypeOptions { get; set; }

        // Voeg success- en foutmeldingen toe
        public string SuccessMessage { get; private set; }
        public string ErrorMessage { get; private set; }

        // Voeg een lijst toe om alle venues weer te geven
        public List<Venue> Venues { get; private set; }

        // Constructor die VenueCatalog injecteert
        public CreateVenueModel(VenueCatalog venueCatalog)
        {
            this.venueCatalog = venueCatalog; // Correcte toewijzing
            RoomTypeOptions = Enum.GetNames(typeof(RoomType)).ToList();
        }

        // Laad de venues in de OnGet-methode
        public void OnGet()
        {
            LoadVenues();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                // Als er iets fout is gegaan, keer terug naar de pagina.
                return Page();
            }

            try
            {
                // Maak een nieuw Venue object aan
                VenueFactory factory = new VenueFactory();
                var result = factory.CreateVenue(
                    NewVenueRegistration.LocationName,
                    NewVenueRegistration.Address,
                    (RoomType)Enum.Parse(typeof(RoomType), NewVenueRegistration.RoomType),
                    NewVenueRegistration.Capacity,
                    venueCatalog
                );

                if (result.Success)
                {
                    // Optioneel: je kan hier een succesbericht instellen
                    SuccessMessage = result.Reason;
                    LoadVenues(); // Herlaad de venues na succesvolle aanmaak
                    return RedirectToPage("CreateVenue");
                }
                else
                {
                    // Toon een foutmelding bij een mislukte aanmaak
                    ErrorMessage = result.Reason;
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
            }

            LoadVenues(); // Laad de venues opnieuw als er een fout was
            return Page();
        }

        
        public IActionResult OnPostRemoveVenue(string locationName)
        {
            if (string.IsNullOrWhiteSpace(locationName))
            {
                LoadVenues();
                return RedirectToPage("CreateVenue");
            }

            try
            {
                var result = venueCatalog.TryRemoveVenue(locationName, SchoolManager.Instance.Name);
                if (result.Success)
                {
                    SuccessMessage = result.Reason;
                }
                else
                {
                    ErrorMessage = result.Reason;
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Er is een fout opgetreden: {ex.Message}";
            }

            LoadVenues();
            return RedirectToPage("CreateVenue");
        }

        // Laad de lijst van alle venues
        private void LoadVenues()
        {
            Venues = venueCatalog.GetVenues.ToList(); 
        }
    }
}
