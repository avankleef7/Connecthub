using ConnectHub.ViewModels.Request;
using Core.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Linq;

namespace ConnectHub.Pages
{
    public class CreateSpeakersModel : PageModel
    {
        private School school => SchoolManager.Instance;
        private readonly StudentCatalog studentCatalog;
        private readonly TeacherCatalog teacherCatalog;
        private readonly SpeakerCatalogus speakerCatalogus;

        [BindProperty]
        public SpeakerRegistration Registration { get; set; } = new SpeakerRegistration();

        public string SuccessMessage { get; private set; }
        public string ErrorMessage { get; private set; }
        public List<Speaker> Speakers { get; private set; }

        public CreateSpeakersModel(
            StudentCatalog studentCatalog,
            TeacherCatalog teacherCatalog,
            SpeakerCatalogus speakerCatalogus)
        {
            this.studentCatalog = studentCatalog;
            this.teacherCatalog = teacherCatalog;
            this.speakerCatalogus = speakerCatalogus;
        }

        public void OnGet()
        {
            LoadSpeakerList(); // Haal de lijst van alle sprekers op
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
                {
                    Console.WriteLine(error.ErrorMessage); // Of log naar een logger
                }
                LoadSpeakerList();
                return Page();
            }

            try
            {
                // Gebruik de SpeakerFactory om een nieuwe spreker aan te maken
                SpeakerService factory = new SpeakerService(new EmailValidator(studentCatalog, teacherCatalog, speakerCatalogus));
                var result = factory.CreateSpeaker(
                    Registration.FirstName,
                    Registration.LastName,
                    Registration.Gender, 
                    Registration.DateOfBirth,
                    Registration.Email,
                    Registration.Organization,
                    Registration.Position,
                    studentCatalog,
                    teacherCatalog,
                    speakerCatalogus
                );

                if (result.Success)
                {
                    SuccessMessage = result.Reason; // Zet succesbericht
                    return RedirectToPage("CreateSpeakers");
                }
                else
                {
                    ErrorMessage = result.Reason; // Zet foutmelding
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message; // Voeg foutmelding toe
            }

            LoadSpeakerList(); // Laad de sprekerlijst opnieuw, zelfs als er een fout was
            return Page(); // Geef de pagina terug
        }

        // Laad de lijst van alle sprekers op
        private void LoadSpeakerList()
        {
            Speakers = speakerCatalogus.GetSpeakers().ToList();
        }
    }
}
