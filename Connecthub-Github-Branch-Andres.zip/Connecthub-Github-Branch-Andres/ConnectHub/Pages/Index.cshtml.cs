using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Shared;
using Core.Domain;
using System.Collections.Generic;

namespace ConnectHub.Pages
{
    public class EventsManagerModel : PageModel
    {
        private readonly EventSearchService _eventSearchService;

        public EventsManagerModel(EventSearchService eventSearchService)
        {
            _eventSearchService = eventSearchService;
        }

        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; }

        [BindProperty(SupportsGet = true)]
        public EventType EventType { get; set; } = EventType.None;

        public IReadOnlyList<Event> Events { get; private set; }

        public void OnGet()
        {
            Events = _eventSearchService.Search(SearchTerm ?? string.Empty, EventType);
        }

        public IActionResult OnGetSearchEvents(string searchTerm, EventType eventType)
        {
            Events = _eventSearchService.Search(searchTerm ?? string.Empty, eventType);
            return Partial("_EventResults", Events);
        }
    }
}
