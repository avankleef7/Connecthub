using ConnectHub.ViewModels.Request;
using Core.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ConnectHub.Pages
{
    public class CreateTeachersModel : PageModel
    {
        private School school => SchoolManager.Instance;
        private readonly StudentCatalog studentCatalog;
        private readonly TeacherCatalog teacherCatalog;
        private readonly SpeakerCatalogus speakerCatalog;
        private readonly DepartmentCatalog departmentCatalog;

        // Injecteer de catalogussen via de constructor
        public CreateTeachersModel(
            StudentCatalog studentCatalog,
            TeacherCatalog teacherCatalog,
            SpeakerCatalogus speakerCatalog,
            DepartmentCatalog departmentCatalog)
        {
            this.studentCatalog = studentCatalog;
            this.teacherCatalog = teacherCatalog;
            this.speakerCatalog = speakerCatalog;
            this.departmentCatalog = departmentCatalog;
        }

        [BindProperty]
        public TeacherRegistration Registration { get; set; } = new TeacherRegistration();

        public List<SelectListItem> Departments { get; set; } = new List<SelectListItem>();
        public string SuccessMessage { get; private set; }
        public string ErrorMessage { get; private set; }
        public List<Teacher> Teachers { get; private set; } 

        public void OnGet()
        {
            LoadDepartments();
            LoadTeacherList(); // Haal de lijst van alle studenten op
        }

        public IActionResult OnPost()
        {
            LoadDepartments();

            // Laad de docentenlijst voordat je de validatie controleert
            LoadTeacherList();

            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Haal de geselecteerde afdeling
            var department = school.DepartmentCatalog.GetDepartments
                .FirstOrDefault(d => d.GetName.Equals(Registration.SelectedDepartment, StringComparison.OrdinalIgnoreCase));

            if (department == null)
            {
                ModelState.AddModelError("Registration.SelectedDepartment", "Invalid department selected.");
                return Page();
            }

            try
            {
                // Gebruik de Teacherfactory om een nieuwe docent aan te maken
                TeacherService factory = new TeacherService(new EmailValidator(studentCatalog, teacherCatalog, speakerCatalog));
                var result = factory.CreateTeacher(
                    Registration.FirstName,
                    Registration.LastName,
                    Registration.Gender,
                    Registration.DateOfBirth,
                    Registration.Email,
                    department,
                    teacherCatalog,
                    studentCatalog,
                    speakerCatalog
                );

                if (result.Success)
                {
                    // Hoe krijg ik de velden weer leeg?
                    SuccessMessage = result.Reason;

                    LoadTeacherList(); // Laad de studentenlijst opnieuw
                    return RedirectToPage("CreateTeachers");
                }
                else
                {
                    ErrorMessage = result.Reason; // Toon de foutmelding bij een mislukte aanmaak

                }
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
            }

            // Laad de studentenlijst opnieuw, zelfs als er een fout was
            LoadTeacherList();

            return Page();
        }

        // Haal de lijst van alle studenten op
        private void LoadTeacherList()
        {
            // Verkrijg de lijst van studenten van de studentCatalog
            Teachers = teacherCatalog.GetTeachers().ToList();
        }

        private void LoadDepartments()
        {
            // Zorg ervoor dat je het juiste property gebruikt
            Departments = school.DepartmentCatalog.GetDepartments
                .Select(d => new SelectListItem { Value = d.GetName, Text = d.GetName })
                .ToList();
        }


    }
}
