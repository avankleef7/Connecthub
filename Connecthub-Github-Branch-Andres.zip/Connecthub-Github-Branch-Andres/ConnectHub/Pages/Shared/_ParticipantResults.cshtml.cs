using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ConnectHub.Pages.Shared
{
    public class _ParticipationResultsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
