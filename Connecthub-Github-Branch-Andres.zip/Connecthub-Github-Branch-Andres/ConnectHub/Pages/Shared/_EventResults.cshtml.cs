using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ConnectHub.Pages.Shared
{
    public class _EventResultsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
