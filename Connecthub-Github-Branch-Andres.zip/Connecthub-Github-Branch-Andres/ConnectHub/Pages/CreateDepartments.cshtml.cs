using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;
using Core.Domain;
using Shared;

namespace ConnectHub.Pages
{
    public class CreateDepartmentsModel : PageModel
    {
        private School school => SchoolManager.Instance;

        public List<DepartmentType> Departments { get; set; } = new List<DepartmentType>
        {
            DepartmentType.EducationAndChildDevelopment,
            DepartmentType.HealthAndSports,
            DepartmentType.EconomicsAndBusiness,
            DepartmentType.TechnologyAndNature,
            DepartmentType.BehaviorAndSociety,
            DepartmentType.LanguageAndCommunication,
            DepartmentType.Art,
            DepartmentType.ICT,
            DepartmentType.Logistics
        };

        [BindProperty]
        public DepartmentType? SelectedDepartment { get; set; }

        public IReadOnlyList<Department> CreatedDepartments => school.DepartmentCatalog.GetDepartments;

        public string SuccessMessage { get; private set; }
        public string ErrorMessage { get; private set; }

        public void OnGet()
        {
            // Logic for GET request
        }

        public IActionResult OnPost()
        {
            if (SelectedDepartment.HasValue)
            {
                DepartmentFactory factory = new DepartmentFactory();
                Result result = factory.CreateDepartment(SelectedDepartment.Value, school.DepartmentCatalog);

                if (result.Success)
                {
                    SuccessMessage = result.Reason;
                    SelectedDepartment = null; // Reset after successful addition
                }
                else
                {
                    ErrorMessage = result.Reason;
                }
            }
            else
            {
                ErrorMessage = "Please select a department to create.";
            }

            return Page();
        }

        public IActionResult OnPostRemove(string departmentName)
        {
            if (!string.IsNullOrWhiteSpace(departmentName))
            {
                var result = school.DepartmentCatalog.TryRemoveDepartment(departmentName);

                if (result.Success)
                {
                    SuccessMessage = result.Reason;
                    return RedirectToPage(); 
                }
                else
                {
                    ErrorMessage = result.Reason;
                }
            }

            SelectedDepartment = null; 
            return Page();
        }
    }
}
