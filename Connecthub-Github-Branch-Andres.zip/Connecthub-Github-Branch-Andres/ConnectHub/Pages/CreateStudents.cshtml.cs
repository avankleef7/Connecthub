using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.Linq;
using Core.Domain;
using Microsoft.AspNetCore.Mvc.Rendering;
using ConnectHub.ViewModels.Request;

namespace ConnectHub.Pages
{
    public class CreateStudentModel : PageModel
    {
        private School school => SchoolManager.Instance;
        private readonly StudentCatalog studentCatalog;
        private readonly TeacherCatalog teacherCatalog;
        private readonly SpeakerCatalogus speakerCatalog;
        private readonly DepartmentCatalog departmentCatalog;

        // Injecteer de catalogussen via de constructor
        public CreateStudentModel(
            StudentCatalog studentCatalog,
            TeacherCatalog teacherCatalog,
            SpeakerCatalogus speakerCatalog,
            DepartmentCatalog departmentCatalog)
        {
            this.studentCatalog = studentCatalog;
            this.teacherCatalog = teacherCatalog;
            this.speakerCatalog = speakerCatalog;
            this.departmentCatalog = departmentCatalog;
        }

        [BindProperty]
        public StudentRegistration Registration { get; set; } = new StudentRegistration();

        public List<SelectListItem> Departments { get; set; } = new List<SelectListItem>();
        public string SuccessMessage { get; private set; }
        public string ErrorMessage { get; private set; }
        public List<Student> Students { get; private set; } // Voor het weergeven van de studentenlijst

        public void OnGet()
        {
            LoadDepartments();
            LoadStudentList(); // Haal de lijst van alle studenten op
        }

        public IActionResult OnPost()
        {
            LoadDepartments();

            // Laad de studentenlijst voordat je de validatie controleert
            LoadStudentList();

            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Haal de geselecteerde afdeling
            var department = school.DepartmentCatalog.GetDepartments
                .FirstOrDefault(d => d.GetName.Equals(Registration.SelectedDepartment, StringComparison.OrdinalIgnoreCase));

            if (department == null)
            {
                ModelState.AddModelError("Registration.SelectedDepartment", "Invalid department selected.");
                return Page();
            }

            try
            {
                // Gebruik de StudentFactory om een nieuwe student aan te maken
                StudentFactory factory = new StudentFactory(new EmailValidator(studentCatalog, teacherCatalog, speakerCatalog));
                var result = factory.CreateStudent(
                    Registration.FirstName,
                    Registration.LastName,
                    Registration.Gender,
                    Registration.Nationality,
                    Registration.DateOfBirth,
                    Registration.Email,
                    department,
                    studentCatalog,
                    teacherCatalog,
                    speakerCatalog
                );

                if (result.Success)
                {
                    // Hoe krijg ik de velden weer leeg?
                    SuccessMessage = result.Reason;
                    
                    LoadStudentList(); // Laad de studentenlijst opnieuw
                    //return Page(); // Refresh the page
                    return RedirectToPage("CreateStudents");
                }
                else
                {
                    ErrorMessage = result.Reason; // Toon de foutmelding bij een mislukte aanmaak
                    
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
            }

            // Laad de studentenlijst opnieuw, zelfs als er een fout was
            LoadStudentList();

            return Page();
        }

        // Haal de lijst van alle studenten op
        private void LoadStudentList()
        {
            // Verkrijg de lijst van studenten van de studentCatalog
            Students = studentCatalog.GetStudents().ToList();
        }

        private void LoadDepartments()
        {
            // Zorg ervoor dat je het juiste property gebruikt
            Departments = school.DepartmentCatalog.GetDepartments
                .Select(d => new SelectListItem { Value = d.GetName, Text = d.GetName })
                .ToList();
        }

    

    }
}
