using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ConnectHub.Pages
{
    public class EventsResultModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
