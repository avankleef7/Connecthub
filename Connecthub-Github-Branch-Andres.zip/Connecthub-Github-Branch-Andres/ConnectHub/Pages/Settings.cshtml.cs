using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ConnectHub.Pages
{
    public class SettingsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
