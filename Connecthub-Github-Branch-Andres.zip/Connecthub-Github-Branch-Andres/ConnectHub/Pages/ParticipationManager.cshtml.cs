using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Shared;
using Core.Domain;
using System.Collections.Generic;

namespace ConnectHub.Pages
{
    public class ParticipationManagerModel : PageModel
    {
        private readonly ParticipantSearchService _participantSearchService;
        private readonly ParticipantManagementService _participantManagementService;

        public ParticipationManagerModel(ParticipantSearchService participantSearchService, ParticipantManagementService participantManagementService)
        {
            _participantSearchService = participantSearchService;
            _participantManagementService = participantManagementService;
        }

        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; }

        [BindProperty(SupportsGet = true)]
        public ParticipantType ParticipantType { get; set; } = ParticipantType.All;

        public IReadOnlyList<IParticipant> Participants { get; private set; }

        public void OnGet()
        {
            Participants = _participantSearchService.Search(SearchTerm ?? string.Empty, ParticipantType);
        }

        public IActionResult OnPostRemoveParticipant(string email, ParticipantType participantType, string departmentName)
        {


            var result = _participantManagementService.RemoveParticipant(email, departmentName, participantType);

            if (result.Success)
            {
                TempData["SuccessMessage"] = result.Reason;
                return RedirectToPage("ParticipationManager");
            }
            else
            {
                TempData["ErrorMessage"] = result.Reason;
                return RedirectToPage("ParticipationManager");
            }
        }


        public IActionResult OnGetSearchParticipants(string searchTerm, ParticipantType participantType)
        {
            Participants = _participantSearchService.Search(searchTerm ?? string.Empty, participantType);
            return Partial("_ParticipantResults", Participants);
        }
    }
}
