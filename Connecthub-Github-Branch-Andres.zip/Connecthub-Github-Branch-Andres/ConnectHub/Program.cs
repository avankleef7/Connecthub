using Core.Domain;
using Infrastructure;

namespace ConnectHub
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Initialiseer de SchoolManager
            SchoolManager.Initialize(builder.Configuration);

            // Haal de verbindingstring uit de configuratie
            var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

            // Registreer de repositories en geef de verbindingstring door
            builder.Services.AddScoped<DepartmentRepository>(provider => new DepartmentRepository(connectionString)); 
            builder.Services.AddScoped<TeacherRepository>(provider => new TeacherRepository(connectionString, provider.GetRequiredService<DepartmentRepository>())); 
            builder.Services.AddScoped<StudentRepository>(provider => new StudentRepository(connectionString));
            builder.Services.AddScoped<SchoolRepository>(provider => new SchoolRepository(connectionString));
            builder.Services.AddScoped<VenueRepository>(provider => new VenueRepository(connectionString));
            builder.Services.AddScoped<SpeakerRepository>(provider => new SpeakerRepository(connectionString));
            builder.Services.AddScoped<EventRepository>(provider => new EventRepository(connectionString));

            // Registreer je catalogussen als Scoped, zodat ze afhankelijkheden goed kunnen injecteren
            builder.Services.AddScoped<StudentCatalog>();
            builder.Services.AddScoped<TeacherCatalog>();
            builder.Services.AddScoped<SpeakerCatalogus>();
            builder.Services.AddScoped<DepartmentCatalog>();
            builder.Services.AddScoped<VenueCatalog>();
            builder.Services.AddScoped<EventCatalog>();

            // Registreer andere services
            builder.Services.AddScoped<ParticipantSearchService>();
            builder.Services.AddScoped<ParticipantService>();
            builder.Services.AddScoped<ParticipantManagementService>();
            builder.Services.AddScoped<EventConflictChecker>();
            builder.Services.AddScoped<SportEventConflictChecker>();
            builder.Services.AddScoped<MeetingConflictChecker>();
            builder.Services.AddScoped<EventStatusManager>();
            builder.Services.AddScoped<EventSearchService>();

            // Enrollmentmanager
            builder.Services.AddTransient<AvailabilityChecker>();
            builder.Services.AddTransient<LimitEventService>();
            builder.Services.AddTransient<EnrollmentManager>();
            builder.Services.AddTransient<SpeakerEventManager>();
            builder.Services.AddTransient<UnenrollmentManager>();

            // Add services to the container.
            builder.Services.AddRazorPages();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseRouting();
            app.UseAuthorization();
            app.MapRazorPages();
            app.Run();
        }
    }
}
