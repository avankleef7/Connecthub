﻿using Shared;
using System;
using System.ComponentModel.DataAnnotations;

namespace ConnectHub.ViewModels.Request
{
    public class EventRegistration
    {
        [Required(ErrorMessage = "Titel is verplicht.")]
        public string Title { get; set; }
        public string SelectedDepartment { get; set; }

        [Required(ErrorMessage = "Datum is verplicht.")]
        public DateTime Date { get; set; }

        [Required(ErrorMessage = "Starttijd is verplicht.")]
        public TimeSpan StartingTime { get; set; }

        [Required(ErrorMessage = "Eindtijd is verplicht.")]
        [DataType(DataType.Time)]
        public TimeSpan EndingTime { get; set; }

        [Required(ErrorMessage = "Einddatum is verplicht.")]
        public DateTime EndDate { get; set; } 

        [Required(ErrorMessage = "Beschrijving is verplicht.")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Selecteer een locatie.")]
        public string SelectedVenue { get; set; }

        [Required(ErrorMessage = "Selecteer een evenementtype.")]
        public EventType EventType { get; set; }

        [Required(ErrorMessage = "Maximale capaciteit is verplicht.")]
        [Range(1, int.MaxValue, ErrorMessage = "Capaciteit moet groter zijn dan 0.")]
        public int MaxCapacity { get; set; }

        public EventRegistration()
        {
            Title = string.Empty; 
            Date = DateTime.Today.AddDays(1); 
            StartingTime = TimeSpan.Zero; 
            EndingTime = TimeSpan.Zero;
            EndDate = DateTime.Today.AddDays(2);
        }
    }
}
