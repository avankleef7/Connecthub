﻿using System.ComponentModel.DataAnnotations;

namespace ConnectHub.ViewModels.Request
{
    public class VenueRegistration
    {
        [Required(ErrorMessage = "Locatienaam is verplicht.")]
        public string LocationName { get; set; }

        [Required(ErrorMessage = "Adres is verplicht.")]
        public string Address { get; set; } // Correcte spelling van "Address"

        [Required(ErrorMessage = "Kamer type is verplicht.")]
        public string RoomType { get; set; } // Hier is de juiste property naam

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Capaciteit moet groter zijn dan 0.")]
        public int Capacity { get; set; }
    }
}
