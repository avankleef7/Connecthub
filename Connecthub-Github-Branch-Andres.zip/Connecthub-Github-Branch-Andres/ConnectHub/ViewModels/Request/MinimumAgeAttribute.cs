﻿using Core.Domain.Helperclasses;
using System;
using System.ComponentModel.DataAnnotations;

namespace ConnectHub.ViewModels.Request
{
    public class MinimumAgeAttribute : ValidationAttribute
    {
        private readonly int _minimumAge;

        public MinimumAgeAttribute(int minimumAge)
        {
            _minimumAge = minimumAge;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value is DateTime dateTime)
            {
                var age = DateTimeHelper.CalculateYearsToDate(dateTime); // Gebruik de helper om de leeftijd te berekenen

                if (age < _minimumAge)
                {
                    return new ValidationResult(ErrorMessage ?? $"Je moet minimaal {_minimumAge} jaar oud zijn.");
                }
            }

            return ValidationResult.Success;
        }
    }
}
