﻿using Shared;
using System;
using System.ComponentModel.DataAnnotations;

namespace ConnectHub.ViewModels.Request
{
    public class StudentRegistration
    {
        [Required(ErrorMessage = "Voornaam is verplicht.")]
        public string FirstName { get; init; }

        [Required(ErrorMessage = "Achternaam is verplicht.")]
        public string LastName { get; init; }

        [Required(ErrorMessage = "Geboortedatum is verplicht.")]
        [DataType(DataType.Date)]
        [MinimumAge(16, ErrorMessage = "Je moet minimaal 16 jaar oud zijn.")]
        public DateTime DateOfBirth { get; init; }

        [Required(ErrorMessage = "E-mailadres is verplicht.")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; init; }

        [Required(ErrorMessage = "Selecteer een afdeling.")]
        public string SelectedDepartment { get; init; }

        [Required(ErrorMessage = "Selecteer een geslacht.")] 
        public Gender Gender { get; init; }

        [Required(ErrorMessage = "Selecteer een nationaliteit.")]
        public Nationality Nationality { get; init; } = Nationality.Nederland;


    }
}
